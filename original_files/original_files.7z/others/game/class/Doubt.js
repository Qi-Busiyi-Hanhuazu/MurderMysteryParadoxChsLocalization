
class Doubt
{
  constructor(master) {
    
     this.id = master.id;
     this.chara_id = master.chara_id;
     this.target = master.target;
     this.conditions = master.conditions;
     this.phase = master.phase;
     this.title = master.title;
     this.desc = Common.replaceDefineLabelStringAll(master.desc);
     this.new_piece_id = master.new_piece_id;
     this.convinced_new_piece_id = master.convinced_new_piece_id;
     this.require_credit_lv = requireConvincingLevelDoubt();
     this.require_slots = master.require_slots;
     this.slot1 = Common.replaceDefineLabelString(master.slot1);
     this.slot2 = Common.replaceDefineLabelString(master.slot2);
     this.slot3 = Common.replaceDefineLabelString(master.slot3);

     if(typeof this.slot1 !== "undefined"){
         this.require_slots = [this.slot1, this.slot2, this.slot3].filter(s => s);
     }
     if(master.inference_help_count){
         this.inference_help_count = Common.replaceDefineLabelStringAll(master.inference_help_count);
     }
     if(master.inference_help_text){
         this.inference_help_text = Common.replaceDefineLabelStringAll(master.inference_help_text);
     }

    
    
    this.solved = false;
    
    this.dispelled = false;
    
    this.result = false;
    
    this.last_credit_point = 0;
    
    this.max_credit_point = 10;
    
    this.min_credit_point = -5;
    
    this.answer_slots = Array(this.require_slots.length).fill(null);

    
    this.desc = Common.replaceDefineColorString(this.desc);

    
    this.consumed_cost = 0;
  }

  
  setSolvePieces(inference_id) {
    this.answer_slots = inference_id.split("_");
    delete this.unsettled_answer_slots;
  }

  
  setAnswerSlot(index, piece_id) {
    if(this.unsettled_answer_slots){ 
      this.unsettled_answer_slots[index] = piece_id;
    }else{
      this.answer_slots[index] = piece_id;
    }
  }

  
  resetAnswerSlot() {
    this.answer_slots.fill(null);
  }

  
  isAnswerFull(inferenceMode=false) {
    if(inferenceMode && this.unsettled_answer_slots){
      return this.unsettled_answer_slots.every(x => x != null);
    }else{
      return this.answer_slots.every(x => x != null);
    }
  }

  isEmptyAnswer(inferenceMode=false) {
    if(inferenceMode && this.unsettled_answer_slots){
      return this.unsettled_answer_slots.every(x => x == null);
    }else{
      return this.answer_slots.every(x => x == null);
    }
  }

  
  hasInference(inferenceMode=false) {
    return this.isAnswerFull(inferenceMode);
  }

  convinceLevel() {
    const inference = getInferenceFromDoubt(this);
    return inference.convince_level_index;
  }


  
  getAnswerPieces(inferenceMode=false) {
    if(inferenceMode && this.unsettled_answer_slots){
      return this.unsettled_answer_slots;
    }else{
      return this.answer_slots;
    }
  }

  
  conclusion() {
    
    const inference = getInferenceFromDoubt(this);
    this.result = compareConvinceLevelStr(
      inference.convince_level,
      this.require_credit_lv
    );
    if (this.result) {
      
      this.dispelled = true;
    }
    this.solved = true;
    
    const tmp = getCreditPointDoubt(this, inference.convince_level);
    const point = calcGetCreditPointDoubt(this, tmp);
    return point;
  }

  toJSON = () => {
    return {
      id: this.id,
      answer_slots: this.answer_slots,
      unsettled_answer_slots: this.unsettled_answer_slots ? this.unsettled_answer_slots : [],
      result: this.result,
      solved: this.solved,
      dispelled: this.dispelled,
      last_credit_point: this.last_credit_point,
      consumed_cost: this.consumed_cost,
    };
  };

  deserialize(data) {
    this.answer_slots = data.answer_slots;
    if(data.unsettled_answer_slots && data.unsettled_answer_slots.length > 0) {
      this.unsettled_answer_slots = data.unsettled_answer_slots;
    }
    this.result = data.result;
    this.solved = data.solved;
    this.dispelled = data.dispelled;
    this.last_credit_point = data.last_credit_point;
    this.consumed_cost = data.consumed_cost;
  }

  beginCreateAnswer(){
    if(this.unsettled_answer_slots) {

    }
    else {
      this.unsettled_answer_slots = Array(this.require_slots.length).fill(null);
      this.answer_slots.forEach((piece_id, index, array) => {
          this.unsettled_answer_slots[index] = piece_id;
      });
    }
  }
  resetAnswer(){
    if(this.unsettled_answer_slots){ 
      this.beginCreateAnswer();
    }else{
      this.resetAnswerSlot();
    }
  }

  clearUnsettledAnswerSlots() {
    if(this.unsettled_answer_slots) {
      this.unsettled_answer_slots.fill(null);
    }
  }

  deleteUnsettledAnswerSlots() {
    if(this.unsettled_answer_slots) {
      delete this.unsettled_answer_slots;
    }
  }
  endCreateAnswer(is_finish){
    if(is_finish && this.unsettled_answer_slots){ 
      for (let i = 0; i < this.unsettled_answer_slots.length; i++) {
          this.answer_slots[i] = this.unsettled_answer_slots[i];
      }
    }
    delete this.unsettled_answer_slots;
  }

  getSlotData(index, inferenceMode=false){
    if(inferenceMode && this.unsettled_answer_slots){
      return this.unsettled_answer_slots[index];
    }else{
      return this.answer_slots[index];
    }

  }

  
  getDoubtTableHtml(type = "") {
    
    this.answer_slots.forEach((piece_id) =>
      console.log(`piece_id ${piece_id}`)
    );

    const chapter = TYRANO.kag.stat.f.chapter;
    const sf = TYRANO.kag.variable.sf;

    let hasCharactor = getCharacter(this.chara_id);
    if (hasCharactor == null) {
      let player = getPlayer();
      if (player.id == this.chara_id) {
        hasCharactor = player;
      } else {
        return;
      }
    }

    const bg_icon_path = `./data/image/detective/common/dummy.png`;
    const icon_path = `./data/fgimage/chara/chapters/${chapter}/${hasCharactor.id}/doubt_plate.png`;
    let info_tags = "";
    this.require_slots.forEach((tag, index, array) => {
      info_tags += `
			<info-icon-bg class="${this.id}_tag_${index}" style="background-image: url(${bg_icon_path});">
				<info-icon>
					<tag>${tag}</tag>
				</info-icon>
			</info-icon-bg>`;
      if (index < this.answer_slots.length - 1) {
        info_tags += `<info-connection></info-connection>`;
      }
    });

    let result_status = "<status-icon-notbuild></status-icon-notbuild>";
    let report_status = "";
    let is_dummy = false;
    this.previous_mode = false;
    if (this.hasInference()) {
      const doubt = this;
      if (type == "inference-page" || type == "") {
        
        is_dummy = true;
        if (this.solved) {
          
          this.previous_mode = true;
          is_dummy = false;
        }
      }
      let inference = getInferenceFromDoubt(doubt, is_dummy);
      
      
      if (!inference) {
        console.error(`No Inference => ${JSON.stringify(doubt)}`);
      } else {
        
        let result_icon_path = `./data/image/${getInferenceCommonIconPath()}`;

        const dummy_path = `./data/image/detective/common/dummy.png`;
        const _convince_path = `./data/image/detective/doubt_list/convince_icon_${inference.convince_level}.png`;
        const title = inference.name;
        const desc = inference.desc.replace(/\[r\]/g, "<br />");
        const convince_path = is_dummy ? dummy_path : _convince_path;
        result_status = `
	                    <cell-inference>
	                        <inference style="background-image: url(${result_icon_path});"></inference>
	                    </cell-inference>`;

        if (this.solved) {
          report_status = `
					<solved-icon></solved-icon>
					<cell-convince><convince style="background-image: url(${convince_path});"></convince></cell-convince>`;
        } else {
          report_status = `
					<not-solved-icon></not-solved-icon>
					<cell-convince><convince style="background-image: url(${convince_path});"></convince></cell-convince>`;
        }
      }
    }
    this.previous_mode = false;

    return `
			<doubt-content id="${this.id}" type="${type}">
				<grid type="${type}">
					<cell-none></cell-none>
					<cell><doubt-title>${this.title}</doubt-title></cell>
					<cell>▼推理に必要な情報</cell>
					<cell></cell>
					<cell>▼推理結果</cell>
					<cell>▼報告状況</cell>

					<!-- キャラアイコン -->
					<cell-icon style="background-image: url(${icon_path});"></cell-icon>
					<!-- 内容 -->
					<cell>${this.desc}</cell>
					<!-- 推理に必要な情報(タグ) -->
					<cell>${info_tags}</cell>
					<!-- = -->
					<cell>=</cell>
					<!-- 推理結果 -->
					<cell>${result_status}</cell>
					<!-- 報告状況 -->
					<cell>${report_status}</cell>
				</grid>
			</doubt-content>`;
  }

  getHtml(
    left,
    top,
    chapter_path,
    creating = false,
    prev_inference = null,
    is_dialog = false,
    is_function = false
  ) {
    const chapter = TYRANO.kag.stat.f.chapter;

    let hasCharactor = getCharacter(this.chara_id);
    if (hasCharactor == null) {
      let player = getPlayer();
      if (player.id == this.chara_id) {
        hasCharactor = player;
      } else {
        return;
      }
    }

    let inference = null;
    if (this.isAnswerFull()) {
      inference = getInferenceFromDoubt(this);
    }
    let insert_html = "";
    
    
    const tag_doubt = `
			<chara-icon style='background-image: url(./data/fgimage/chara/chapters/${chapter}/${hasCharactor.id}/doubt_plate.png); '></chara-icon>
			<doubt-title>${this.title}</doubt-title>
			<info-title>▼推理に必要な情報</info-title>
			<build-title>▼推理結果</build-title>
			<status-title>▼報告状況</status-title>
			<description>${this.desc}</description>`; 
    

    insert_html = tag_doubt;

    let info_icon_x = 737;
    let info_cross_x = 804;
    let info_icon_space = 90;
    if (is_dialog) {
      info_icon_x = 720;
      info_cross_x = 787;
      info_icon_space = 90;
    } else if (is_function) {
      info_icon_x = 662;
      info_cross_x = 724;
      info_icon_space = 80;
    }

    
    const tag_info_connection = "info-connection";
    const tag_info_answer_function_icon_old = `
			<info-icon style='left: {0}px;'>
				<icon-frame style='background-image: url(./data/fgimage/chara/{3}/frame.png);' />
				<icon style='background-image: url(./data/image/{1}/piece/icon_{2}.png);'/>
				<tag>{4}</tag>
			</info-icon>`;

    const tag_info_answer_function_icon = `
			<info-icon style='left: {0}px;'>
				<icon-frame style='background-image: url(./data/fgimage/chara/{2}/frame.png);' />
				<icon style='background-image: url(./data/image/{1});'/>
				<tag>{3}</tag>
			</info-icon>`;

    
    let tag_status_icon = "";

    if (inference) {
      tag_status_icon = `
			<info-equal>
				<status-icon-build style='background-image: url(./data/image/${getInferenceCommonIconPath()}); '></status-icon-build>
			</info-equal>`;
    } else {
      tag_status_icon = `
			<info-equal>
				<status-icon-build style='background-image: url(./data/image/${chapter_path}/doubt/icon_${this.id}.png); '></status-icon-build>
			</info-equal>`;
      console.error(`Use obsoleted path style ${this.id}`);
    }

    if (!creating && inference != null) {
      this.answer_slots.forEach((piece_id, index, array) => {
        let piece = getPiece(piece_id);
        let pieceHasCharacter = getCharacter(piece.chara_id);
        if (!pieceHasCharacter && piece.chara_id == "itsuki") {
          pieceHasCharacter = getPlayer();
        }

        if (piece.resouce) {
          insert_html += tag_info_answer_function_icon.format(
            info_icon_x + index * info_icon_space,
            piece.resouce,
            pieceHasCharacter.resource,
            this.require_slots[index]
          );
        } else {
          insert_html += tag_info_answer_function_icon_old.format(
            info_icon_x + index * info_icon_space,
            chapter_path,
            piece_id,
            pieceHasCharacter.id,
            this.require_slots[index]
          ); 
          console.error("Use obsoleted path style it01");
        }

        if (index < this.answer_slots.length - 1) {
          const left = info_cross_x + index * info_icon_space;
          insert_html += `<${tag_info_connection} style='left: ${left}px; '></${tag_info_connection}>`; 
        }
      });
      insert_html += tag_status_icon;
      const tag_convince_icon = `<convince-icon style='background-image: url(./data/image/detective/doubt_list/convince_icon_${inference.convince_level}.png); '></convince-icon>`;
      insert_html += tag_convince_icon.format(inference.convince_level);
    } else {
      this.require_slots.forEach((tag, index, array) => {
        if (
          creating &&
          this.answer_slots[index] != null &&
          this.answer_slots[index] != ""
        ) {
          let piece_id = this.answer_slots[index];
          let piece = getPiece(piece_id);
          let pieceHasCharacter = getCharacter(piece.chara_id);
          if (!pieceHasCharacter && piece.chara_id == "itsuki") {
            pieceHasCharacter = getPlayer();
          }
          if (piece.resouce) {
            insert_html += tag_info_answer_function_icon.format(
              info_icon_x + index * info_icon_space,
              piece.resource,
              pieceHasCharacter.resource,
              this.require_slots[index]
            );
          } else {
            insert_html += tag_info_answer_function_icon_old.format(
              info_icon_x + index * info_icon_space,
              chapter_path,
              piece_id,
              pieceHasCharacter.id,
              this.require_slots[index]
            );
            console.error("Use obsoleted path style it01");
          }
        } else {
          const left = info_icon_x + index * info_icon_space;
          insert_html += `<info-icon style='left: ${left}px; '><tag>${tag}</tag></info-icon>`;
        }
        if (index < this.answer_slots.length - 1) {
          const left = info_cross_x + index * info_icon_space;
          insert_html += `<${tag_info_connection} style='left: ${left}px; '></${tag_info_connection}>`;
        }
      });
      if (creating && prev_inference != null) {
        insert_html += tag_status_icon;
        const tag_convince_icon = `<convince-icon style='background-image: url(./data/image/detective/doubt_list/convince_icon_${prev_inference}.png); '></convince-icon>`;
        insert_html += tag_convince_icon;
      } else {
        const tag_status_notbuild_icon =
          "<info-equal /><status-icon-notbuild></status-icon-notbuild>"; 
        insert_html += tag_status_notbuild_icon;
      }
    }

    if (this.solved) {
      const tag_solved_icon = "<solved-icon></solved-icon>";
      insert_html += tag_solved_icon;
    }

    if (is_dialog) {
      
      const div =
        "<dialog-doubt-container id={0} style='left:{1}px;top:{2}px;'>{3}</dialog-doubt-container>";
      return div.format(this.id, left, top, insert_html);
    } else if (is_function) {
      const tag_div_function =
        "<div class='function-doubt-container'  id={0} style='left:{1}px;top:{2}px;'>{3}</div>"; 
      return tag_div_function.format(this.id, left, top, insert_html);
    }

    const tag_div =
      "<div class='doubt-container' id={0} style='left:{1}px;top:{2}px;'>{3}</div>"; 
    return tag_div.format(this.id, left, top, insert_html);
  }

  shouldDisplayInferenceHelp() {
    if(!this.inference_help_text){ return ""; }

    const count = getInferenceCreateCount(this.id);
    if(count >= Number(this.inference_help_count)){
        return this.inference_help_text;
    }
    return "";
  }
}


function doubtDebugHtml()
{
  if (!mist_save.enable_debug) return;

  Common.debugInfoHtml(() => getOwnerDoubts(mist_save.npc), false);
}

function setupDoubtMaster(master_json){
  let dict_id = {};
  let dict_chara = {};
  let dict_phase = {};

  const json_obj = JSON.parse(master_json);
  json_obj.forEach((item) => {
      let doubt = new Doubt(item);
      dict_id[doubt.id] = doubt;
      if(doubt.phase != ""){	
          const phase = doubt.phase;
          if(!dict_phase[phase]){
              dict_phase[phase] = {};
          }
          dict_phase[phase]
          if(!dict_phase[phase][doubt.chara_id]){
              dict_phase[phase][doubt.chara_id] = new Array();
          }
          dict_phase[phase][doubt.chara_id].push(doubt);
          return ;
      }

      if(!dict_chara[doubt.chara_id]){
          dict_chara[doubt.chara_id] = new Array();
      }
      dict_chara[doubt.chara_id].push(doubt);
  });

  masterdata.doubt = {
      dict_id: dict_id,
      dict_chara: dict_chara,
      dict_phase: dict_phase,
  };

  doubtDebugHtml();
}


function updateAnswerSlotsHtml(doubt)
{
    doubt.answer_slots.forEach((piece_id, index) => {
        if (piece_id === undefined || piece_id === null) return;
        let piece = getPiece(piece_id);
        let pieceHasCharacter = getCharacter(piece.chara_id);
        if (!pieceHasCharacter && piece.chara_id == "itsuki") {
            pieceHasCharacter = getPlayer();
        }

        const bg_icon_path = `./data/fgimage/chara/${pieceHasCharacter.resource}/frame.png`;
        let bg_elem = $(`.${doubt.id}_tag_${index}`);
        bg_elem.css("background-image", `url(${bg_icon_path})`);
        let icon_path = '';
        if(piece.resource){
            icon_path = `./data/image/${piece.resource}`;
        }else{
            icon_path = `./data/image/${mist_system.chapter_path}/piece/icon_${piece_id}.png`; 
            console.error('Use obsoleted path style it01');
        }
        bg_elem.children('info-icon').css("background-image", `url(${icon_path})`)
    });
}


function getDoubt(id) {
    return masterdata.doubt.dict_id[id];
}


function getOwnerDoubtCount(chara_id) {
    return getOwnerDoubts(chara_id).length;
}


function getOwnerDoubts(chara_id){
    const doubts = masterdata.doubt.dict_chara[chara_id];
    return (!doubts) ? [] : doubts;
}


function saveDoubts(phase) {
    mist_save.saved_doubts = mist_save.saved_doubts || {};
    mist_save.saved_doubts[phase] =  JSON.stringify(masterdata.doubt.dict_id);
}


function loadDoubts(phase) {
    const save_doubts = mist_save.saved_doubts;
    if(save_doubts == null || save_doubts[phase] == null) { return; }
    const json = JSON.parse(save_doubts[phase]);
    Object.keys(json).forEach(function(id) {
        getDoubt(id).deserialize(json[id]);
    });

    
    if (mist_save.doubt !== undefined && !!mist_save.doubt)
    {
      mist_save.doubt = getDoubt(mist_save.doubt.id);
    }
}
