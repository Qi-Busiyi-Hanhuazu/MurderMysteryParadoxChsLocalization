
class DetectiveContainer {
  INVALIDATE_BADGE = {			
      'LISTEN': (1<<0), 		
      'INFERENCE': (1<<1),		
      'SHOW': (1<<2),			
      'QUESTION': (1<<3),		
      'ALL': 0x7,
  };

  
  constructor() {
    
    mist_save.detective_select_index = -1;
    mist_save.detective_select_target = "";
    mist_save.last_detective_select_index = 1;
    mist_save.detective_select_list = []
    mist_save.is_show_effect = false;

    TYRANO.kag.off("messagewindow-show", this.systemShowEffect);
    TYRANO.kag.off("messagewindow-hide", this.systemHideEffect);

    TYRANO.kag.on("messagewindow-show", this.systemShowEffect);
    TYRANO.kag.on("messagewindow-hide", this.systemHideEffect);
  }

  load() {
    
    const container = $("detective-new-container");
    container.find("chara-grid").each(function() {
      
      const elem = $(this).find("nameplate > name");
      const off_path = elem.css("background-image");
      if(off_path.indexOf("_h.png") >= 0) {
        elem.css("background-image", off_path.replace("_h.png", ".png"));  
      }
    });
    if (mist_save.detective_select_target != "")
    {
      this.setSelectEvent(mist_save.detective_select_target, String(isModeVote()));
    }
    TYRANO.kag.off("messagewindow-show", this.systemShowEffect);
    TYRANO.kag.off("messagewindow-hide", this.systemHideEffect);

    TYRANO.kag.on("messagewindow-show", this.systemShowEffect);
    TYRANO.kag.on("messagewindow-hide", this.systemHideEffect);
  }

  
  remove() {
    $("detective-new-container").remove();
    $('video[data-video-name*="badge-movie"]').remove();
    this.stopTimeAnimation();
  }

  show() {
    $("detective-new-container").show();
  }

  hide() {
    $("detective-new-container").hide();
    this.stopTimeAnimation();
  }

  
  clearSelectIndex() {
    mist_save.last_detective_select_index = 1;
  }

  
  offSelectEvent() {
    mist_save.detective_select_index = -1;
    mist_save.detective_select_target = "";
    const container = $("detective-new-container");
    
    container.find("chara-grid").each(function() {
      $(this).attr("tabindex", "");
      $(this).removeClass("tyrano-focusable");
      $(this).css("cursor", "default");
      $(this).off();

      
      const elem = $(this).find("nameplate > name");
      const off_path = elem.css("background-image");
      elem.css("background-image", off_path.replace("_h.png", ".png"));
    });

    const select_elem = container.find("select-element");
    select_elem.css("background-image", "none");
    this.setVisibleTime(false);
  }

  
  setSelectEvent(target, is_voting) {
    mist_save.detective_select_target = target;
    mist_save.detective_select_index = -1;
    mist_save.detective_select_list = [];
    const that = this;
    const container = $("detective-new-container");

    const not_there_characters = getCommonCondition("not_there_characters");
    
    
    container.find("chara-grid").each(function(i) {
      
      if (i == 0) { 
        mist_save.detective_select_list.push(undefined);
        return;
      }

      const chr = mist_system.DetectiveManager.characters[i];
      
      if(not_there_characters != null && Object.keys(not_there_characters.value).findIndex(x => x == chr.id) >= 0) {
        return;
      }

      mist_save.detective_select_list.push($(this));
      $(this).attr("tabindex", "-1");
      $(this).addClass("tyrano-focusable");
      $(this).css("cursor", "pointer");
      $(this).off();
      $(this).click((e) => {
        if (mist_temp.is_tutorial) return;
        if (isInMacroFile()){
            console.warn(`マクロ内なので実行できません`); 
            return ;
        }
        
        
        e.stopPropagation();
        
        if(mist_save.detective_select_index == -1) { 
          mist_save.detective_select_index = i;
          mist_save.last_detective_select_index = i;
          TYRANO.kag.ftag.startTag("jump", { target: target });
          TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
        }
      });

      
      const elem = $(this).find("nameplate > name");
      const off_path = elem.css("background-image");
      const select_elem = container.find("select-element");

      const name_id = (() => {
        const id = masterdata.names[chr.name_id].id;
        
        if (id == "kumiko_p") {
          return id;
        } 

        return id.replace("_p", "");
      })();
      const on_path = "./data/image/detective/name/${name_id}.png";
      let select_path = `url(./data/image/detective/select_chara/${TYRANO.kag.stat.f.chapter}_${chr.id}.png)`;
      const override_select = getCommonCondition(`bg_chara_select`);
      if(override_select){
          if(override_select.value[chr.id]){
              select_path = `url(./data/image/detective/select_chara/${override_select.value[chr.id]})`;
          }
      }

      const index = i;
      const focusFunc = () => {
        
        if(mist_save.detective_select_index == -2) {
          return;
        }
        elem.css("background-image", on_path);
        select_elem.css("background-image", select_path);
        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        mist_save.last_detective_select_index = index;
      };
      const blurFunc = () => {
        
        if(mist_save.detective_select_index == -2) {
          return;
        }
        elem.css("background-image", off_path);
        select_elem.css("background-image", "none");
      };

      $(this).focus(() => {
        focusFunc();
      });
      $(this).blur(() => {
        blurFunc();
      });
      $(this).hover(() => {
        focusFunc();
      }, () => {
        blurFunc();
      });
      if (i == mist_save.last_detective_select_index) {
        Common.setFocus($(this));
      }
    });
    this.setVisibleTime(is_voting == undefined || is_voting == "false");
  }

  
  getSelectCharacter() {
    if (mist_save.detective_select_index == -1 || mist_save.detective_select_index == -2) {
      return mist_system.DetectiveManager.characters[0];
    }
    return mist_system.DetectiveManager.characters[mist_save.detective_select_index];
  }

  
  footerBack() {
    if (mist_save.detective_select_list != undefined && mist_save.last_detective_select_index != undefined) {
      Common.setFocus(mist_save.detective_select_list[mist_save.last_detective_select_index]);
    }
  }

  
   create(layer_name) {
    
    if ($("detective-new-container").length > 0) {
      this.updateUI();
      return;
    }

    const characters = mist_system.DetectiveManager.characters;
    const layer = Common.getLayer(layer_name, true);
    let container = $(
      `<detective-new-container type="${characters.length}">
        <select-element></select-element>
        <name-area></name-area>
        <grid-columns></grid-columns>
        <timer>
          <numbers>
          </numbers>
        </timer>
      </detective-new-container>`
    );

    let chara_grid_htmls = "";
    characters.forEach((x) => {
      const name_id = (() => {
        const id = masterdata.names[x.name_id].id;
        
        if (id == "kumiko_p") {
          return id;
        } 

        return id.replace("_p", "");
      })();

      const isPlayer = x.player == 1;
      chara_grid_htmls += `
      <chara-grid id="${x.id}">
        <nameplate>
            <name style="background-image: url(./data/image/detective/name/${name_id}.png)"></name>
            <line></line>
        </nameplate>
        <icon class="icon">
          <icon1 class="icon"></icon1>
          <icon2 class="icon"></icon2>
          <icon3 class="icon"></icon3>
          <icon4 class="icon"></icon4>
          <badges>
            <badge><number></number></badge>
            <badge><number></number></badge>
            <badge><number></number></badge>
            <badge><number></number></badge>
          </badges>
        </icon>
        <vigilance class="vigilance">
          <v1 class="vigilance"></v1>
          <v2 class="vigilance"></v2>
          <v3 class="vigilance"></v3>
          <v4 class="vigilance"></v4>
          <v5 class="vigilance"></v5>
        </vigilance>
        <select-region></select-region>
        <icon-voted></icon-voted>
        <icon-player-voted></icon-player-voted>
        <voted-num>
          <voted-num-text></voted-num-text>
          <voted-num-value class="type_question"></voted-num-value>
        </voted-num>
        </chara-grid>`;
    });
    
    layer.append(container);
    container.find("grid-columns").append(chara_grid_htmls);
    

    
    this.hideVoteUI();
    this.updateUI();


  }

  
  hideVoteUI()
  {
    const container = $("detective-new-container");
    
    container.find("icon-voted").setStyle("visibility", "hidden");
    container.find("icon-player-voted").setStyle("visibility", "hidden");
    container.find("voted-num").setStyle("visibility", "hidden");
  }

  
  showCredit(show_credit)
  {
    const that = this;

    $("detective-new-container").find("chara-grid").each(function () {
      const id = $(this).attr("id");
      
      if (id == "itsuki") {
        
        const container = $("detective-new-container");
        const timer_elem = container.find("timer");
        if(!timer_elem.is(":visible")) {
          
          Common.setVisible($(this).find("vigilance"), false);
          Common.setVisible($(this).find("icon"), false);
          
          Common.setVisible($(this).find("nameplate"), true);
        }
        return;
      }
      Common.setVisible($(this).find("vigilance"), show_credit);
      Common.setVisible($(this).find("icon"), show_credit);

      const character = mist_system.DetectiveManager.characters.find(x => x.id == id);
      const vigilance_list = $(this).find("vigilance > .vigilance");

      
      
      
      
      
      
      
      
      let credit_disp_level = -1;
      if (show_credit) {
        credit_disp_level = character.getCreditDispLevel();
      }
      vigilance_list.each(function(i) {
          Common.setVisible($(this), i == credit_disp_level);
      });
    });
  }

  
  showUI(is_show)
  {
    is_show = Common.toBool(is_show);
    this.showCredit(is_show);
    const that = this;
    $("detective-new-container").find("chara-grid").each(function () {
      Common.setVisible($(this).find("nameplate"), is_show);
    });
  }


  setPlayerVoted(frame_index)
  {
    const container = $("detective-new-container");
    if (container.length == 0) return;
    container.find("icon-player-voted").eq(frame_index).setStyle("visibility", "visible");
  }
  
  setVoted(taget_id)
  {
    const container = $("detective-new-container");
    if (container.length == 0) return;

    container.find("chara-grid").each(function () {
      const id = $(this).attr("id");
      if (id == taget_id) {
        $(this).find("icon-voted").setStyle("visibility", "visible");
      }
    });
  }
  
  getPositionIndex(target_id)
  {
    const container = $("detective-new-container");
    if (container.length == 0) return 0;

    let tempIndex = 0;
    container.find("chara-grid").each(function () {
      const id = $(this).attr("id");
      if (id == target_id) {
        console.log("target_id : " + target_id);
        tempIndex = Number($(this).attr("type"));
        console.log("tempIndex : " + tempIndex);
      }
    });
    return tempIndex;
  }
  resetVoted()
  {
    const container = $("detective-new-container");
    if (container.length == 0) return;

    container.find("chara-grid").each(function () {
      $(this).find("icon-voted").setStyle("visibility", "hidden");
    });
  }
  
  openVotedNum()
  {
    const container = $("detective-new-container");
    if (container.length == 0) return;

    container.find("chara-grid").each(function () {
      $(this).find("voted-num").setStyle("visibility", "visible");
    });
  }
  closeVotedNum()
  {
    const container = $("detective-new-container");
    if (container.length == 0) return;

    container.find("chara-grid").each(function () {
      $(this).find("voted-num").setStyle("visibility", "hidden");
    });
  }
  resetVotedNum()
  {
    const container = $("detective-new-container");
    if (container.length == 0) return;

    container.find("chara-grid").each(function () {
      $(this).find("voted-num").setStyle("visibility", "hidden");
      let content = $(this).find("voted-num-value");
      content.removeClass();
      content.addClass("type_question");
    });
  }
  setVotedNum(taget_id, value)
  {
    const container = $("detective-new-container");
    if (container.length == 0) return;

    container.find("chara-grid").each(function () {
      const id = $(this).attr("id");
      if (id == taget_id) {
        
        let content = $(this).find("voted-num-value");
        content.removeClass();
        content.addClass(`type_${value}`);
        }
    });
  }

  
  updateCharacterCount(character_ids = [])
  {
    
    $('video[data-video-name*="badge-movie"]').remove();

    const container = $("detective-new-container");
    if (container.length == 0) return;

    const grid = container.find("grid-columns");
    
    if (character_ids[0] == "" && character_ids[1] != "") {
      grid.addClass("right");
    } else {
      grid.removeClass("right");
    }

    if(character_ids.length == 0 || character_ids.length == 2){
        
        const select_elem = container.find("select-element");
        select_elem.css("background-image", "none");
    }

    container.attr("type", character_ids.length);
    let chara_grids = container.find("chara-grid");
    chara_grids.each(function() {
      const id = $(this).attr("id");
      const index = character_ids.findIndex(x => x == id);
      $(this).css("display", index == -1 ? "none" : "block");
      $(this).attr("type", index == -1 ? 99 : index); 
    });

    
    const elems = chara_grids.sort(function(a, b) {
      return Number($(a).attr("type")) > Number($(b).attr("type")) ? 1 : -1;
    })
    
    grid.html(elems);

    character_ids.forEach(chara_id => this.updateBadge(chara_id));
  }

  
  setVisibleTime(is_show) {
    this._updateTime(is_show);
    this._setVisiblePlayerNameplate(!is_show);

    
    
  }

  
  _setVisiblePlayerNameplate(is_show) {
    const elem = $("detective-new-container").find("chara-grid[id='itsuki']");
    if (elem.length === 0) return;
    Common.setVisible(elem.find("nameplate"), is_show);
  }

  
  updateUI() {
    const that = this;

    const not_there_characters = getCommonCondition("not_there_characters");
    $("detective-new-container").find("chara-grid").each(function () {
      
      

      const id = $(this).attr("id");
      
      if (id == "itsuki") {
        
        const container = $("detective-new-container");
        const timer_elem = container.find("timer");
        if(!timer_elem.is(":visible")) {
          
          Common.setVisible($(this).find("vigilance"), false);
          Common.setVisible($(this).find("icon"), false);
          
          Common.setVisible($(this).find("nameplate"), true);
        }
        return;
      }

      let not_there = false;
      if(not_there_characters != null && Object.keys(not_there_characters.value).findIndex(x => x == id) >= 0) {
        not_there = true;
      }
      if(not_there) {
        $(this).addClass("grayout");
      }else{
        $(this).removeClass("grayout");
      }
      Common.setVisible($(this).find("vigilance"), true);
      Common.setVisible($(this).find("icon"), true);

      const character = mist_system.DetectiveManager.characters.find(x => x.id == id);
      const vigilance_list = $(this).find("vigilance > .vigilance");

      
      if(not_there) {
        
        vigilance_list.each(function(i) {
          Common.setVisible($(this), false);
      });
      } else {
        
        
        
        
        
        
        
        let credit_disp_level = character.getCreditDispLevel();
        vigilance_list.each(function(i) {
            Common.setVisible($(this), i == credit_disp_level);
        });
      }

      that.updateBadge(character.id);
    });
  }


  
  updateBadge(chara_id)
  {
    const container = $("detective-new-container");
    const chara_length = parseInt(container.attr("type"));

    
    if (chara_id == "itsuki") {
      const grid = container.find(`chara-grid[id="${chara_id}"]`);
      Common.setVisible(grid.find("icon"), false);
      Common.setVisible(grid.find("vigilance"), false);
      return;
    }

    const not_there_characters = getCommonCondition("not_there_characters");
    let not_there = false;
    if(not_there_characters != null && Object.keys(not_there_characters.value).findIndex(x => x == chara_id) >= 0) {
      not_there = true;
    }

    let badge_counts = [0, 0, 0, 0]; 
    if(isEnableUIInfo() && !not_there){
      badge_counts = [
          mist_system.DetectiveManager.getDoubtCount(chara_id),           
          mist_system.DetectiveManager.getInferenceCount(chara_id),       
          mist_system.DetectiveManager.getBuiltInferenceCount(chara_id),  
          mist_system.DetectiveManager.getQuestionCount(chara_id),        
      ];
    }

    
    badge_counts.forEach((x, i) => {
        if(mist_save.disable_update_badge && (mist_save.disable_update_badge & (1<<i))){ 
            return ;
        }
      
      Common.setVisible(container.find(`chara-grid[id="${chara_id}"]`).find(`icon${i + 1}`), x > 0);
    });

    
    const chara_container = container.find(`chara-grid[id="${chara_id}"]`);
    if(chara_container.css("display") == "none"){ return ; } 
    chara_container.find("badge").each(function(index) {

     if(mist_save.disable_update_badge && (mist_save.disable_update_badge & (1<<index))){ 
         return ;
     }

      const count = badge_counts[index];
      Common.setVisible($(this), count > 0);
      $(this).find("number").text(count);
      
      if(index == 0){
        if(count > 0){
          const y = 915;
          let x_list = [0, 472, 843, 1212, 1582];
          if(Object.keys(masterdata.characters).length == 5){
              x_list = [0, 367, 683, 1000, 1317, 1633];
          }
          if(chara_length == 2){ 
            x_list = [204, 1480];
          }
          const idx = parseInt(chara_container.attr('type'));
          const x = x_list[idx];
          TYRANO.kag.ftag.startTag("layermode_movie",{name:`badge-movie-${chara_id}`,video:"ef025.mp4",zIndex:"999999999",skip:"false",width:"80",height:"80",top:y,left:x,mode:"screen",loop:"true",fit:"false",stop:"true"});
        }else{
          $(`video[data-video-name="badge-movie-${chara_id}"]`).remove();
        }
      }
    });
    if (mist_save.is_show_effect) {
      this.showEffect();
    } else {
      this.hideEffect();
    }
}

  
  displayTimeHtml(time_val){
    
    const str_ary = Common.stringToArray(String(time_val));
    const number_html = str_ary
      .map(c => `<number style="background-image: url(./data/image/detective/time/time_${c}.png)"></number>`)
      .join("");

    const container = $("detective-new-container");
    const timer_elem = container.find("timer");
    const numbers_elem = timer_elem.find("numbers");
    
    numbers_elem.empty();
    
    numbers_elem.html(number_html);

    this.applyTempTime();
  }

  updateTimeInAnimation(animSetting){
    const val = animSetting["step"];
    let current_val = 0;
    let digits = $('numbers').find('number').length - 1;
    $('numbers').find('number').each(function(i, elem) {
        const scale = 10 ** digits;
        current_val += Number($(elem).css('background').match(/time_(\d+)\.png/)[1]) * scale;
        digits -= 1;
    });
    current_val = Math.max(current_val - val, animSetting["end"]);
    current_val = parseInt(current_val);
    
    this.displayTimeHtml(current_val);
    if(current_val == animSetting["end"] || current_val <= 0){
      this.stopTimeAnimation();
    }
  }

  registTimeAnimation(animSetting){
    this.stopTimeAnimation();
    
    
    animSetting["step"] = 1;
    this.intervalId = setInterval(() =>{ this.updateTimeInAnimation(animSetting); }, animSetting.time);
  }

  stopTimeAnimation(){
    if(this.intervalId){
      clearInterval(this.intervalId);
      this.intervalId = 0;
    }
  }
  
  applyTempTime() {
    if (mist_save.temp_player_cost != 0) {
      const tempCost = TYRANO.kag.stat.f.player_cost;
      TYRANO.kag.stat.f.player_cost = mist_save.temp_player_cost;
      mist_save.temp_player_cost = 0;
      consumeCost(TYRANO.kag.stat.f.player_cost - tempCost);
    }
  }
  
  applyTime() {
    const container = $("detective-new-container");
    const timer_elem = container.find("timer");
    const numbers_elem = timer_elem.find("numbers");
    if (!Common.isVisible(timer_elem)) {
      
      return;
    }
    timer_elem.removeAttr("type");
    if(mist_save.phaseTiming == "secret"){
        
        timer_elem.attr("type", "1");
    }

    
    
    let current_val = 0;
    let digits = $('numbers').find('number').length - 1;
    $('numbers').find('number').each(function(i, elem) {
        const scale = 10 ** digits;
        current_val += Number($(elem).css('background').match(/time_(\d+)\.png/)[1]) * scale;
        digits -= 1;
    });
    if (mist_save.temp_player_cost != 0) {
      const aniation_time = {"start": current_val, "end": mist_save.temp_player_cost, "delta": Math.abs(current_val - mist_save.temp_player_cost), "time": 350};
      this.registTimeAnimation(aniation_time);
    }
    else {
      const aniation_time = {"start": current_val, "end": mist_save.player_cost, "delta": Math.abs(current_val - mist_save.player_cost), "time": 350};
      this.registTimeAnimation(aniation_time);
    }
  }

  
  _updateTime(is_show) {
    const container = $("detective-new-container");
    const timer_elem = container.find("timer");
    const numbers_elem = timer_elem.find("numbers");
    Common.setVisible(timer_elem, is_show);
    if (!is_show) {
      numbers_elem.empty();
      return;
    }
    timer_elem.removeAttr("type");
    if(mist_save.phaseTiming == "secret"){
        
        timer_elem.attr("type", "1");
    }
    
    if (this.intervalId) {
      this.applyTime();
      return;
    }
    if (mist_save.temp_player_cost != 0) {
      this.displayTimeHtml(mist_save.temp_player_cost);
    } else {
      this.displayTimeHtml(mist_save.player_cost);
    }
  }

  hideEffect(){
    mist_save.is_show_effect = false;
    $('video[data-video-name*="badge-movie"]').hide();
  }
  showEffect(){
    mist_save.is_show_effect = true;
    $('video[data-video-name*="badge-movie"]').show();
    if(mist_system.DetectiveContainer.hidingChoiceEffect){
        mist_system.DetectiveContainer.hideChoiceEffect();
    }
  }
  systemHideEffect(){
    $('video[data-video-name*="badge-movie"]').hide();
  }
  systemShowEffect(){
    if (mist_save.is_show_effect) {
      $('video[data-video-name*="badge-movie"]').show();
    }
    if(mist_system.DetectiveContainer.hidingChoiceEffect){
        mist_system.DetectiveContainer.hideChoiceEffect();
    }
  }
  hideChoiceEffect(){
    $('video[data-video-name*="badge-movie-choice"]').hide();
    this.hidingChoiceEffect = true;
  }
  showChoiceEffect(){
    $('video[data-video-name*="badge-movie-choice"]').show();
    this.hidingChoiceEffect = false;
  }

}

Common.sfAddClass(new DetectiveContainer());
