
class ChapterView
{
    constructor(chapter, elem, call_back) {
        this.button_clicked = false;
        this.create(call_back);
        this.addEvent();
    }

    
    create(call_back)
    {
        const that = this;
        let elem = $('chapter-container > content > items');

        Object.keys(mist_system.chapter_select).forEach(function (key) {
            const x = mist_system.chapter_select[key];
            const master = masterdata.chapter.find(v => v.id == key);
            if(mist_system.chapters[master.chapter_id].is_release) {
                const html = $(`
                    <item type="${key}">
                        <thumbnail class="shadow">
                            <thumbnail-image style="background-image: url(./${master.image});"></thumbnail-image>
                            <tape></tape>
                            <new></new>
                            ${x.is_badge && master.badge != 0 ?
                                `<badge>
                                    <number>1</number>
                                    <video class="layer_blend_mode blendlayer blendvideo" style="position: relative; width: 80px; height: 80px; background-color: black; top: -66px; left: -26px; background-size: cover; mix-blend-mode: screen;" src="./data/video/ef025.mp4" autoplay="" playsinline="1" loop=""></video>
                                </badge>`: ''}
                        </thumbnail>
                        <chapter>${master.chapter_name}</chapter>
                        <title>${master.title}</title>
                    </item>`);
                elem.append(html);
                Common.setVisible(html.find('new'), x.is_new);
            }
            else {
                const html = $(`
                    <item type="${key}">
                        <thumbnail>
                        </thumbnail>
                        <chapter>${master.chapter_name}</chapter>
                        <title>？</title>
                    </item>`);
                elem.append(html);
            }
        });

        const item_left = mist_system.chapter_select.length % 4;
        if(item_left > 0) {
            for(let i = 0; i < 4 - item_left; ++i) {
                elem.append($('<empty-item></empty-item>'));
            }
        }

        elem.append($('<footer-space></footer-space>'));

        var layer_menu = TYRANO.kag.layer.getMenuLayer();
        const close_event = function(e){
            that.focusManager.unregisterFocus();
            layer_menu.hide();
            layer_menu.empty();
            mist_system.FooterContainer.back();
            e.stopPropagation();
            if (typeof call_back == "function") {
                call_back();
            }
        };
        const footer_display_data = {
            is_visible_close_button_q_key:true,
            close_event_q_key:close_event,
            help_text:getCommonHelpDirect("chapter_scene")
        };
        mist_system.FooterContainer.showCollectionFooter(footer_display_data);

        
        if(!mist_system.open_chapter) {
            mist_system.open_chapter = true;
            Common.saveSystem();
        }
    }

    
    addEvent()
    {
        const that = this;
        let elem_list = [];
        let count = 0;
        $('chapter-container > content > items > item').each(function() {
            let elem = $(this);
            elem_list.push(elem);
            elem.off();
            elem.click(function(e){
                if (mist_temp.is_tutorial) return;
                that.focusManager.unregisterFocus();
                Common.setBlock(true);
                e.stopPropagation();

                const select_id = $(this).attr("type");
                let item = mist_system.chapter_select[select_id];
                const master = masterdata.chapter.find(v => v.id == select_id);
                if(!mist_system.chapters[master.chapter_id].is_release) {
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                    that.focusManager.registerFocus();
                    that.focusManager.setLastFocus();
                    Common.setBlock(false);
                    return;
                }
                item.is_new = false;
                mist_system.chapters[master.chapter_id].is_new = false;
                Common.setVisible(elem.find('new'), item.is_new);
                
                Common.saveSystem();

                
                
                that.createConfirmDialog(master,
                     () => {
                        const title_layer = $(".title-container");
                        title_layer.hide();
                        title_layer.empty();
        
                        var layer_menu = TYRANO.kag.layer.getMenuLayer();
                        layer_menu.hide();
                        layer_menu.empty();
                        mist_system.FooterContainer.back();
                        delete mist_temp.disable_footer_action;
                        e.stopPropagation();
                        restartGameProgress();

                        
                        mist_save.chapter_select_start = true;                        

                        TYRANO.kag.stat.f.current_play_bgm = "";
                        TYRANO.kag.variable.tf.set_chapter_data = master.chapter;
                        TYRANO.kag.variable.tf.jump_story_file = master.scenario_path;
                        TYRANO.kag.variable.tf.jump_label = master.scenario_label;
                        TYRANO.kag.ftag.startTag("jump", { storage: "scenario_start.ks" });
                     }, () => {
                        that.focusManager.registerFocus();
                        that.focusManager.setLastFocus();
                    });
            });
            const index = count;
            elem.hover(() => {
                elem.addClass("hover");
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                that.focusManager.setLastIndex(index);
            }, () => {
                elem.removeClass("hover");
            });
            ++count;
        });
        const max_column = 4;
        let index_list = [];
        const max_y = Math.floor((elem_list.length - 1) / max_column) + 1;
        for (let i = 0; i < elem_list.length; ++i) {
            const x = i % max_column;
            const y = Math.floor(i / max_column);
            const base_x = y * max_column;

            let top = ((y + max_y - 1) % max_y) * max_column + x;
            let bottom = (y + 1) % max_y * max_column + x;
            let left = base_x + (x + max_column - 1) % max_column;
            let right = base_x + (x + 1) % max_column;

            if (top >= elem_list.length) {
                top -= max_column;
            }
            if (bottom >= elem_list.length) {
                bottom = x;
            }
            if (left >= elem_list.length) {
                left = elem_list.length - 1;
            }
            if (right >= elem_list.length) {
                right = base_x;
            }
            
            index_list.push([top, bottom, left, right]);
        }

        this.focusManager = new FocusManager("chapter", elem_list, index_list);
    }

    createConfirmDialog(master, decide_target, cancel_target) {
        const warning = master.auto_save != 0 ? "<br>※オートセーブデータは上書きされます。" : "";
        const data = masterdata.define_dialog["CHAPTER_CONFIRM"];
        let dialog = Common.createDialogBase(false);
        const html = `
            <chapter-confirm-window>
                <container>
                    <title>このチャプターからゲームを開始しますか？</title>
                    <warning>※コンティニューはできません（終了時、タイトル画面に戻ります）${warning}</warning>
                    <item type="${master.id}">
                        <thumbnail>
                            <thumbnail-image style="background-image: url(./${master.image});"></thumbnail-image>
                            <tape></tape>
                        </thumbnail>
                        <chapter>${master.chapter_name}</chapter>
                        <title>${master.title}</title>
                    </item>                    
                </container>
                <button-grid>
                    <button-container>
                        <chapter-button class="dialog-decide-button">${data.yes}</chapter-button>
                        <line></line>
                        <cursor></cursor>
                    </button-container>
                    <button-container>
                        <chapter-button class="dialog-cancel-button">${data.no}</chapter-button>
                        <line></line>
                        <cursor></cursor>
                    </button-container>
                </button-grid>
            </chapter-confirm-window>
            <sample class="sample_imagea"></sample>`;

        dialog.html(html);
        this.yesNoButtonSetting(dialog, decide_target, cancel_target);
        Common.fadeInAnimation(dialog);
    }

    
    yesNoButtonSetting(dialogBase, decide_target, cancel_target, click_event = null)
    {
        
        setFlagStopGameProgress(true);

        const decide_button = dialogBase.find("button-container").eq(0);
        const yes_cursor = decide_button.find("cursor");
        const yes_line = decide_button.find("line");
        const yes_text = decide_button.find("button");
        const cancel_button = dialogBase.find("button-container").eq(1);
        const no_cursor = cancel_button.find("cursor");
        const no_line = cancel_button.find("line");
        const no_text = cancel_button.find("button");

        Common.setVisible(yes_cursor, false);
        Common.setVisible(yes_line, false);
        mist_system.Dialog.setButtonEvent(decide_button, decide_target, "",
            () => {
                Common.setVisible(yes_line, true);
                decide_button.addClass("selected");
                yes_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(yes_line, false);
                decide_button.removeClass("selected");
                yes_text.removeClass("selected-white-back");
            },
            "system/se_sys02.mp3",
            click_event
        );

        Common.setVisible(no_cursor, false);
        Common.setVisible(no_line, false);
        mist_system.Dialog.setButtonEvent(cancel_button, cancel_target, "",
            () => {
                Common.setVisible(no_line, true);
                cancel_button.addClass("selected");
                no_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(no_line, false);
                cancel_button.removeClass("selected");
                no_text.removeClass("selected-white-back");
            },
            "system/se_sys01.mp3",
            click_event
        );
    }
}
