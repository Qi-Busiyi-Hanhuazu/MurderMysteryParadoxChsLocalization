
class FooterContainer {
    footer_display_data_stack = [];
    footer_display_data_stack_mark_index = -1; 
    timeout_id = {};
    scroll_x = 0;
    default_z_index = 0;
    deactive_timeout_id = 0;
    prev_button_image = {};
    movie_skip_event = null;

    constructor() {
        const base_path = "./data/image/adv/new_footer";
        this.storages = {
            note: `${base_path}/note.png`,
            note2: `${base_path}/note2.png`,
            close0: `./data/image/common/button_close.png`,
            close1: `./data/image/common/button_close2.png`,
            auto: `${base_path}/auto.png`,
            auto2: `${base_path}/auto2.png`,
            auto3: `${base_path}/auto3.png`,
            skip: `${base_path}/skip.png`,
            skip2: `${base_path}/skip2.png`,
            skip3: `${base_path}/skip3.png`,
            log: `${base_path}/log.png`,
            log2: `${base_path}/log2.png`,
            log3: `${base_path}/log3.png`,
            system: `${base_path}/system.png`,
            system2: `${base_path}/system2.png`,
            system3: `${base_path}/system3.png`,
            detectiveend: `${base_path}/detective_end.png`,
            detectiveend2: `${base_path}/detective_end2.png`,
            detectiveend3: `${base_path}/detective_end3.png`,
            secretend: `${base_path}/secret_end.png`,
            secretend2: `${base_path}/secret_end2.png`,
            background: `${base_path}/base.png`,
            noimage: `${base_path}/dummy.png`,
        };
    }

    
    load() {
        this.addEvent();
        const footer = mist_save.footer;
        
        if(footer.footer_display_data_stack && footer.footer_display_data_stack.length > 0){
            this.removeMark();
            this.footer_display_data_stack = footer.footer_display_data_stack;
            
            this.setupFooterContainer(this.footer_display_data_stack[this.footer_display_data_stack.length -1], true);
            
        }else{
            this.onChageFooter(mist_save.detective_mode, mist_save.detective_phase, mist_save.phaseTiming);
        }
        let content = $("footer-container > left-content");
        if (Common.isVisible(content)) {
            this.onDetectiveEvent(footer.note_taret, footer.detective_end_target);
        }
    }

    
    show(update_is_hide = true) {
        $("footer-container").show();
        $("footer-container").attr("l_visible", true);

        if(this.footer_display_data_stack.length > 0 && update_is_hide){
            this.footer_display_data_stack[this.footer_display_data_stack.length -1].is_hide = false;
        }
    }

    
    hide(update_is_hide = true) {
        $("footer-container").hide();
        $("footer-container").attr("l_visible", false);

        
        if(this.footer_display_data_stack.length > 0 && update_is_hide){
            this.footer_display_data_stack[this.footer_display_data_stack.length -1].is_hide = true;
        }
    }

    
    enableSelectAction(){
        return this.isVisible();
    }

    isVisible() {
        return Common.toBool($("footer-container").attr("l_visible"));
    }
    
    
    setupFooterContainer(display_param, is_back=false) {
        $("footer-container").show();

        
        if(!is_back) {
            this.footer_display_data_stack.push(display_param);
            if(mist_save.footer){
                mist_save.footer.footer_display_data_stack = this.footer_display_data_stack;
            }else{
                mist_save.footer = {
                    footer_display_data_stack : this.footer_display_data_stack
                };
            }
        } else {
            
            switch (display_param.back_mode) {
                case 1 :
                    
                    mist_system.DetectiveContainer.footerBack();
                    break;
                case 2 :
                    
                    mist_system.SecretTalkContainer.footerBack();
                    break;
                case 3 :
                    
                    mist_system.SecretTalkContainer.footerBack();
                    break;
                case 4 :
                    
                    mist_system.DetectiveContainer.footerBack();
                    break;
                case 5 :
                    
                    mist_system.ContinueContainer.backLoad();
                    break;
                case 6 :
                    
                    mist_system.SelectContainer.footerBack();
                    break;
                default:
                    break;
            }
        }

        const left_content = $("footer-container > left-content");
        if(display_param.is_visible_left_content){
            Common.setVisible(left_content, true);
        }else{
            Common.setVisible(left_content, false);
        }
        
        const right_content = $("footer-container > right-content");
        if(display_param.is_visible_right_content){
            Common.setVisible(right_content, true);
            this.active();
        }else{
            Common.setVisible(right_content, false);
        }
        
        if(display_param.is_visible_note_button){
            left_content.find("note-button").show();
        }else{
            left_content.find("note-button").hide();
        }
        
        if(display_param.is_visible_detective_end_button){
            left_content.find("detective-end-button").show();
        }else{
            left_content.find("detective-end-button").hide();
        }
        
        if(display_param.is_visible_secret_end_button){
            left_content.find("secret-end-button").show();
        }else{
            left_content.find("secret-end-button").hide();
        }

        const auto_button = right_content.find("auto-button");
        if(display_param.is_visible_auto) {
            Common.setVisible(auto_button, true);
        }
        else {
            Common.setVisible(auto_button, false);
        }

        const skip_button = right_content.find("skip-button");
        
        if(display_param.is_visible_skip) {
            Common.setVisible(skip_button, true);
        }
        else {
            Common.setVisible(skip_button, false);
        }

        const log_button = right_content.find("log-button");
        if(display_param.is_visible_log) {
            Common.setVisible(log_button, true);
        }
        else {
            Common.setVisible(log_button, false);
        }

        const system_button = right_content.find("system-button");
        const movie_skip_button = right_content.find("movie-skip-button");
        if(display_param.is_visible_system) {
            movie_skip_button.hide();
            system_button.show();
            Common.setVisible(system_button, true);
        }
        else {
            Common.setVisible(system_button, false);
        }

        
        if(display_param.is_visible_movie_skip) {
            this.movie_skip_event = display_param.movie_skip_event;
            movie_skip_button.show();
            system_button.hide();
            Common.setVisible(movie_skip_button, true);
        }
        else {
            Common.setVisible(movie_skip_button, false);
            this.movie_skip_event = undefined;
        }
        
        const close_key = left_content.find("close-button");

        
        close_key.css("background-image", `url(${this.storages["close0"]})`);

        if(display_param.is_visible_close_button){
            close_key.show();
            close_key.off();
            if(display_param.close_event != undefined){
                close_key.click(function(e){
                    if (mist_temp.is_tutorial) return;

                    const isFooterDisplay = $("footer-container").css('display') != "none";
                    if(!isFooterDisplay){
                        return;
                    }
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                    display_param.close_event(e);
                });
            }
            close_key.hover(() => {
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                close_key.css("background-image", `url(${this.storages["close1"]})`);
            }, () => {
                close_key.css("background-image", `url(${this.storages["close0"]})`);
            });
        }else{
            close_key.hide();
            close_key.off();
        }

        const close_q_key = left_content.find("close-button-q-key");

        
        close_q_key.css("background-image", `url(${this.storages["close0"]})`);

        if(display_param.is_visible_close_button_q_key){
            close_q_key.show();
            close_q_key.off();
            if(display_param.close_event_q_key != undefined){
                close_q_key.click(function(e){
                    if (mist_temp.is_tutorial) return;
                    
                    const isFooterDisplay = $("footer-container").css('display') != "none";
                    if(!isFooterDisplay){
                        return;
                    }
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                    display_param.close_event_q_key(e);
                });
            }
            close_q_key.hover(() => {
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                close_q_key.css("background-image", `url(${this.storages["close1"]})`);
            }, () => {
                close_q_key.css("background-image", `url(${this.storages["close0"]})`);
            });
        }else{
            close_q_key.hide();
            close_q_key.off();
        }

        if(display_param.is_visible_footer_base){
            this.show_base()
        }else{
            this.hide_base();
        }

        if(display_param.is_visible_help_bar){
            left_content.find("help").show();
        }else{
            left_content.find("help").hide();
        }

        if(display_param.z_index){
            $("footer-container").css("z-index", display_param.z_index);
        }else{
            $("footer-container").css("z-index", this.default_z_index);
        }

        
        const update_is_hide = !is_back;
        if(display_param.is_hide){
            this.hide(update_is_hide);
        }else{
            this.show(update_is_hide);
        }

        
        this.updateHelp({help:display_param.help_text, type:display_param.help_type, skip_update_help:is_back});

        
        if(display_param.is_visible_skip) {
            
            this.active();
        }

        this.setSkipMode();
    }

    
    setBackMode(back_mode) {
        if(this.footer_display_data_stack.length > 0){
            this.footer_display_data_stack[this.footer_display_data_stack.length - 1].back_mode = back_mode;
        }
    }

    
    back(){
        if(this.footer_display_data_stack.length == 1){
            this.setupFooterContainer(this.footer_display_data_stack[0], true);
        }else{
            this.footer_display_data_stack.pop();
            this.setupFooterContainer(this.footer_display_data_stack[this.footer_display_data_stack.length - 1], true);
        }
        
        if(this.footer_display_data_stack.length -1 < this.footer_display_data_stack_mark_index){
            this.removeMark();
        }
    }

    
    isMarking(){
        return this.footer_display_data_stack_mark_index >= 0;
    }

    
    mark(){
        this.footer_display_data_stack_mark_index = this.footer_display_data_stack.length -1;
    }

    
    markBack(){
        if(!this.isMarking()){
            this.footer_display_data_stack_mark_index = 0;
        }
        this.footer_display_data_stack = this.footer_display_data_stack.slice(0, this.footer_display_data_stack_mark_index + 1);
        this.setupFooterContainer(this.footer_display_data_stack[this.footer_display_data_stack.length -1], true);
        this.removeMark();
    }
    
    removeMark(){
        this.footer_display_data_stack_mark_index = -1;
    }

    
    clearStack(){
        this.footer_display_data_stack = [];
        mist_save.footer.footer_display_data_stack = [];
        this.removeMark();
    }

    
    clearStackAndSetCurrentStateFooter(){
        const base = this.footer_display_data_stack[0];
        this.clearStack();
        this.setupFooterContainer(base);
    }

    
    create() {
        const fix_layer = TYRANO.kag.layer.getLayer("fix");
        const exist_footer = fix_layer.find("footer-container").length > 0
        
        
        if(exist_footer){
            return;
        }
        Common.preloadAll(Object.values(this.storages), () => {
            const container = $(`
                <footer-container>
                    <left-content>
                        <detective-end-button></detective-end-button>
                        <secret-end-button></secret-end-button>
                        <note-button></note-button>
                        <close-button></close-button>
                        <close-button-q-key class="menu_close"></close-button-q-key>
                        <help class="footer-help"></help>
                    </left-content>
                    <right-content>
                        <auto-button></auto-button>
                        <skip-button></skip-button>
                        <log-button></log-button>
                        <system-button></system-button>
                        <movie-skip-button style="display: none"></movie-skip-button>
                    </right-content>
                </footer-container>`);
            Common.addFixLayer(container);
            this.default_z_index = $("footer-container").css('z-index');
            this.addEvent();
            this.offDetectiveEvent();
            
            this.showRightOnlyFooter();
        });

        

    }

    
    showMenuFooter(display_param){
        let is_visible_base = true;
        if(this.footer_display_data_stack.length > 0) {
            
            is_visible_base = this.footer_display_data_stack[this.footer_display_data_stack.length - 1].is_visible_footer_base;
        }
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_close_button_q_key:display_param.is_visible_close_button_q_key,
            is_visible_right_content: true,
            is_visible_system: display_param.is_visible_system !== undefined ? display_param.is_visible_system : true,
            is_visible_footer_base:is_visible_base,
            is_visible_help_bar:true,
            close_event_q_key:display_param.close_event_q_key,
            help_text:display_param.help_text,
            help_type:display_param.help_type
        };
        this.setupFooterContainer(footer_display_param, true);
        
        this.activeImpl("system-button", "system");
    }

    
    showRightOnlyFooterAndBase(){
        var footer_display_param = {
            is_visible_right_content:true,
            is_visible_auto: true,
            is_visible_skip: true,
            is_visible_log: true,
            is_visible_system: true,
            is_visible_footer_base:true,
        };
        this.setupFooterContainer(footer_display_param);
    }

    showRightOnlyFooter(){
        var footer_display_param = {
            is_visible_right_content:true,
            is_visible_auto: true,
            is_visible_skip: true,
            is_visible_log: true,
            is_visible_system: true,
            is_visible_footer_base:false,
        };
        this.setupFooterContainer(footer_display_param);
    }

    
    showAdvFooter() {
        this.clearStack();
        this.showRightOnlyFooterAndBase();
    }

    showDetectiveAdvFooter() {
        this.clearStack();
        this.showRightOnlyFooter();
    }

    
    showInvestigationFooter(){
        var footer_display_param = {
            is_visible_right_content:true,
            is_visible_auto: true,
            is_visible_skip: true,
            is_visible_log: true,
            is_visible_system: true,
        };
        this.clearStack();
        this.setupFooterContainer(footer_display_param);
    }

    
    showInvestigationCharaSelectFooter(){
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_right_content:true,
            is_visible_auto: true,
            is_visible_skip: true,
            is_visible_log: true,
            is_visible_system: true,
            is_visible_note_button:true,
            is_visible_detective_end_button:true,
            is_visible_help_bar:true,
            is_visible_footer_base:false,
            help_type:"select",
            back_mode: 1,
        };
        this.clearStack();
        this.setupFooterContainer(footer_display_param);
    }

    
    showInvestigationSecretFooter(){
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_right_content:true,
            is_visible_auto: true,
            is_visible_skip: true,
            is_visible_log: true,
            is_visible_system: true,
            is_visible_note_button:true,
            is_visible_secret_end_button:true,
            is_visible_help_bar:true,
            is_visible_footer_base:false,
            help_type:"select",
            back_mode: 2,
        };
        this.clearStack();
        this.setupFooterContainer(footer_display_param);
    }

    
    showDebateFooter(){
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_right_content:true,
            is_visible_auto: true,
            is_visible_skip: true,
            is_visible_log: true,
            is_visible_system: true,
            is_visible_note_button:true,
            is_visible_footer_base:false,
            help_type:"none",
            back_mode: 3,
        };
        this.clearStack();
        this.setupFooterContainer(footer_display_param);
    }

    
    showVoteFooter(){
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_right_content:true,
            is_visible_auto: true,
            is_visible_skip: true,
            is_visible_log: true,
            is_visible_system: true,
            is_visible_note_button:true,
            is_visible_help_bar:true,
            is_visible_footer_base:false,
            help_type:"select",
            back_mode: 4,
        };
        this.clearStack();
        this.setupFooterContainer(footer_display_param);
    }

    
    showNoteFooter(display_param){
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_close_button:true,
            close_event:display_param.close_event,
            is_visible_help_bar:true,
            is_visible_footer_base:true,
            help_type:"note"
        };
        this.setupFooterContainer(footer_display_param);
    }

    
    showBackLogFooter(display_param){
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_close_button_q_key:true,
            is_visible_right_content: true,
            is_visible_log: true,
            close_event_q_key:display_param.close_event_q_key
        };
        this.setupFooterContainer(footer_display_param);
        
        this.activeImpl("log-button", "log");
    }

    
    showDialogFooter(display_param, is_add_stack = true){
        
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_close_button_q_key:true,
            close_event_q_key:display_param.close_event_q_key,
            is_visible_footer_base:display_param.is_visible_footer_base,
            z_index:2147483646
        };
        this.setupFooterContainer(footer_display_param, !is_add_stack);
    }

    
    showContinueFooter(){
        var footer_display_param = {
            is_visible_left_content: true,
            is_visible_right_content: true,
            is_visible_system: true,
            is_visible_help_bar:true,
            is_visible_footer_base:true,
            back_mode: 5,
        };
        this.setupFooterContainer(footer_display_param);
    }
    
    showDetectiveResultFooter(display_param){
        var footer_display_param = {
            is_visible_left_content: true,
            is_visible_right_content: true,
            is_visible_system: true,
            is_visible_help_bar:true,
            is_visible_close_button_q_key:true,
            is_visible_footer_base:true,
            close_event_q_key:display_param.close_event_q_key,
        };
        this.setupFooterContainer(footer_display_param);
    }

    
    showCollectionFooter(display_param){
        var footer_display_param = {
            is_visible_left_content:true,
            is_visible_close_button_q_key:display_param.is_visible_close_button_q_key,
            is_visible_right_content: false,
            is_visible_footer_base:true,
            is_visible_help_bar:true,
            close_event_q_key:display_param.close_event_q_key,
            help_text:display_param.help_text,
            help_type:display_param.help_type
        };
        this.setupFooterContainer(footer_display_param);
    }

    
    showMoiveFooter(skip_event){
        var footer_display_param = {
            is_visible_left_content: false,
            is_visible_right_content: true,
            is_visible_movie_skip: true,
            movie_skip_event: skip_event,
            is_visible_footer_base:true,
        };
        this.setupFooterContainer(footer_display_param);
    }

    
    showTimeWarningFooter(){
        var footer_display_param = {
            is_visible_left_content: false,
            is_visible_right_content: false,
            is_visible_system: false 
        };
        this.setupFooterContainer(footer_display_param);
    }



    
    updateHelp(mp) {
        if(!mp.skip_update_help){
            if(mp.help) {
                this.footer_display_data_stack[this.footer_display_data_stack.length - 1].help_text = mp.help;
            }
            if(mp.type) {
                this.footer_display_data_stack[this.footer_display_data_stack.length - 1].help_type = mp.type;
            }
        }
        let elem = $("footer-container > left-content > help");
        switch (mp.type) {
            case "select":
                elem.attr("type", mp.type);
                elem.html(mp.help);
                break;

            case "note":
                elem.attr("type", mp.type);
                elem.html(mp.help);
                break;

            case "none":
                elem.attr("type", mp.type);
                elem.html("");
                break;
            
            default:
                elem.html(mp.help);
                break;
        }
        this.scroll_x = 0;
        clearTimeout(this.timeout_id);


    }

    
    helpAutoScroll(elem, first) {
        elem.scrollLeft(this.scroll_x);
        let next_time = first ? 1000 : 20;
        if (this.scroll_x != elem.scrollLeft())
        {
            this.scroll_x = 0;
            next_time = 1000;
            first = true;
        }
        else
        {
            this.scroll_x += 3;
            first = false;
        }
        this.timeout_id = setTimeout(() => {
            this.helpAutoScroll(elem, first);
        }, next_time);
    }

    
    onNoteEvent() {
        
        this.updateHelp({ type: "note" });
    }

    offNoteEvent() {
        
        this.updateHelp({ type: "none" });
    }

    
    onDetectiveEvent(note_target, detective_end_target) {
        TYRANO.kag.variable.tf.click_detective_end_button = false;
        
        mist_save.footer.note_target = note_target;
        mist_save.footer.detective_end_target = detective_end_target;
        this.detective_end_target = detective_end_target;

        let content = $("footer-container > left-content");
        let detective_end_button = content.find("detective-end-button");

        
        let disable_end_secret = true;
        if(typeof getCommonCondition == 'function'){
            disable_end_secret = !getCommonCondition("end_secret_phase");
        }else{
            console.error(`TODO: getCommonConditionが未定義です、loadからの復帰方法に問題があります`);
        }
	
        let storage_key_normal = disable_end_secret ? "detectiveend3" : "detectiveend";
        let storage_key_hover = disable_end_secret ? "detectiveend3" : "detectiveend2";
        detective_end_button.off("click");
        detective_end_button.off("hover");
        detective_end_button.click((e) => {
            if (mist_temp.is_tutorial) return;
            if (Common.isPreventSimultaneosKey()) return ;
            
            e.stopPropagation();
            if(!TYRANO.kag.key_mouse.util.canShowMenu()){
                console.warn("今は開けません");
                return ;
            }
            if(TYRANO.kag.variable.tf.click_detective_end_button){
                return;
            }
            Common.addPreventScene("detective_end"); 
            TYRANO.kag.variable.tf.click_detective_end_button = true;
            if(getCommonCondition("end_secret_phase")) {
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            }
            else {
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
            }
            this.confirmEndDetective(detective_end_target);
        });
        detective_end_button.css("background-image", `url(${this.storages[storage_key_normal]})`);
        detective_end_button.hover(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            detective_end_button.css("background-image", `url(${this.storages[storage_key_hover]})`);
        }, () => {
            detective_end_button.css("background-image", `url(${this.storages[storage_key_normal]})`);
        });


    }

    
    confirmEndDetective(detective_end_target){
        
        const tutorial_id = "900";
        if(mist_save.phaseTiming == "select_talk" && !mist_system.tutorial_group[tutorial_id]){
            
            this.detective_end_target = detective_end_target;
            Common.removePreventScene("detective_end");
            TYRANO.kag.variable.sf.TutorialDialog.create(tutorial_id, "", this.confirmEndDetectiveImpl, this);
        }else{
            this.confirmEndDetectiveImpl(detective_end_target);
        }
    }

    confirmEndDetectiveImpl(detective_end_target){
        if(!detective_end_target){ detective_end_target = this.detective_end_target; } 
        Common.removePreventScene("detective_end");
        TYRANO.kag.ftag.startTag("jump", { target: detective_end_target });
    }

    offDetectiveEvent() {
        
        if(mist_save.footer){
            mist_save.footer.note_target = "";
            mist_save.footer.detective_end_target = "";
        }
        return;

        let content = $("footer-container > left-content");
        Common.setVisible(content, false);
        let note_button = content.find("note-button");
        let detective_end_button = content.find("detective-end-button");
        note_button.off();
        detective_end_button.off();
    }

    addEvent() {
        const container = $("footer-container");
        const skip_button = container.find("skip-button");
        const movie_skip_button = container.find("movie-skip-button");
        const log_button = container.find("log-button");
        const auto_button = container.find("auto-button");
        const system_button = container.find("system-button");
        const note_button = container.find("note-button");
        const detective_end_button = container.find("detective-end-button");
        const secret_end_button = container.find("secret-end-button");

        
        note_button.off();
        detective_end_button.off();
        skip_button.off();
        log_button.off();
        auto_button.off();
        system_button.off();
        movie_skip_button.off();


        
        note_button.on("mousedown touchstart", () => false);
        note_button.click(() => {
            if (mist_temp.is_tutorial) return;
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            this.openNote();
        });
        note_button.hover(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            note_button.css("background-image", `url(${this.storages["note2"]})`);
        }, () => {
            note_button.css("background-image", `url(${this.storages["note"]})`);
        });

        
        detective_end_button.on("mousedown touchstart", () => false);
        detective_end_button.click(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
        });

        
        const secret_storage_key_normal = "secretend";
        const secret_storage_key_hover = "secretend2";
        secret_end_button.click(() => {
            if (mist_temp.is_tutorial) return;
            if (Common.isPreventSimultaneosKey()) return ;

            if(!TYRANO.kag.key_mouse.util.canShowMenu()){
                console.warn("今は開けません");
                return ;
            }
            Common.addPreventScene("end_secret");

            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            this.confirmEndDetective();
        });
        secret_end_button.css("background-image", `url(${this.storages[secret_storage_key_normal]})`);
        secret_end_button.hover(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            secret_end_button.css("background-image", `url(${this.storages[secret_storage_key_hover]})`);
        }, () => {
            secret_end_button.css("background-image", `url(${this.storages[secret_storage_key_normal]})`);
        });


        
        
        skip_button.on("mousedown touchstart", () => false);
        skip_button.hover(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            if(this.isDisableButton(skip_button)){ return false; }
            skip_button.css("background-image", `url(${this.storages["skip2"]})`);
        }, () => {
            if (TYRANO.kag.stat.is_skip) return;
            if(this.isDisableButton(skip_button)){ return false; }
            skip_button.css("background-image", `url(${this.storages["skip"]})`);
        });
        Common.on("skip-start", () => {
            skip_button.css("background-image", `url(${this.storages["skip2"]})`);

            if(TYRANO.kag.stat.is_strong_stop){
                return ;
            }
            
            this.deactiveImpl("log-button", "log");
            this.deactiveImpl("system-button", "system");
        });
        Common.on("skip-stop", () => {
            let image_index = "skip";
            if(this.prev_button_image["skip-button"]){
                image_index = this.prev_button_image["skip-button"];
                delete this.prev_button_image["skip-button"];
            }
            skip_button.css("background-image", `url(${this.storages[image_index]})`);

            this.prev_button_image = {};
            this.active();
        });
        skip_button.click((e) => {
            if (mist_temp.is_tutorial) return;
            if(this.isDisableButton(skip_button)) { 
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                return false;
            }
            this.onClick(e, "skip");
        });

        
        movie_skip_button.on("mousedown touchstart", () => false);
        movie_skip_button.hover(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            if(this.isDisableButton(movie_skip_button)) { return false; }
            movie_skip_button.css("background-image", `url(${this.storages["skip2"]})`);
        }, () => {
            if(this.isDisableButton(movie_skip_button)){ return false; }
            movie_skip_button.css("background-image", `url(${this.storages["skip"]})`);
        });
        movie_skip_button.click((e) => {
            if (mist_temp.is_tutorial) return;
            if(this.isDisableButton(movie_skip_button)) { 
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                return false;
            }
            if(!this.movie_skip_event) {
                return false;
            }
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            this.movie_skip_event();
            return true;
        });

        
        auto_button.on("mousedown touchstart", () => false);
        auto_button.hover(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            if(this.isDisableButton(auto_button)){ return false; }
            auto_button.css("background-image", `url(${this.storages["auto2"]})`);
        }, () => {
            if (TYRANO.kag.stat.is_auto) return;
            if(this.isDisableButton(auto_button)){ return false; }
            auto_button.css("background-image", `url(${this.storages["auto"]})`);
        });
        Common.on("auto-start", () => {
            auto_button.css("background-image", `url(${this.storages["auto2"]})`);
        });
        Common.on("auto-stop", () => {
            let image_index = "auto";
            if(this.prev_button_image["auto-button"]){
                image_index = this.prev_button_image["auto-button"];
                delete this.prev_button_image["auto-button"];
            }
            auto_button.css("background-image", `url(${this.storages[image_index]})`);
        });
        auto_button.click((e) => {
            if (mist_temp.is_tutorial) return;
            if(this.isDisableButton(auto_button)) { 
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                return false;
            }

            this.onClick(e, "auto");
        });

        
        log_button.on("mousedown touchstart", () => false);
        log_button.hover(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            if(this.isDisableButton(log_button)){ return false; }
            log_button.css("background-image", `url(${this.storages["log2"]})`);
        }, () => {
            if(this.isDisableButton(log_button)){ return false; }
            log_button.css("background-image", `url(${this.storages["log"]})`);
        });
        log_button.click((e) => {
            if (mist_temp.is_tutorial) return;
            if(this.isDisableButton(log_button)) { 
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                return false;
            }

            this.onClick(e, "backlog");
        });

        
        system_button.on("mousedown touchstart", () => false);
        system_button.hover(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            if(this.isDisableButton(system_button)){ return false; }
            system_button.css("background-image", `url(${this.storages["system2"]})`);
        }, () => {
            if(this.isDisableButton(system_button)){ return false; }
            system_button.css("background-image", `url(${this.storages["system"]})`);
        });
        system_button.click((e) => {
            if (mist_temp.is_tutorial) return;
            if(this.isDisableButton(system_button)) { 
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                return false;
            }
            this.onClick(e, "system");
        });

        
        watchValue(mist_save, "detective_mode", this.onChangeMode);
        watchValue(mist_save, "detective_phase", this.onChangePhase);
        watchValue(mist_save, "phaseTiming", this.onChangePhaseTiming);
        watchValue(mist_save, "disp_initial_information", this.onChangeInitialInformation);
        watchValue(mist_save, "is_approaching", this.onChangeIsApproaching);

        
        watchValue(TYRANO.kag.stat, "is_strong_stop", this.onCalledStrongStop);
    }

    
    onClick(e, role) {
        if (mist_temp.is_tutorial) return;
        
        
        const is_clicked_button = e != undefined;
        
        
        if (is_clicked_button && !TYRANO.kag.key_mouse.mouse.isClickEnabled(e)) {
            TYRANO.kag.key_mouse.vmouse.hide();
            return false;
        }

        var is_menu_displayed = $(".layer_menu").css("display") !== "none";
        if(is_menu_displayed){
            const left_content = $("footer-container > left-content");
            if(role === "backlog"){
                const exist_backlog = $(".layer_menu").find("backlog-container").length > 0;
                if(exist_backlog){
                    left_content.find("close-button-q-key").click();
                    return true;
                }
            }else if(role === "system"){
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                const exist_system = $(".layer_menu").find("menu-window,save-window,option-root,help-container").length > 0;
                if(exist_system){
                    
                    const display_systems = $(".layer_menu").find("menu-window,save-window,option-root,help-container");
                    for(let i = 0; i < display_systems.length; ++i) {
                        if(display_systems.eq(i).is(":visible")){
                            
                            const is_call_quit = $(".layer_menu").find("menu-window:visible").length <= 0;
                            if(is_call_quit) {
                                left_content.find("close-button-q-key").click();
                            }
                            TYRANO.kag.menu.hideMenu();
                            return true;
                        }
                    }

                }
            }
        }
        else {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
        }

        var is_event_layer_displayed = TYRANO.kag.layer.layer_event.css("display") !== "none";
        if (role !== "skip" && role !== "auto") {
            
            if (!TYRANO.kag.stat.is_strong_stop && !is_event_layer_displayed) {
                return false;
            }
            if (is_menu_displayed) {
                return false;
            } 
        }
        
        
        if(this.footer_display_data_stack.length == 0){
            return false;
        }

        
        if(!this.footer_display_data_stack[this.footer_display_data_stack.length -1].is_visible_right_content){
            return false;
        }

        
        if(TYRANO.kag.stat.is_hide_message) {
            return false;
        }

        
        
        const tutorial_role = {"skip": "930", "auto": "920", "backlog": "941", "system": "950"};
        if(tutorial_role[role] && !mist_system.tutorial_group[tutorial_role[role]]){
            
            if(!TYRANO.kag.key_mouse.util.canShowMenu()){
                return false;
            }

            
            let group = tutorial_role[role];
            if (role == "backlog" && mist_save.detective_mode) {
                group = "942";
            }

            
            this.e = e;
            this.role = role;
            TYRANO.kag.variable.sf.TutorialDialog.create(group, "", this.onClickTutorialCallback, this);
            return true;
        }else{
            return this.onClickImpl(e, role);
        }
	}

    onClickTutorialCallback(){
        this.onClickImpl(this.e, this.role);
    }
    
    onClickImpl(e, role) {
        
        const is_clicked_button = e != undefined;

        
        if (!TYRANO.kag.tmp.ready_audio) TYRANO.kag.readyAudio();

        
        TYRANO.kag.key_mouse.vmouse.hide();

        
        if(is_clicked_button){
            TYRANO.kag.trigger("click-tag-button-role", e);
        }

        
        if (role !== "skip") TYRANO.kag.setSkip(false);
        
        if (role !== "auto") {
            TYRANO.kag.setAuto(false, true);
        }
        switch (role) {
            case "skip":
                TYRANO.kag.setAuto(false, true);
                if (TYRANO.kag.stat.is_skip) {
                    TYRANO.kag.setSkip(false, {}, true);
                } else {
                    TYRANO.kag.setSkip(true, {}, true);
                    if (TYRANO.kag.layer.layer_event.isDisplayed()) {
                          
                          const img_next = $(".img_next");
                          if(img_next && img_next.length > 0){
                              TYRANO.kag.layer.layer_event.click();
                          }
                    }
                }
                return true;


            case "auto":
                TYRANO.kag.setSkip(false, {}, true);
                if (TYRANO.kag.stat.is_auto) {
                    TYRANO.kag.setAuto(false, true);
                } else {
                    if (TYRANO.kag.layer.layer_event.isDisplayed()) {
                        TYRANO.kag.layer.layer_event.click();
                    }
                    TYRANO.kag.setAuto(true, true);
                }
                return true;

            case "backlog":
                TYRANO.kag.menu.displayLog();
                return true;
            
            case "system":
                TYRANO.kag.menu.showMenu();
                return true;
        }

        return false;
    }

    
    show_base() {
        this.footer_display_data_stack[this.footer_display_data_stack.length - 1].is_visible_footer_base = true;
        $("footer-container").css("background-image",`url(${this.storages["background"]})`);
    }

    
    hide_base() {
        this.footer_display_data_stack[this.footer_display_data_stack.length - 1].is_visible_footer_base = false;
        $("footer-container").css("background-image",`url(${this.storages["noimage"]})`);
    }

    
    onChangeMode(oldValue, newValue) {
        mist_system.FooterContainer.onChageFooter(newValue, mist_save.detective_phase, mist_save.phaseTiming, mist_save.disp_initial_information, mist_save.is_approaching);
    }
  
    onChangePhase(oldValue, newValue) {
        mist_system.FooterContainer.onChageFooter(mist_save.detective_mode, newValue, mist_save.phaseTiming, mist_save.disp_initial_information, mist_save.is_approaching);
    }
  
    onChangePhaseTiming(oldValue, newValue) {
        mist_system.FooterContainer.onChageFooter(mist_save.detective_mode, mist_save.detective_phase, newValue, mist_save.disp_initial_information, mist_save.is_approaching);
    }
  
    onChangeInitialInformation(oldValue, newValue) {
        mist_system.FooterContainer.onChageFooter(mist_save.detective_mode, mist_save.detective_phase, mist_save.phaseTiming, newValue, mist_save.is_approaching);
    }
  
    onChangeIsApproaching(oldValue, newValue) {
        mist_system.FooterContainer.onChageFooter(mist_save.detective_mode, mist_save.detective_phase, mist_save.phaseTiming, mist_save.disp_initial_information, newValue);
    }

    onChageFooter(isDetective, phase, phaseTiming, initialInformation, isApproaching) {
        if(isDetective) {
            if(initialInformation || isApproaching) {
                this.showDetectiveAdvFooter();
            }
            else {
                switch(phase) {
                    case "investigate":
                        if(phaseTiming == "select_talk") {
                            this.showInvestigationCharaSelectFooter();
                        }
                        else if(phaseTiming == "secret") {
                            this.showInvestigationSecretFooter();
                        }
                        break;
                    case "debate":
                        this.showDebateFooter();
                        break;
                    case "vote":
                        this.showVoteFooter();
                        break;
                }
            }
        }
        else {
            this.showAdvFooter();
        }
    }

    noteButton(){
        const content = $("footer-container > left-content");
        const noteButton = content.find("note-button");
        
        if(noteButton.length > 0 && noteButton.is(':visible')) {
            return noteButton.eq(0);
        }
        return undefined;
    }

    closeButton() {
        const content = $("footer-container > left-content");
        const closeButton = content.find("close-button");
        
        if(closeButton.length > 0 && closeButton.is(':visible')) {
            return closeButton.eq(0);
        }
        return undefined;
    }
    
    
    openNote() {
        if(!TYRANO.kag.key_mouse.util.canShowMenu()){
            console.warn("今は開けません");
            return ;
        }
        Common.unfocusKey();
        
        const tutorial_id = "910";
        if(!mist_system.tutorial_group[tutorial_id]){
            
            TYRANO.kag.variable.sf.TutorialDialog.create(tutorial_id, "", this.openNoteImpl, this);
        }else{
            Common.addPreventScene("Note");
            this.openNoteImpl();
        }

    }

    
    openNoteImpl() {
        mist_save.doubt_filter = null;
        mist_save.enableShowInference = false;
        mist_system.NoteContainer2.setCloseButtonLable(undefined);
        mist_save.detective_select_index = -2; 
        mist_system.NoteContainer2.createView();
    }
    
    closeNote() {
        mist_system.NoteContainer2.clearUsedData();
        mist_system.NoteContainer2.clearContainer();
        this.offNoteEvent();
        Common.removePreventScene("Note");
        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys14.mp3", stop: true });
    }

    
    activeImpl(button_name, baseimage){
        const button = $("footer-container").find(button_name);
        if(!button) { return; }
        let file_path = button.css("background-image");
        if(!file_path) { return ; }
        const file = Common.getFilename(file_path);
        const target_files = [Common.getFilename(this.storages[`${baseimage}3`])];
        if(target_files.includes(file)){
            if(this.prev_button_image[button_name]) {
                baseimage = this.prev_button_image[button_name];
                delete this.prev_button_image[button_name];
            }
            button.css("background-image", `url(${this.storages[baseimage]})`);
        }
    }

    
    deactiveImpl(button_name, baseimage){
        const button = $("footer-container").find(button_name);
        if(!button) { return; }
        let file_path = button.css("background-image");
        if(!file_path) { return ; }
        const file = Common.getFilename(file_path);
        const target_files = [Common.getFilename(this.storages[baseimage]), Common.getFilename(this.storages[`${baseimage}2`])];
        if(target_files.includes(file)){
            const idx = target_files.indexOf(file);
            this.prev_button_image[button_name] = idx == 0 ? baseimage : `${baseimage}2`;
            button.css("background-image", `url(${this.storages[`${baseimage}3`]})`);
        }
    }

    
    active(ignore_check_skip=false) {
        clearTimeout(this.deactive_timeout_id);
        this.deactive_timeout_id = 0;
        setTimeout(() => {
            this.activeImpl("auto-button", "auto");
            this.activeImpl("skip-button", "skip");
            if(TYRANO.kag.key_mouse.util.canShowMenu()){
				if(!ignore_check_skip && TYRANO.kag.stat.is_skip){ return ; }
                this.activeImpl("log-button", "log");
                this.activeImpl("system-button", "system");
            }
        }, 0);
    }

    
    deactive() {
        const wait_time = 300;
        clearTimeout(this.deactive_timeout_id);
        this.deactive_timeout_id = 0;
        if(TYRANO.kag.stat.f.detective_mode){ return; }
        this.deactive_timeout_id = setTimeout(() => {
            
            if(!TYRANO.kag.stat.is_skip ){
                this.deactiveImpl("skip-button", "skip");
            }else{
               this.prev_button_image["skip-button"]= `skip3`;
            }
            if(!TYRANO.kag.stat.is_auto ){
                this.deactiveImpl("auto-button", "auto");
            }else{
                this.prev_button_image["auto-button"] = `auto3`;
            }

            if(!TYRANO.kag.key_mouse.util.canShowMenu()){
                this.deactiveImpl("log-button", "log");
                this.deactiveImpl("system-button", "system");
            }
        }, wait_time);
    }

    
    isDisableButton(button){
        let file_path = button.css("background-image");
        if(!file_path) { return false; }
        const file = Common.getFilename(file_path);
        if(file.includes("3")){
            return true;
        }
        return false;
    }

    
    isActiveButton(button_name){
        const container = $("footer-container");
        if(container.css("display") == "none"){ return false; }
        const button = container.find(button_name);
        if(!button) { return false; }
        if(button.css("visibility") == "hidden"){ return false; }
        if(this.isDisableButton(button)){ return false; }
        return true;
    }

    isActiveAutoButton(){
        return this.isActiveButton("auto-button");
    }
    isActiveSkipButton(){
        return this.isActiveButton("skip-button");
    }
    isActiveLogButton(){
        return this.isActiveButton("log-button");
    }
    isActiveSystemButton(){
        return this.isActiveButton("system-button");
    }

    onCalledStrongStop(oldValue, newValue){
        if(newValue){
            
            mist_system.FooterContainer.prev_button_image = {};
            mist_system.FooterContainer.active(true);
        }else{
            
            mist_system.FooterContainer.setSkipMode();
        }
    }

    
    setSkipMode(){
        if(TYRANO.kag.stat.is_skip){
            
            this.deactiveImpl("log-button", "log");
            this.deactiveImpl("system-button", "system");
        }
    }
}

Common.sfAddClass(new FooterContainer());
