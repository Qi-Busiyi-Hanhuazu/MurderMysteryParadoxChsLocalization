
class SelectContainer {
    load() {
        const container = $('mist-select-container');
        const id = container.attr("id");
        if (container.length == 0) return;

        const exsitSystem = mist_system.readed && (id in mist_system.readed);
        if(!("readed" in mist_save)) {
            mist_save.readed = {};
        }
        else if(!(id in mist_save.readed) && exsitSystem) {
            mist_save.readed[id] = []
            
            const count = mist_system.readed[id].length;
            for(let i = 0; i < count; ++i) {
                mist_save.readed[id].push(mist_system.readed[id][i]);
            }
        }
        else if(exsitSystem) {
            
            const count = mist_system.readed[id].length;
            for(let i = 0; i < count; ++i) {
                if(mist_save.readed[id].length > i) {
                    mist_save.readed[id][i] = mist_save.readed[id][i] || mist_system.readed[id][i];
                }
                else {
                    mist_save.readed[id].push(mist_system.readed[id][i]);
                }
            }
        }

        const that = this;
        let is_first = true;
        container.find("mist-select").each(function(i) {
            const is_readed = mist_save.readed && mist_save.readed[id][i] ? mist_save.readed[id][i] : false;
            that.addEvent($(this), is_readed, i);
            if (is_first) {
                Common.setFocus($(this));
                is_first = false;
            }
        });
    }

    
    create(id) {
        
        const elem = $(`<mist-select-container id="${id}"><mist-select-contents></mist-select-contents></mist-select-container>`);
        
        const layer = TYRANO.kag.layer.getFreeLayer();
        layer.append(elem);
        layer.show();
        mist_system.FooterContainer.setBackMode(6);
    }

    
    setBlur(blur) {
        let elem = $('mist-select-container');
        elem.css("backdrop-filter", `blur(${blur}px)`);
    }

    
    addEvent(select_elem, is_readed, index) {
        const line_elem = select_elem.find("line");
        const cursor_elem = select_elem.find("cursor");
        const readed_elem = select_elem.find("readed");
        Common.setVisible(line_elem, false);
        Common.setVisible(cursor_elem, false);
        Common.setVisible(readed_elem, is_readed);
        if(is_readed && !select_elem.hasClass("readed")) {
            select_elem.addClass("readed");
        }

        select_elem.hover(() => {
            mist_temp.last_select_element = select_elem;
            Common.setVisible(line_elem, true);
            select_elem.addClass("selected");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            Common.setVisible(line_elem, false);
            Common.setVisible(cursor_elem, false);
			select_elem.removeClass("selected");
        });
        select_elem.click((e) => {
            if (mist_temp.is_tutorial) return;
            
            mist_system.FooterContainer.setBackMode(0);
            Common.setVisible(cursor_elem, true);
            select_elem.off();
            select_elem.siblings().off();
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
        });

        Common.makeFocusable(select_elem, index);
    }

    
    addSelect(text, is_readed, is_first) {
        const container = $('mist-select-container > mist-select-contents');
        if (container.length == 0) return undefined;

        const elem = $(`
            <mist-select class='${is_readed ? "readed" : ""}'>
                <text>${text}</text>
                <readed></readed>
                <line></line>
                <cursor></cursor>
            </mist-select>`);
        container.append(elem);

        const index = $('mist-select').length;
        this.addEvent(elem, is_readed, index);
        if (is_first) {
            Common.setFocus(elem);
        }

        return elem;
    }

    footerBack() {
        if (mist_temp.last_select_element != undefined) {
            Common.setFocus(mist_temp.last_select_element);
        }
    }

    countSelect() {
        return $('mist-select-container > mist-select-contents mist-select').length;
    }
}
Common.sfAddClass(new SelectContainer());
