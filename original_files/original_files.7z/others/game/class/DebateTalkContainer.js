
class DebateTalkContainer
{
    constructor()
    {
        
        this.container_class = "debate-talk-container";
        this.move_container_class = "debate-talk-move-container";
        this.talk_class = "talk_window";
        
        this.container_selector = `.message9_fore > .${this.container_class}`;
        this.move_container_selector = `${this.container_selector} > .${this.move_container_class}`;
        this.talk_selector = `${this.move_container_selector} > .${this.talk_class}`;
    }

    
    createContainer()
    {
        
        let is_create_base = $(this.container_selector).length <= 0;
        if(is_create_base)
        {
            $(".message9_fore").append(`
            <div class="${this.container_class}">
                <div class="${this.move_container_class}">
                </div>
            </div>`);
            $(".message9_fore").find(".message_outer").css("opacity", 0);
            $(".message9_fore").find(".message_inner").css("opacity", 0);
            $(".message9_fore").find(".message_inner").addClass("message_inner_original");
            $(".message9_fore").find(".message_inner").removeClass("message_inner");

            $(".message10_fore").css("text-align", "center");
            $(".message10_fore").find(".message_inner").css({"display":"flex", "align-items":"center", "justify-content":"center"});
        }
        $(".message10_fore").css("z-index", 1000);
        $(`.${this.container_class}`).css("height", 520);
    }

    
    copyMessage()
    {
        
        let inner = $(this.talk_selector).first().find("inner");
        inner.append(inner.find(".message_inner").clone());

        var disp_message = inner.find(".message_inner").eq(1);
        
        disp_message.addClass("disp_message");
        disp_message.removeClass("message_inner");
        disp_message.find(".current_span").removeClass("current_span");
        
        
        disp_message.css("opacity", 0);
    }

    
    deleteMessage()
    {
        
        let inner = $(this.talk_selector).first().find("inner");
        inner.find(".message_inner").remove();
        inner.find(".disp_message").css("opacity", 1);
    }


    
    clearTalkWindow()
    {
        $(this.talk_selector).remove();
    }

    
    createTalkWindow(mono, page_mode)
    {
        const player_name = "主人公";
        let chara_name = Common.getCharaName();

        const { unused_window_type, unused_css_transform, css_color } = this._getBallonStyle(mono);
        mist_save.window_font_color = css_color;


        if(!(chara_name in mist_save.st_chara_position))
        {
            mist_save.control_layer = "message10";
            mist_save.page_mode = page_mode || "fore";
            return;
        }


        const window_type = (chara_name == player_name && mono) ? "monologue-window" : "normal-window";
        let message_layer = $(".message9_fore");
        let move_container = $(this.move_container_selector);

        let prev_window = move_container.children().first();
        prev_window.css("filter", "brightness(0.5)");
        prev_window.css("transform", "scale(0.85)");
        prev_window.css("transition-property", "transform");
        prev_window.css("transition-duration", "300ms");
        let talk_windows = $(this.talk_selector);

        
        
        
        
        

        move_container.prepend(`
            <${window_type} class="${this.talk_class}">
                <inner></inner>
            </${window_type}>`);
        let talk_window = $(this.talk_selector).first();
        const { left, top } = this._getTalkPosition(chara_name, talk_window.width(), window_type);
        talk_window.css("left", left);
        talk_window.css("top", top);
        talk_window.css("transform", "scale(1.0)");
        talk_window.css("z-index", move_container.children().length);


        let inner = talk_window.find("inner");
        inner.append(message_layer.children(".message_inner_original").clone());
        var message_inner = inner.find(".message_inner_original");
        message_inner.removeClass("message_inner_original");
        message_inner.addClass("message_inner");
        message_inner.css("opacity", 1);
        message_inner.css("width", inner.css("width"));
        message_inner.css("height", inner.css("height"));

        
        let line_count = mist_save.line_count;
        if(talk_windows.length > line_count)
        {
            talk_windows.eq(line_count).remove();
            talk_windows.each(function(index) {
                $(this).css("z-index", talk_windows.length - index);
            });
        }

        mist_save.control_layer = "message9";
        mist_save.page_mode = page_mode || "fore";

        this._moveAnimation(move_container);
    }

    
    _getTalkPosition(chara_name, width, window_type)
    {
        let left = mist_save.st_chara_position[chara_name];
        let top = -10;

        left -= width / 2;
        if (left < 0)
        {
            left = 50;
            top = -10;
            if(window_type == "monologue-window")
            {
                left = 60;
                top = -15;
            }
        }
        else if(left + width > 1920)
        {
            left = 1920 - width + -50;
            top = -10;
        }

        return {
            left: left,
            top: top,
        }
    }

    
    _scrollBottom()
    {
        let container = $(this.container_selector);
        container.scrollTop(container.get(0).scrollHeight);
    }

    
    _moveAnimation(move_container)
    {
        if (move_container.children().length == 1) return;
        
        if(move_container.is(':animated')){
            move_container.stop(true, true);
        }

        this._scrollBottom();

        const elem = move_container.children().first();
        const height = elem.outerHeight(true);
        
        move_container.css("top", height);
        
        move_container.animate({
            top: "0px",
        }, 300);
    }

    
    _getBallonStyle(is_monologue)
    {
        const chara_name = Common.getCharaName();
        const player_name = "主人公";
        let window_type = "pc-window";
        let scale = "scale(1.0)";
        let translate = "translate(50px, 0px)";
        let css_color = "0xFFFFFF";
        if(chara_name == '')
        {
            translate = "";
            window_type = "info-window";
            css_color = "0x000000";
        }
        else if(chara_name != player_name)
        {
            translate = "translate(-50px, 0px)";
            window_type = "npc-window";
        }
        else if(chara_name == player_name && is_monologue)
        {
            translate = "translate(50px, -5px)";
            window_type ="pc-window-monologue";
        }

        return {
            window_type: window_type,
            css_transform: `${scale} ${translate}`,
            css_color: css_color,
        };
    }


}

Common.sfAddClass(new DebateTalkContainer());
