
class GalleryView {

    constructor(call_back) {
        const preload_list = [
            "data/image/chapter/new.png",
            "data/image/detective/common/dummy.png",
            "data/image/chapter/frame.png",
            "data/image/chapter/frame_hover.png",
            "data/image/chapter/frame_select.png",
            "data/image/chapter/frame_select_hover.png",
            "data/image/chapter/frame_grayout.png",
            "data/image/chapter/scotch_tape.png",
            "data/image/chapter/nodata.png",
            "data/image/chapter/thumbnail_shadow.png",
            "data/image/chapter/movie_start.png",
        ];

        masterdata.note_album.forEach(x => {
            preload_list.push(x.thumbnail);
        });

        Common.preloadAll(preload_list, () => {
            this.create(call_back);
            this.addEvent();
        });
    }

    
    create(call_back)
    {
        const that = this;
        let elem = $('gallery-container > content > items');
        if (!mist_system.albums) mist_system.albums = [];

        const release_extra = mist_system.chapters["extra"].is_release;

        const active_album = masterdata.note_album.filter(x => release_extra || x.ignore_complete.toLowerCase() != "true");
        active_album.forEach(x => {
            const item = mist_system.albums.find(album => album.id == x.id);
            if(item) {
                const html = $(`
                    <item type="${x.id}">
                        <thumbnail class="shadow">
                            <thumbnail-image style="background-image: url(./${x.thumbnail});"></thumbnail-image>
                            <tape></tape>
                            <new></new>
                            ${x.type == "movie" ? "<play></play>" : ""}
                            <no>No.${x.no}</no>    
                        </thumbnail>
                        <chapter>${x.chapter}</chapter>
                        <title>${x.title}</title>
                    </item>`);
                elem.append(html);
                Common.setVisible(html.find('new'), item.is_new);
            }
            else {
                const html = $(`
                    <item type="${x.id}">
                        <thumbnail>
                            <no>No.${x.no}</no>    
                        </thumbnail>
                        <chapter>${x.chapter}</chapter>
                        <title>？</title>
                    </item>`);
                elem.append(html);
            }
        });

        
        const count_elem = $("gallery-container").find("total-count");
        count_elem.text(`集めた数 ${mist_system.albums.length} / ${active_album.length}`);

        var layer_menu = TYRANO.kag.layer.getMenuLayer();
        const close_event = function(e){
            that.focusManager.unregisterFocus();
            layer_menu.hide();
            layer_menu.empty();
            mist_system.FooterContainer.back();
            e.stopPropagation();
            if (typeof call_back == "function") {
                call_back();
            }
        };
        const footer_display_data = {
            is_visible_close_button_q_key:true,
            close_event_q_key:close_event,
            help_text:getCommonHelpDirect("gallery")
        };
        mist_system.FooterContainer.showCollectionFooter(footer_display_data);

        
        if(!mist_system.open_collection) {
            mist_system.open_collection = true;
            Common.saveSystem();
        }
    }

    
    addEvent()
    {
        const that = this;
        let elem_list = [];
        let count = 0;
        $('items > item').each(function() {
            let elem = $(this);
            elem_list.push(elem);
            elem.off();
            elem.click(() => {
                if (mist_temp.is_tutorial) return;
                that.focusManager.unregisterFocus();
                

                const select_id = $(this).attr("type");
                let item = mist_system.albums.find(x => x.id == select_id);
                if(item === undefined) {
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                    setTimeout(() => {
                        that.focusManager.setLastFocus();
                    }, 30);
                    return;    
                }
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                item.is_new = false;
                Common.setVisible(elem.find('new'), item.is_new);
                
                Common.saveSystem();

                elem.addClass("select");
                const data = masterdata.note_album.find(master_album => master_album.id == select_id);
                switch (data.type) {
                    case "still":
                        that.createEventWindow(data.id, () => {
                            that.focusManager.registerFocus();
                            that.focusManager.setLastFocus();
                        });
                        break;

                    case "movie":
                        pauseBgm();
                        Common.playMovie({
                            layer: TYRANO.kag.layer.getMenuLayer(),
                            storage: `${data.id}.mp4`,
                            volume: `${mist_system.bgm_volume}`,
                            onComplete: () => {
                                $('items > item').removeClass("select");
                                resumeBgm();
                                that.focusManager.registerFocus();
                                that.focusManager.setLastFocus();
                            }
                        });
                        break;
                }
            });
            const index = count;
            elem.hover(() => {
                elem.addClass("hover");
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                that.focusManager.setLastIndex(index);
            }, () => {
                elem.removeClass("hover");
            });
            ++count;
        });

        const max_column = 4;
        let index_list = [];
        const max_y = Math.floor((elem_list.length - 1) / max_column) + 1;
        for (let i = 0; i < elem_list.length; ++i) {
            const x = i % max_column;
            const y = Math.floor(i / max_column);
            const base_x = y * max_column;

            let top = ((y + max_y - 1) % max_y) * max_column + x;
            let bottom = (y + 1) % max_y * max_column + x;
            let left = base_x + (x + max_column - 1) % max_column;
            let right = base_x + (x + 1) % max_column;

            if (top >= elem_list.length) {
                top = ((y + max_y - 2) % max_y) * max_column + x;
            }
            if (bottom >= elem_list.length) {
                bottom = x;
            }
            if (left >= elem_list.length) {
                left = elem_list.length - 1;
            }
            if (right >= elem_list.length) {
                right = base_x;
            }
            
            index_list.push([top, bottom, left, right]);
        }

        this.focusManager = new FocusManager("gallery", elem_list, index_list);
    }

    
    createEventWindow(id, call_back)
    {
        const window = $(`
            <gallery-event-window style="background-image:url(./data/bgimage/${id}.png)">
            </gallery-event-window>`);
        const layer = TYRANO.kag.layer.getMenuLayer();
        layer.append(window);

        const album_event = $("gallery-event-window");
        const close_event = () => {
            if (mist_temp.is_tutorial) return;
            
            mist_system.FooterContainer.back();
            $('items > item').removeClass("select");
            $('gallery-event-window').remove();
            call_back();
        };

        window.click((e) => {
            e.stopPropagation();
            window.off();
            close_event();
        });

        mist_system.FooterContainer.showDialogFooter({
            close_event_q_key: close_event,
            is_visible_footer_base: true
        });
    }
}