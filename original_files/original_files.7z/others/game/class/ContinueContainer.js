
class ContinueContainer
{
    constructor() {
        mist_temp.continue_last_select_index = 0;
     }

    load()
    {
        mist_temp.continue_last_select_index = 0;
        const container = $("continue-container");
        if(container.length == 0) return;
        this.addEvent(container);
    }

    remove() {
        const container = $("continue-container");
        if(container.length == 0) return;
        container.remove();
        mist_system.FooterContainer.hide();
    }

    
    addEvent(elem)
    {
        this.cells = elem.find("cell");
        
        for(let i = 0; i < this.cells.length; ++i) {
            const cell = this.cells.eq(i);
            cell.click(function(e) {
                if (mist_temp.is_tutorial) return;
                
                e.stopPropagation();
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                Common.setVisible(cell.find("cursor"), true);
                const target = cell.attr("type");
                if(target != "*OpenLoad"){
                    cell.off();
                    cell.siblings().off();
                } else {
                    mist_temp.is_continue_load = true;
                }
                setTimeout(function(){
                    restartGameProgress();
                    TYRANO.kag.ftag.startTag("jump", { target: target });
                }, Common.durationSelected());
            });
            const index = i;
            cell.hover(() => {
                Common.setVisible(cell.find("line"), true);
                cell.addClass("selected");
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                mist_temp.continue_last_select_index = index;
            }, () => {
                cell.removeClass("selected");
                Common.setVisible(cell.find("line"), false);
                Common.setVisible(cell.find("cursor"), false);
            });
            Common.makeFocusable(cell);
        }
        Common.setFocus(this.cells.eq(mist_temp.continue_last_select_index));

        
        mist_system.DetectiveContainer.remove();
        mist_system.SecretTalkContainer.removeContainer();
    }

    backLoad() {
        Common.setFocus(this.cells.eq(mist_temp.continue_last_select_index));        
    }

    
    setSetting(id, select_id, is_skip, is_vote, is_debate, is_secret_talk, help = "", select_title="", use_flag=false)
    {
        const master = masterdata.continue.find(x => x.id == id);
        if (master === undefined) {
            console.error(`コンティニューのマスターデータにid: [${id}]が存在しません。`);
            return;
        }

        mist_save.continue = {
            id: id,
            select_id: select_id ? select_id : "",
            is_skip: Common.toBool(is_skip),
            is_vote: Common.toBool(is_vote),
            is_debate: Common.toBool(is_debate),
            is_secret_talk: Common.toBool(is_secret_talk),
            help: help,
			select_title: select_title,
            use_flag: Common.toBool(use_flag)
        };
    }

    
    getContinueRecommend()
    {
        return 3; 
        
        let low_credit_count = 0;
        const credit_lv = 0;
        getCharacterList().forEach((chara) => {
            if(chara.credit_level <= credit_lv){
                low_credit_count += 1;
            }
        });

        
        if(low_credit_count >= (getCharacterList().length / 2)) {
            return 1;
        }

        let high_convinve_count = 0;
        const convince_lv = requireConvincingLevelDoubt();
        getResolvedDoubtIds().forEach((id) => {
            const doubt = getDoubt(id);
            if(doubt != null && doubt.isAnswerFull()) {
                let inference = getInferenceFromDoubt(doubt);
                if(compareConvinceLevelStr(inference.convince_level, convince_lv)){
                    high_convinve_count += 1;
                }
            }
        });

        const require_convince_high_count = 3;
        if(high_convinve_count >= require_convince_high_count) {
            return 3;
        } else {
            return 2;
        }
    }

    
    create(is_adv = true)
    {
        
        const tutorial_id = is_adv ? "711" : "710";
        if(!mist_system.tutorial_group[tutorial_id]){
            
            this.is_adv = is_adv;
            TYRANO.kag.variable.sf.TutorialDialog.create(tutorial_id, "", this.createImpl, this, false);
        }else{
            this.createImpl(is_adv)
        }
    }

    
    createImpl(is_adv)
    {
        if(is_adv == void 0) {is_adv = this.is_adv; }
        const layer = TYRANO.kag.layer.getFreeLayer();
        layer.show();

        if (mist_save.continue === undefined) {
            console.error(`[SET_CONTINUE]で設定されてないようです。`);
            return;
        }
        const id = mist_save.continue.id;
        if (id === undefined) {
            console.error(`[SET_CONTINUE]で設定されてないようです。`);
            return;
        }
        const master = masterdata.continue.find(x => x.id == id);
        if (master === undefined) {
            console.error(`コンティニューのマスターデータにid: [${id}]が存在しません。`);
            return;
        }
        let cells = "";
        if (is_adv)
        {
           
            if (mist_save.continue.is_skip) {
                cells += `<cell type="*ConfirmJumpNext" class="tyrano-focusable" tabindex="-1"><text>- <span>やり直さず</span>先に進む</text><line></line><cursor></cursor></cell>`;
            }
            if (mist_save.continue.select_id != "") {
                cells += `<cell type="*ConfirmJumpSelect" class="tyrano-focusable" tabindex="-1"><text>- <span>直前の選択肢</span>からやり直す</text><line></line><cursor></cursor></cell>`;
            }
            if (mist_save.continue.is_secret_talk) {
                cells += `<cell type="*ConfirmSecretTalk" class="tyrano-focusable" tabindex="-1"><text>- <span>調査フェーズ</span>からやり直す</text><line></line><cursor></cursor></cell>`;
            }

            if (mist_save.continue.is_debate) {
                cells += `<cell type="*ConfirmJumpDebate" class="tyrano-focusable" tabindex="-1"><text>- <span>全体議論フェーズ</span>からやり直す</text><line></line><cursor></cursor></cell>`;
            }

            if (mist_save.continue.is_vote) {
                cells += `<cell type="*ConfirmJumpVote" class="tyrano-focusable" tabindex="-1"><text>- <span>投票フェーズ</span>からやり直す</text><line></line><cursor></cursor></cell>`;
            }
        } else {
            let num = this.getContinueRecommend();
			TYRANO.kag.stat.f.continue_recomend = num;
            const mc = mist_save.continue;
        
            cells += `<cell type="*ConfirmDetectiveResult" class="tyrano-focusable" tabindex="-1"><text>- <span>プレイ結果</span>をもう一度確認する</text><line></line><cursor></cursor></cell>`;
            if(mc.use_flag == false || (mc.use_flag && mc.is_secret_talk))
            {
                cells += `<cell type="*ConfirmSecretTalk" class="tyrano-focusable" tabindex="-1"><text>- <span>調査フェーズ</span>からやり直す</text><line></line><cursor></cursor></cell>`;
                mist_save.continue.help = helpMessage('continue_msg1').text;
            }
            if(mc.use_flag == false || (mc.use_flag && mc.is_debate))
            {
                cells += `<cell type="*ConfirmJumpDebate" class="tyrano-focusable" tabindex="-1"><text>- <span>全体議論フェーズ</span>からやり直す</text><line></line><cursor></cursor></cell>`;
                mist_save.continue.help = helpMessage('continue_msg2').text;
            }
            if(mc.use_flag == false || (mc.use_flag && mc.is_vote))
            {
                cells += `<cell type="*ConfirmJumpVote" class="tyrano-focusable" tabindex="-1"><text>- <span>投票フェーズ</span>からやり直す</text><line></line><cursor></cursor></cell>`;
                mist_save.continue.help = helpMessage('continue_msg3').text;
            }
            if (mc.select_id != "" && mc.select_title != "")
            {
                cells += `<cell type="*ConfirmJumpSelect" class="tyrano-focusable" tabindex="-1"><text>- <span>${mist_save.continue.select_title}</span>からやり直す</text><line></line><cursor></cursor></cell>`;
            }

            if(mc.use_flag == false || (mc.use_flag && mc.is_skip))
            {
                cells += `<cell type="*ConfirmJumpNext" class="tyrano-focusable" tabindex="-1"><text>- <span>やり直さず</span>先に進む</text><line></line><cursor></cursor></cell>`;
            }
        }
        cells += `<space></space><cell type="*OpenLoad" class="tyrano-focusable" tabindex="-1"><text>- <span>ロード</span></text><line></line><cursor></cursor></cell>`;
        cells += `<space></space><cell type="*ConfirmJumpTitle" class="tyrano-focusable" tabindex="-1"><text>- <span>タイトル</span>へ戻る</text><line></line><cursor></cursor></cell>`;

        const container = $(`
            <continue-container>
                <grid>
                    <title></title>
                    <content>
                        ${cells}
                    </content>
                </grid>
            </continue-container>`);
        layer.append(container);
        
        
        Common.setVisible(container.find("line"), false);
        Common.setVisible(container.find("cursor"), false);

        this.addEvent(container);
        mist_system.FooterContainer.showContinueFooter();
        
        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("help_continue") });

        
        
        
        
        
        
        
        
        
        
        
        
    }

    
    selectJump(type)
    {
        const id = mist_save.continue.id;
        const storage = (() =>
        {
            const master = masterdata.continue.find(x => x.id == id);
            switch (type)
            {
                case "skip": return master.skip_path;
                case "vote": return master.vote_path;
                case "debate": return master.debate_path;
                case "secret_talk": return master.secret_talk_path;
                case "title":
                default: 
                    return "detective/transition/return_title.ks";
            }
        })();

        mist_system.FooterContainer.back();
        TYRANO.kag.ftag.startTag("jump", { storage: storage  });
        if(!mist_temp.optionNowStopping) {
            restartGameProgress(mist_temp.optionCallNextOrder);
            mist_temp.optionCallNextOrder = false;
        }
        mist_temp.optionNowStopping = false;
        this.remove();
    }
}

Common.sfAddClass(new ContinueContainer());
