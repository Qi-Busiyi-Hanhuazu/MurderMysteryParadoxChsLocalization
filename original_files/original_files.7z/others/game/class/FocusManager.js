
class FocusManager {
    
    constructor(key, list, index_list, index = 0, on_change_value = undefined) {
        this.key = key;
        this.list = list;
        this.index_list = index_list;
        this.last_index = index;
        this.on_change_value = on_change_value;
        this.key_down_left = false;
        this.key_down_right = false;
        this.active_focus_event = true;
        
        this.uncontrollable = false;

        this.registerFocus();
        this.setFocusIndex(index);
    }

    registerFocus() {
        var that = this;
        this.list.forEach((elem) => {
            Common.makeFocusable(elem);
        });
        Common.registerFocus(this.key,
            function() {
                
                return that.active_focus_event && that.setFocus(0);
            }, function() {
                
                return that.active_focus_event && that.setFocus(1);
            }, function() {
                
                that.key_down_left = true;
                setTimeout(function () {
                    that.key_down_left = false;
                }, 10);
                return that.active_focus_event && that.setFocus(2);
            }, function() {
                
                that.key_down_right = true;
                setTimeout(function () {
                    that.key_down_right = false;
                }, 10);
                return that.active_focus_event && that.setFocus(3);
            }
        );
    }

    unregisterFocus() {
        this.list.forEach((elem) => {
            Common.makeUnfocusable(elem);
        });
        Common.unregisterFocus(this.key);
    }

    setLastFocus() {
        this.setFocusIndex(this.last_index);
    }

    setLastIndex(index) {
        this.last_index = index;
    }

    setFocusIndex(index) {
        this.resetSelectFocusView();
        if (0 > index || index >= this.list.length) {
            return;
        }

        this.last_index = index;
        var item = this.list[index];
        if (item != undefined && item.length > 0) {
            Common.setFocus(item);
        }
        if (typeof this.on_change_value == "function") {
            this.on_change_value(index);
        }
    }

    setFocus(dir) {
        if (this.index_list.length <= this.last_index) {
            this.uncontrollable = true;
            return false;
        }
        if (this.index_list[this.last_index].length <= dir) {
            this.uncontrollable = true;
            return false;
        }
        const index = this.index_list[this.last_index][dir];
        if (index == -1) {
            this.uncontrollable = true;
            return false;
        }
        if (index == this.last_index) {
            this.uncontrollable = false;
            return true;
        }

        this.uncontrollable = false;
        this.resetSelectFocusView();
        const item = this.list[index];
        this.last_index = index;
        if (item != undefined && item.length > 0) {
            Common.setFocus(item);
        }
        if (typeof this.on_change_value == "function") {
            this.on_change_value(index);
        }
        return true;
    }

    resetSelectFocusView() {
        this.list.forEach((elem) => {
            elem.trigger("mouseleave");
        });
    }

    isKeyDownLeftRight() {
        return this.key_down_left || this.key_down_right;
    }

    getLastIndex() {
        return this.last_index;
    }
    
    setActiveFocusEvent(is_active) {
        this.active_focus_event = is_active;
    }
}
