
class HelpView
{
    
    create(set_footer_func)
    {
        const container = $(".help-container");
        
        mist_temp.hover_index = -1;
        mist_temp.is_help_key_scroll = false;

        
        const sf = TYRANO.kag.variable.sf;
        if (!sf.helps)
        {
            $('.help-left').remove();
            $('.help-right').remove();
            return;
        }

		
        $('.help-bottom-marquee').text(getCommonHelpDirect('help_scene'));
        this.addLeftUI();
        const that = this;
        const elm_item = container.find("item");
        elm_item.off();

        
        elm_item.hover(function() {
            Common.setVisible($(this).find("line"), true);
            $(this).find("text").addClass("selected");
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys05.mp3", stop:true });
            that.focusManager.setLastIndex(elm_item.index($(this)));
        }, function() {
            const index = elm_item.index($(this));
            if (mist_temp.hover_index == index) {
                mist_temp.hover_index = -1;
                $(this).trigger("mouseenter");
                return;
            }

            Common.setVisible($(this).find("line"), false);
            $(this).find("text").removeClass("selected");
        });

        that.isHelpDetail = false;
        
        elm_item.click(function(e) {
            if (mist_temp.is_tutorial || that.isHelpDetail) return;
            e.stopPropagation();
            Common.setBlock(true);
            Common.setVisible($(this).find("line"), true);
            Common.setVisible(elm_item.find("cursor"), false);
            Common.setVisible($(this).find("cursor"), true);
            
            const id = $(this).attr("help_id");
            const group = $(this).attr("group");
            let help = masterdata.help[group].find(x => x.id == id);
            sf.helps[id].is_new = false;
            Common.setVisible($(this).find('icon-new'), sf.helps[id].is_new);
            mist_temp.hover_index = elm_item.index($(this));

            setTimeout(() => {
                Common.setBlock(false);
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                that.updateRightUI(help);
            }, Common.durationSelected());
        });

        
        let focus_list = [];
        let focus_index_list = [];
        elm_item.each(function(index, elem){
           focus_list[index] = $(elem);
           const up = (index + elm_item.length - 1) % elm_item.length;
           const down = (index + 1) % elm_item.length;
           focus_index_list[index] = [up, down];
        });
        that.focusManager = new FocusManager("help", focus_list, focus_index_list);
        that.registerWheel(elm_item);

        
        const icon =  container.find("icon");
        icon.hover(function() {
            $(this).addClass("select");
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys05.mp3", stop:true });
        }, function() {
            $(this).removeClass("select");
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys05.mp3", stop:true });
        });
        icon.click(() => {
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys02.mp3", stop:true });
            const id = icon.attr("type");
            that.focusManager.resetSelectFocusView();
            that.focusManager.unregisterFocus();
            that.unregisterWheel();
            xClickCallback = undefined;
            that.isHelpDetail = true;
            this.detailDialog(id, set_footer_func, () => {
                that.focusManager.registerFocus();
                that.registerWheel(elm_item);
                xClickCallback = () => {
                    xClickCallback = undefined;
                    icon.trigger('click');
                };
                that.isHelpDetail = false;
            });
        });
        xClickCallback = () => {
            xClickCallback = undefined;
            icon.trigger('click');
        }
    }

    
    close() {
        this.focusManager.unregisterFocus();
        this.unregisterWheel();
        xClickCallback = undefined;
    }

    
    addLeftUI()
    {
        let html = "";
        const sf = TYRANO.kag.variable.sf;
        let first_item = undefined;
        masterdata.help_group.forEach(x => {
            if (!(x.group in masterdata.help)) {
                console.error(`ヘルプにgroup: ${x.group} が存在しません`);
                return;
            }

            let items = [];
            masterdata.help[x.group].forEach(item => {
                if (!(item.id in sf.helps)) return;
                if (!sf.helps[item.id].is_release || !sf.helps[item.id].is_visible) return;
                const is_first_item = first_item === undefined;
                items.push(this.createItemHtml(item, is_first_item));
                if (is_first_item) {
                    first_item = item;
                }
            });

            html += `
                <group>
                    <text>${x.group}</text>
                    <line></line>
                    ${items.join("")}
                </group>`;
        });

        $(".help-left > category").append(html);

        
        const groups = $(".help-left > category > group");
        groups.each(function() {
            if ($(this).find("item").length === 0) {
                $(this).hide();
            }
        });

        
        this.updateRightUI(first_item);
    }

    
    createItemHtml(item, visible_cursor) {
        const sf = TYRANO.kag.variable.sf;
        if (!(item.id in sf.helps)) return "";
        if (!sf.helps[item.id].is_release || !sf.helps[item.id].is_visible) return "";
        const cursor_visible = visible_cursor ? "visible" : "hidden";
        const new_icon_visible = sf.helps[item.id].is_new && !visible_cursor ? "visible" : "hidden";
        return `
            <item help_id="${item.id}" group="${item.group}">
                <text>- ${item.title}</text>
                <line></line>
                <cursor style="visibility: ${cursor_visible}"></cursor>
                <icon-new style="visibility: ${new_icon_visible}"></icon-new>
            </item>`;
    }

    
    updateRightUI(help)
    {
        const help_content = $(".help-content");
        const title = help_content.find("top > right > text");
        title.html(help.title);

        const right = $(".help-right");
        right.find("text").html(help.text);

        const thumbnail = right.find("box > thumbnail");
        if (help.iamge !== "") {
            thumbnail.show();
            thumbnail.css('background-image', `url(${help.image})`);
            thumbnail.find("icon").attr("type", help.id);
        } else {
            thumbnail.hide();
            thumbnail.css('background-image', `url(${help.image})`);
        }
    }

    
    detailDialog(id, set_footer_func, on_exit) {
        const layer = TYRANO.kag.layer.getMenuLayer();
        const help = Object.values(masterdata.help).find(a => a.find(b => b.id == id)).find(a => a.id == id); 
        const path = `${help.image}`;
        const dialog = $(`
            <div class="dialog">
                <help-detail-window>
                    <img src="${path}">
                </help-detail-window>
            </div>`);
        layer.append(dialog);

        dialog.click(() => {
            dialog.remove();
            set_footer_func();
            on_exit();
        });

        Common.makeFocusable(dialog);
        const close_func = function(){
            xClickCallback = undefined;
            dialog.click();
        }
        const display_param = {
            close_event_q_key: function(e){
                e.stopPropagation();
                close_func();
            },
        }

        xClickCallback = close_func;
        mist_system.FooterContainer.showDialogFooter(display_param, false);
    }

    registerWheel(elm_item) {
        mist_temp.is_help_key_scroll = false;
        const scroll_target = $('.help-left');
        scroll_target.off();
        var timer = false;
        scroll_target.scroll(function () {
            
            if (!mist_temp.is_help_key_scroll) {
                return;
            }

            
            if (timer !== false){
                clearTimeout(timer);
            }
            timer = setTimeout(function(){
                mist_temp.is_help_key_scroll = false;
            }, 200);

            const base_rect = scroll_target[0].getBoundingClientRect();
            const center = base_rect.top + base_rect.height / 2;
            for (let i = 0; i < elm_item.length; ++i) {
                const rect = elm_item[i].getBoundingClientRect();
                if (rect.top <= center && center <= rect.bottom) {
                    elm_item.trigger("mouseleave");
                    elm_item.eq(i).trigger("mouseenter");
                    return;
                }
            };
        });
        Common.registerWheel("HelpView", () => {
            mist_temp.is_help_key_scroll = true;
            Common.wheel(scroll_target, -100);
            return true;
        }, () => {
            mist_temp.is_help_key_scroll = true;
            Common.wheel(scroll_target, 100);
            return true;
        });
    }
    unregisterWheel() {
        mist_temp.is_help_key_scroll = false;
        Common.unregisterWheel("HelpView");
    }
}

Common.sfAddClass(new HelpView());
