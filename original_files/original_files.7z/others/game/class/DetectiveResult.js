
class DetectiveResult
{
    constructor() {
     }

    load()
    {
        const container = $("detective-result");
        if(container.length == 0) return;
        this.addEvent(container);
        this.enable_click = true;
    }

    remove() {
        const container = $("detective-result");
        if(container.length == 0) return;
        container.remove();
    }

    enableClick() {
        this.enable_click = true;
    }

    
    addEvent()
    {
        const that = this;
        that.enable_click = false;
        const display_param = {
            close_event_q_key: function(e){
                if(!that.enable_click) return;
                mist_system.FooterContainer.back();
                TYRANO.kag.ftag.startTag("jump",{target: mist_save.close_click_target });
            },
            is_visible_footer_base: true
        }
        mist_system.FooterContainer.showDetectiveResultFooter(display_param);

        
        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("help_detective_result") });

    }


    
    create(close_target)
    {
        mist_save.close_click_target = close_target;

        const layer = TYRANO.kag.layer.getFreeLayer();
        layer.show();
        let creditLevelCount = 0;
        for (let i = 0 ; i < mist_system.DetectiveManager.characters.length ; ++i) {
            if (mist_system.DetectiveManager.characters[i].id == "itsuki") {
                continue;
            }
            
            if (mist_system.DetectiveManager.characters[i].getCreditDispLevel() <= 1) {
                ++creditLevelCount;
            } 
        }
        let high_convinve_count = 0;
        const convince_lv = requireConvincingLevelDoubt();
        getResolvedDoubtIds().forEach((id) => {
            const doubt = getDoubt(id);
            if(doubt != null && doubt.isAnswerFull()) {
                let inference = getInferenceFromDoubt(doubt);
                if(compareConvinceLevelStr(inference.convince_level_index, convince_lv)){
                    high_convinve_count += 1;
                }
            }
        });

        
        let monologueMessage = getCommonHelpDirect("detective_result_monologue_3");
        
        if (!TYRANO.kag.stat.f.end_secret_phase) {
            
            monologueMessage = getCommonHelpDirect("detective_result_monologue_2");
        }else if (creditLevelCount >= (mist_system.DetectiveManager.characters.length == 5 ? 2 : 3)) {
            
            monologueMessage = getCommonHelpDirect("detective_result_monologue_1");
        }

        if(getCommonHelpWithCondition("detective_result_monologue_special")){
            
            monologueMessage = getCommonHelpWithCondition("detective_result_monologue_special");
        }
        const pieceMaster = getPieceMaster();
        const characters = mist_system.DetectiveManager.characters;
        let chara_grid_htmls = "";
        characters.forEach((x) => {
            const full_name = Common.getDisplayNameToFullName(x.name);

            let targetVote = 0;
            if (TYRANO.kag.stat.f.vote_result != undefined) {
                targetVote = TYRANO.kag.stat.f.vote_result.find(vote_result => vote_result.key == x.id).value;
            }
            const isPlayer = x.player == 1;
            chara_grid_htmls += `
            <vote-character-grid id="${x.id}">
                <icon-player-voted></icon-player-voted>
                <nameplate>
                ${full_name}
                </nameplate>
                <result-vigilance class="result-vigilance">
                    <v1 class="result-vigilance"></v1>
                    <v2 class="result-vigilance"></v2>
                    <v3 class="result-vigilance"></v3>
                    <v4 class="result-vigilance"></v4>
                    <v5 class="result-vigilance"></v5>
                </result-vigilance>
                <vote-value>
                    ${targetVote + "票"}
                </vote-value>
            </vote-character-grid>`;
        });
        const container = $(`
            <detective-result>
                <title></title>
                <character-grid>
                    <character></character>
                    <message-window></message-window>
                    <message>
                        ${monologueMessage}
                    </message>
                </character-grid>
                <info-grid>
                    <text-content>
                        <icon></icon>
                        <text-title>
                            ${"解決した疑問"}
                        </text-title>
                        <line1></line1>
                        <text-value>
                        ${getDoubtAll().filter(d => d.hasInference()).length + " / " + Object.values(masterdata.doubt.dict_id).filter(d =>d.phase != 'debate').length}
                        </text-value>
                    </text-content>
                    <text-content>
                        <icon></icon>
                        <text-title>
                            ${"獲得した手がかり"}
                        </text-title>
                        <line2></line2>
                        <text-value>
                            ${Object.keys(TYRANO.kag.stat.f.player_pieces).length + " / " + Object.keys(pieceMaster).length}
                        </text-value>
                    </text-content>
                    <text-content>
                        <icon></icon>
                        <text-title>
                            ${"樹への信用 / 得票数"}
                        </text-title>
                    </text-content>
                    <vote-content>
                        ${chara_grid_htmls}
                    </vote-content>


                </info-grid>
            </detective-result>`);
        layer.append(container);
        const tempPlayerVoteID = TYRANO.kag.stat.f.player_voted_id != ''
                                    ? TYRANO.kag.stat.f.player_voted_id
                                    : mist_system.DetectiveManager.characters[mist_system.DetectiveManager.characters.length - 1].id;

        let maxVoteTargetID = mist_system.DetectiveManager.characters[mist_system.DetectiveManager.characters.length - 2].id;
        if (TYRANO.kag.stat.f.vote_result != undefined) {
            maxVoteTargetID = TYRANO.kag.stat.f.vote_result.reduce((max, val) => max.value > val.value ? max : val).key; 
        }
        $("detective-result").find("character").css("background-image", `url(./data/fgimage/chara/${TYRANO.kag.stat.f.player.resource}/continue_charactor.png)`);

        $("detective-result").find("vote-character-grid").each(function () {
            const id = $(this).attr("id");
            Common.setVisible($(this).find("icon-player-voted"), id == tempPlayerVoteID);
            
            if (maxVoteTargetID == id) {
                
              $(this).find("vote-value").css("text-shadow", "0 0 10px rgba(255, 255, 255, 1.0)");
            }

            
            if (id == "itsuki") {
              
              Common.setVisible($(this).find("result-vigilance"), false);
              return true;
            }
            const character = mist_system.DetectiveManager.characters.find(x => x.id == id);
            const vigilance_list = $(this).find("result-vigilance > .result-vigilance");

            
            
            
            
            
            
            
            
            let credit_disp_level = character.getCreditDispLevel();
            vigilance_list.each(function(i) {
                Common.setVisible($(this), i == credit_disp_level);
            });
      
        });

        this.addEvent();
    }
}

Common.sfAddClass(new DetectiveResult());
