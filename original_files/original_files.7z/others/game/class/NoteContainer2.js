
class NoteContainer2 {
    constructor() {
        this.returnLabel = undefined;
        this.click_target = undefined;
        this.open_create_interfance = false;
        this.back_create_interfance_func = undefined;
        this.not_clear_doubt_id = false;
        this.save_cursor = false;
        this.question_start = false;
        this.is_question = true;
        this.is_tab_memory = true;

        this.storages = [
            "./data/image/detective/common/dummy.png",
            "./data/image/detective/note/note_bg.png",
            "./data//image/common/new.png",

            "./data/image/detective/note/tab_left.png",
            "./data/image/detective/note/tab_left_hover.png",
            "./data/image/detective/note/tab_left_disable.png",
            "./data/image/detective/note/tab_right.png",
            "./data/image/detective/note/tab_right_hover.png",
            "./data/image/detective/note/tab_right_disable.png",

            "./data/image/detective/note/tab_1.png",
            "./data/image/detective/note/tab_1_select.png",
            "./data/image/detective/note/tab_1_gray.png",

            "./data/image/detective/note/tab_2.png",
            "./data/image/detective/note/tab_2_select.png",
            "./data/image/detective/note/tab_2_gray.png",

            "./data/image/detective/note/tab_3.png",
            "./data/image/detective/note/tab_3_select.png",
            "./data/image/detective/note/tab_3_gray.png",

            "./data/image/detective/note/tab_4.png",
            "./data/image/detective/note/tab_4_select.png",
            "./data/image/detective/note/tab_4_gray.png",

            "./data/image/detective/note/tab_5.png",
            "./data/image/detective/note/tab_5_select.png",
            "./data/image/detective/note/tab_5_gray.png",

            "./data/image/detective/note/tab_6.png",
            "./data/image/detective/note/tab_6_select.png",
            "./data/image/detective/note/tab_6_gray.png",

            "./data/image/detective/note/select_frame.png",

            
            "./data/image/detective/note/color/name_color0.png",
            "./data/image/detective/note/color/name_color1.png",
            "./data/image/detective/note/color/name_color2.png",
            "./data/image/detective/note/color/name_color3.png",
            "./data/image/detective/note/color/name_color4.png",
            "./data/image/detective/note/color/name_color5.png",
            "./data/image/detective/note/color/name_color6.png",

            "./data/image/detective/note/color/piece_color0.png",
            "./data/image/detective/note/color/piece_color1.png",
            "./data/image/detective/note/color/piece_color2.png",
            "./data/image/detective/note/color/piece_color3.png",
            "./data/image/detective/note/color/piece_color4.png",
            "./data/image/detective/note/color/piece_color5.png",
            "./data/image/detective/note/color/piece_color6.png",

            "./data/image/detective/note/question/grayout.png",

            "./data/image/detective/note/color/wide_color0.png",
            "./data/image/detective/note/color/wide_color1.png",
            "./data/image/detective/note/color/wide_color2.png",
            "./data/image/detective/note/color/wide_color3.png",
            "./data/image/detective/note/color/wide_color4.png",
            "./data/image/detective/note/color/wide_color5.png",
            "./data/image/detective/note/color/wide_color6.png",

            "./data/image/detective/note/color/piece_color0_gray.png",
            "./data/image/detective/note/color/piece_color1_gray.png",
            "./data/image/detective/note/color/piece_color2_gray.png",
            "./data/image/detective/note/color/piece_color3_gray.png",
            "./data/image/detective/note/color/piece_color4_gray.png",
            "./data/image/detective/note/color/piece_color5_gray.png",
            "./data/image/detective/note/color/piece_color6_gray.png",

            "./data/image/detective/note/warning_red.png",
            "./data/image/detective/note/warning_yellow.png",

            "./data/image/detective/note/lens1.png",
            "./data/image/detective/note/lens2.png",

            "./data/image/detective/note/tag_1.png",
            "./data/image/detective/note/tag_2.png",
            "./data/image/detective/note/tag_3.png",

            "./data/image/detective/note/chronology/width_line.png",
            "./data/image/detective/note/chronology/length_line.png",

            "./data/image/detective/note/inference/piece_list_grayout.png",

            
            "./data/image/detective/note/inference/frame.png",
            "./data/image/detective/note/button.png",
            "./data/image/detective/note/button_hover.png",
            "./data/image/detective/note/button.png",
            "./data/image/detective/note/button_grayout.png",
            "./data/image/detective/note/button_grayout_hover.png",
            "./data/image/detective/note/button_effect.gif",

            
            "./data/image/detective/note/summay_title_line.png",

            "./data/image/detective/select/check.png",

            "./data/image/detective/note/person/1989.png",
            "./data/image/detective/note/person/1990.png",
            "./data/image/detective/note/person/1991.png",
            "./data/image/detective/note/person/2004.png",


            "./data/image/common/common_arrow_icon.png",
            "./data/image/detective/note/doubt/arrow_center.png",
            "./data/image/detective/note/doubt/frame0.png",
            "./data/image/detective/note/doubt/frame1.png",
            "./data/image/detective/note/doubt/frame2.png",
            "./data/image/detective/note/doubt/frame3.png",
            "./data/image/detective/note/doubt/frame4.png",
            "./data/image/detective/note/doubt/frame5.png",
            "./data/image/detective/note/doubt/grayout.png",
            "./data/image/common/new.png",
        
            "./data/image/detective/note/doubt/result0.png",
            "./data/image/detective/note/doubt/result1.png",
            "./data/image/detective/note/doubt/result2.png",
        ];
        const layer = TYRANO.kag.layer.getLayer("message12");
        layer.empty();
        mist_save.temp_player_cost = 0;
    }

    closeFooterEvent(time) {
        this.save_cursor = false;
        mist_system.DetectiveContainer.applyTempTime();
        
        if (this.is_tab_memory) {
            this.question_start = false;
            this.is_question = true;
            mist_temp.note_create_interfance_question_id = undefined;
            mist_temp.note_create_interfance_question_scroll = 0;
            mist_temp.note_create_interfance_time_id = undefined;
            mist_temp.note_create_interfance_time_scroll = 0;
        }
        if(this.open_create_interfance) {
            this.open_create_interfance = false;
            
            
            
            
            
            
            
            mist_save.doubt_id = "";
            mist_save.selected_slot_tag = undefined;
            mist_save.current_slot = 0;
            mist_system.FooterContainer.back();
            if(this.back_create_interfance_func) {
                this[this.back_create_interfance_func]();
            }
            else {
                this.createDoubtNormal();
            }
            return;
        }

        Common.setBlock(true);
        this.unregisterFocus();
        const that = this;
        this.fadeOut(() => {
            that.clearContainer();
            Common.removePreventScene();
            mist_save.detective_select_index = -1; 
            if(that.returnLabel) {
                TYRANO.kag.ftag.startTag("jump", { target: mist_system.NoteContainer2.returnLabel });
            }
            that.returnLabel = undefined;
            that.click_target = undefined;
            that.fadeIn(() => {
                Common.setBlock(false);
                const layer = TYRANO.kag.layer.getLayer("message12");
                layer.hide();

                
                mist_system.FooterContainer.active(TYRANO.kag.stat.is_strong_stop);
            }, time);
        }, time);

    }

    
    clearUsedData() {
        tyrano.plugin.kag.key_mouse.util.enableFocusTab(undefined);
        
        
        
        
        
        
        if(!this.not_clear_doubt_id) {
            mist_save.doubt_id = "";
        }
        this.not_clear_doubt_id = false;
        mist_save.doubt_filter = null;
        mist_save.enableShowInference = false;
        mist_save.select_piece_id = "";
        mist_save.current_slot = 0;
        mist_save.selected_slot_tag = undefined;
        this.open_create_interfance = false;
        this.back_create_interfance_func = undefined;
        this.help_text_tag = "";
    }

    
    create() {
        this.clearUsedData();
        const container = this.createContainer();
        this.createPiece(container);

        this.addTabEvent();

    }

    clearContainer(clearData=true) {
        if(clearData) {
            this.clearUsedData();
        }
        this.click_target = undefined;
        mist_system.FooterContainer.back();
        const layer = TYRANO.kag.layer.getLayer("message12");
        layer.empty();
        layer.hide();

        restartGameProgress(this.callNextOrder);
        this.callNextOrder = false;
        TYRANO.kag.layer.showEventLayer();
        TYRANO.kag.ftag.startTag("autostop", { next: false }); 
    }

    hide() {
        this.click_target = undefined;
        const layer = TYRANO.kag.layer.getLayer("message12");
        layer.hide();
    }
    
    
    createContainer(close_event=undefined) {
        
        const layer = TYRANO.kag.layer.getLayer("message12");
        const before_container = layer.find("note-container2");
        if(before_container.length > 0) {
            
            before_container.remove();
        }

        this.unregisterFocus();

        layer.show();
        
        const container = $(`
            <note-container2>
                <tab-left></tab-left>
                <tab-right></tab-right>
                <tabs>
                    <tab-summary>
                        <text>事件概要</text>
                    </tab-summary>
                    <tab-doubt>
                        <text>疑問・推理</text>
                    </tab-doubt>
                    <tab-piece>
                        <text>手がかり</text>
                    </tab-piece>
                    <tab-time>
                        <text>時系列</text>
                    </tab-time>
                    <tab-map>
                        <text>マップ</text>
                    </tab-map>
                    <tab-person>
                        <text>人物情報</text>
                    </tab-person>
                </tabs>
                <content>
                </content>
            </note-container2>`);
        layer.append(container);

        mist_system.FooterContainer.showNoteFooter({
            close_event: () => {
                if(close_event) {
                    close_event();
                }
                else {
                    mist_system.NoteContainer2.closeFooterEvent();
                }                
            }
        });
        
        return container;
    }

    appendFadeContainer() {
        const layer = TYRANO.kag.layer.getLayer("message12");
        const exist_container = layer.find("note-fade-container").length > 0;
        if(!exist_container) {
            layer.append(`<note-fade-container></note-fade-container>`);
        }
        layer.show();
        this.being_fadeout = true; 
        return layer.find("note-fade-container").eq(0);
    }

    fadeIn(callback, time) {
        const that = this;
        const fade_time = time ? time : parseInt(Common.getDefineLabel("@program_fade_time"));
        const fade = this.appendFadeContainer();
        fade.show().fadeOut(fade_time, "linear", function() {
            if(callback) {
                callback();
            }
            if(!that.being_fadeout){
                
                fade.remove();
            }
        });
    }

    fadeOut(callback, time) {
        const fade = this.appendFadeContainer();
        const fade_time = time ? time : parseInt(Common.getDefineLabel("@program_fade_time"));
        fade.hide().fadeIn(fade_time, "linear", function() {
            this.being_fadeout = false;
            if(callback) {
                callback();
            }
        });
    }

    
    createPieceInfo(disable_select_chara_id, prohibition_ids, filter_tag){
        let result = {};
        let charList = getNpcListOrderedDisp();
        charList.unshift(getPlayer());

        if(prohibition_ids === void 0) {
            prohibition_ids = {};
        }
        let pieces = [];
        let pieceInfo = {};
        const quest_keys = ["cond1", "cond2", "cond3", "cond4", "cond5", "cond6", "cond7"];
        const pieceMaster = getPieceMaster();
        for(const p of getPlayerPieceKeysInventory()){
            result[p] = {"talked":[],  "alert": []};

            const chara_id = pieceMaster[p].chara_id;
            if(!pieceInfo[chara_id]){ pieceInfo[chara_id] = [];}
            pieceInfo[chara_id].push(p);
            if(chara_id == disable_select_chara_id){
                prohibition_ids[p] = true;
            }
            if(filter_tag != void 0){
                if(filter_tag == "all" || !pieceMaster[p].getTagStr(filter_tag)){
                    prohibition_ids[p] = true;
                }
            }
        }
        
        const current_doubt = getDoubt(TYRANO.kag.stat.f.doubt_id);
        const inferenceMode = Boolean(current_doubt);
        if(inferenceMode) {
            if(current_doubt.unsettled_answer_slots) {
                const loopCnt = current_doubt.unsettled_answer_slots.length;
                for(let i = 0; i < loopCnt; ++i) {
                    const p = current_doubt.unsettled_answer_slots[i];
                    
                    if(mist_save.current_slot != i && p !== null && p.length > 0) {
                        prohibition_ids[p] = true;
                    }
                }
            }
        }

        for(const chr of charList){
            if(pieceInfo[chr.id]){
                pieces.push(pieceInfo[chr.id]);
            }else{
                pieces.push([]);
            }
            Object.keys(result).forEach(p => {
                result[p]["talked"].push(isAlreadyTalked(chr.id, p)); 

                if(chr.id == getPlayer().id){ 
                    return;
                }
                if(chr.id != disable_select_chara_id){
                    return ;
                }
                const q = getQuestion(`${chr.id}_${p}`);
                const q_cond_key = quest_keys.find(key => checkConditionsStr(q[key]));
                if(q_cond_key){
                    const alert_icon = `${q_cond_key}_alert`;
                    result[p]["alert"].push(q[alert_icon]); 
                }else{
                    result[p]["alert"].push(""); 
                }
            });
        }

        return [result, pieces, prohibition_ids];
    }

    
    clearItemEvent(container) {
        const elem_items = container.find("item");
        elem_items.off();
        const lens_items = container.find("lens");
        lens_items.off();
    }

    
    createHoverEventInPiece(container, is_question){
        const right_content = container.find("pieces > right-content > content").first();
        const that = this;
        const elem_items = container.find("item");

        elem_items.hover(function(e) {
            $(this).addClass("select");
            const id = $(this).attr("id");
            
            that.setLastIndex(id);
            const color = Common.getClassByName($(this).find("item-frame"), "color");
            const piece = getPiece(id);

            const info = $("note-container2 > content > pieces > left-content > info");
            Common.setVisible(info, true);
            info.removeClass(function(index, className) {
                return (className.match(/\bcolor\S+/g) || []).join(' ');
            });
            info.addClass(color);
            info.find("title").removeClass(function(index, className) {
                return (className.match(/\bcolor\S+/g) || []).join(' ');
            });
            info.find("title").addClass(color);
            info.find("title").html(piece.title);
            info.find("text").html(piece.desc);

            info.find("lens").remove();
            if($(this).find("lens").length > 0){
                info.append("<lens>");
            }
            info.find("warning").remove();
            if($(this).find("warning").length > 0){
                info.append("<warning>");
            }
            info.find("alert").remove();
            if($(this).find("alert").length > 0){
                info.append("<alert>");
            }
            const tags = Object.keys(piece.tag_list);
            const elem_tags = info.find("hash-tags");
            elem_tags.empty();
            tags.forEach(x => {
                const tag_index = that.getTagIndex(x);
                elem_tags.append(`<tag class="tag${tag_index}"></tag>`);
            });

            
            if (that.is_tab_memory) {
                if (is_question) {
                    mist_temp.note_create_interfance_question_id = id;
                    mist_temp.note_create_interfance_question_scroll = right_content.scrollTop();
                }
                else {
                    mist_temp.note_create_interfance_time_id = id;
                    mist_temp.note_create_interfance_time_scroll = right_content.scrollTop();
                }
            }
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, function(e) { 
            $(this).removeClass("select"); 
            const info = $("note-container2 > content > pieces > left-content > info");
            Common.setVisible(info, false);
        });

        const lens_items = container.find("right-content lens");
        lens_items.hover(function(e) {
            $(this).addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, function(e) {
            $(this).removeClass("hover");
        });

        for(let i = 0; i < elem_items.length; ++i) {
            Common.makeFocusable(elem_items.eq(i), 1);
        }
    }

    createTextDialog(text, callback) {
        const that = this;
        that.unregisterFocus(false);
        TYRANO.kag.variable.sf.Dialog.createTextDialog(text, undefined, false, () => {
            that.reRegisterFocus();
            if(callback) {
                callback();
            }
        });
    }

    
    createSelectEvent(container, click_target, inferenceMode, disable_select_chara_id, prohibitions, pieceInfo, returnFunctionName){
        
        const that = this;
        const doubt = $("note-container2 > content > pieces > left-content > doubt");
        const elem_items = container.find("item");
        if(click_target || inferenceMode){
            elem_items.click(function() {
                if (mist_temp.is_tutorial) return;

			    const id = $(this).attr("id");
                
                
                clearPiecesNew(id);
                $(this).find("new").remove();

                const current_doubt = getDoubt(mist_save.doubt_id);
                if(prohibitions[id]){
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                    if(inferenceMode) {
                        
                        if(current_doubt.unsettled_answer_slots.findIndex(ele => ele == id) >= 0) {
                            
                            that.createTextDialog(getCommonHelpDirect("piece_selected_in_other_slots"));
                        }else if(mist_save.selected_slot_tag === undefined){
                            
                            that.createTextDialog(getCommonHelpDirect("select_slot"));
                        }else{
                            
                            that.createTextDialog(getCommonHelpDirect("piece_unableselect"));
                        }
                    } else if(click_target){
                        if(getPiece(id).chara_id == disable_select_chara_id){
                            that.createTextDialog(getCommonHelpDirect("piece_himself"));
                        }
                        else if(pieceInfo[id]["talked"]) {
                            that.createTextDialog(getCommonHelpDirect("asked_questions"));
                        }
                    }
                    return ;
                }
                mist_save.select_piece_id = id;
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                if(click_target){
                    TYRANO.kag.ftag.startTag("jump",{target: click_target });
                }
                if(inferenceMode){
                    if(current_doubt.getAnswerPieces(inferenceMode)[mist_save.current_slot] != mist_save.select_piece_id) {
                        current_doubt.setAnswerSlot(mist_save.current_slot, mist_save.select_piece_id);
                    } else {
                        current_doubt.setAnswerSlot(mist_save.current_slot, null);
                    }

                    const old_right_content = $("note-container2 > content > pieces > right-content > content");
                    that.default_focus_piece_scroll_top = old_right_content.scrollTop();
                    that.default_focus_piece_frame_no = parseInt(mist_save.current_slot);
        
                    mist_system.FooterContainer.back();
                    TYRANO.kag.variable.sf.NoteContainer2[returnFunctionName]();

                    if(current_doubt.isAnswerFull(true)) {
                        that.setFocusOkButton();
                    }
                }
            });
        }else{
            elem_items.click(function() {
                
                if (mist_temp.is_tutorial) return;
                that.setFocusElement($(this).attr("id"));
            });
        }

        
        const lens_items = container.find("right-content lens");
        lens_items.click(function(e) {
            if (mist_temp.is_tutorial) return;

            e.stopPropagation();
            const id = $(this).parent().parent().attr("id");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            that.unregisterFocus(false);
            mist_system.Dialog.createPieceDetailDialog(id, undefined, undefined, () => {
                that.reRegisterFocus();
            });
        });

        
        Common.setVisible(doubt, inferenceMode);
        const ok_button = doubt.find("ok-button");
        ok_button.hover(function() {
            $(this).addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, function() {
            $(this).removeClass("hover");
        });
        ok_button.click((e) => {
            if (mist_temp.is_tutorial) return;

            e.stopPropagation();
            const doubt_data = getDoubt(mist_save.doubt_id);
            if(doubt_data.isAnswerFull(inferenceMode)){
                if (isLastActionCreateInference()) {
                    
                    that.createTextDialog(helpMessage("warn_last_action_createinference").text, () => {
                        that.unregisterFocus(false);
                        TYRANO.kag.variable.sf.Dialog.createConfirmInference2Event(() => {
                            if(TYRANO.kag.stat.f.phaseTiming != "select_talk"){
                                this.clseNoteCallCreateInference();
                            } else {
                                Common.clearDialogLayer();
                            }
                            mist_system.NoteContainer2.closeFooterEvent();
                            if(TYRANO.kag.stat.f.phaseTiming == "select_talk"){
                                
                                TYRANO.kag.ftag.startTag("jump", { target: "*ApplyJumpSecretToDebate" });
                            } else {
                                
                                
                                TYRANO.kag.ftag.startTag("jump", { target: "" });
                            }
                        }, 
                        () => {
                            that.reRegisterFocus();
                        });
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                    });

                    const elem = $(this);
                    ok_button.attr("type", 2);
                    setTimeout(() => {
                        ok_button.attr("type", 0);
                    }, 1000);
                }
                else {
                    that.unregisterFocus(false);
                    TYRANO.kag.variable.sf.Dialog.createConfirmInference2Event(() => { this.clseNoteCallCreateInference() }, () => { that.reRegisterFocus(); });
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                }
            }else{
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                that.createTextDialog(getCommonHelpDirect("inference_unableok"), () =>{
                    that.reRegisterFocus();
                    that.setFocusOkButton();
                });
            }
        });
        Common.makeFocusable(ok_button);

        const reset_button = doubt.find("reset-button");
        reset_button.hover(function() {
            $(this).addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, function() {
            $(this).removeClass("hover");
        });
        reset_button.click(() => {
            if (mist_temp.is_tutorial) return;

            reset_button.attr("type", 3);
            ok_button.attr("type", 3);
            const count = doubt.find("doubt-tags > piece-frame").length;
            const tags = doubt.find("doubt-tags");
            Common.setVisible(container.find("pieces-grayout"), true);

            tags.empty();
            
            let doubt_data = getDoubt(mist_save.doubt_id);
            doubt_data.clearUnsettledAnswerSlots();
            mist_save.current_slot = 0;
            mist_save.selected_slot_tag = undefined;

            const old_right_content = $("note-container2 > content > pieces > right-content > content");
            that.default_focus_piece_scroll_top = old_right_content.scrollTop();
            that.default_focus_piece_frame_no = parseInt(mist_save.current_slot);

            mist_system.FooterContainer.back();
            TYRANO.kag.variable.sf.NoteContainer2[returnFunctionName]();
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
        });
        Common.makeFocusable(reset_button);

        const piece_frame = doubt.find("doubt-tags > piece-frame");
        piece_frame.hover(function() {
            $(this).addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            const slot_index = $(this).attr("id");
            const current_doubt = getDoubt(mist_save.doubt_id);
            
            if(current_doubt.unsettled_answer_slots[slot_index] != null) {
                const piece_elem = $("note-container2").find(`item#${current_doubt.unsettled_answer_slots[slot_index]}`);
                that.setSelectPiece(piece_elem.eq(0));
                const info = $("note-container2 > content > pieces > left-content > info");
                Common.setVisible(info, true);
            }
        }, function() { 
            $(this).removeClass("hover");

            
            const info = $("note-container2 > content > pieces > left-content > info");
            Common.setVisible(info, false);
        });
        
        piece_frame.css("cursor", "pointer");
        piece_frame.click(function() {
            if (mist_temp.is_tutorial) return;
            const current_doubt = getDoubt(mist_save.doubt_id);
            mist_save.current_slot = $(this).attr("id");
            const slot_tag = current_doubt.require_slots[mist_save.current_slot];
            mist_save.selected_slot_tag = slot_tag;
                        
            const old_right_content = $("note-container2 > content > pieces > right-content > content");
            that.default_focus_piece_scroll_top = old_right_content.scrollTop();
            that.default_focus_piece_frame_no = parseInt(mist_save.current_slot);

            mist_system.FooterContainer.back();
            TYRANO.kag.variable.sf.NoteContainer2[returnFunctionName]();
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
        });
        for(let i = 0; i < piece_frame.length; ++i) {
            Common.makeFocusable(piece_frame.eq(i));
        }
    }


    
    createPiece(container, click_target, disable_select_chara_id, prohibition_ids, do_question) {
        
        if (this.is_tab_memory) {
            this.is_question = true;
        }

        this.unregisterFocus();

        const tab = container.find("tab-piece");
        tab.addClass("select");
        tab.removeClass("disable");
        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("note_piece") });
        const content = container.find("content");
        content.empty();

        const current_doubt = getDoubt(TYRANO.kag.stat.f.doubt_id);
        const inferenceMode = Boolean(current_doubt);
        

        const doubtHtml = this.getDoubtMiniHtml(current_doubt, inferenceMode);
        

        let filter_tag = mist_save.selected_slot_tag;
        if(!filter_tag && inferenceMode) {
            
            filter_tag = "all";
        }

        
        let rightContentGridItems = "";
        let rightHeaderGridItems = "";

        if(prohibition_ids === void 0) {
            prohibition_ids = {};
        }

        
        let [pieceInfo,  pieces, prohibitions] = this.createPieceInfo(disable_select_chara_id, prohibition_ids, filter_tag);

        let col_count = 0;
        pieces.map(x => {if(x.length > col_count) {
            col_count = x.length;
        }});
        if(col_count <= 0) {
            const empty_text = getCommonHelpDirect("empty_pieces");
            const empty_html = `<empty_text>${empty_text}</empty_text>`
            content.html(empty_html);
            return;
        }
        let colorIdx = 0;
        let charList = getNpcListOrderedDisp();
        charList.unshift(getPlayer());
        for(const chr of charList){
            const chara_name = masterdata.names[chr.name_id];
            const name = chara_name ? chara_name.fullname : chr.sysname;
            colorIdx = chr.colorIndex();
            rightHeaderGridItems += `
                <grid>
                    <name-line class="color${colorIdx}">${name}</name-line>
                </grid>
            `;
            rightContentGridItems += `
                <grid>
                </grid>
            `;
        }

        let contents_html = `
        <pieces type="${charList.length}">
            <left-content>
                ${inferenceMode ? 
                `<doubt style="visibility: hidden;">
                    <content class="doubt" type="4">
                        ${doubtHtml}
                    </content>
                </doubt>`: ""}
                <info style="visibility: hidden;">
                    <warning></warning>
                    <lens></lens>
                    <title></title>
                    <text></text>
                    <hash-tags>
                        <tag></tag>
                        <tag></tag>
                        <tag></tag>
                    </hash-tags>
                </info>
            </left-content>
            <empty></empty>
            <right-content>
                <header>
                    <div></div>
                    ${rightHeaderGridItems}
                </header>
                <content>
                    <div></div>
                    ${rightContentGridItems}
                </content>
            </right-content>
        </pieces>
        <pieces-grayout></pieces-grayout>`;

        content.html(contents_html);

        const element_list = [];
        const element_index_list = [];
        let element_count = 0;

        for (let i = 0; i < pieces.length; ++i) {
            element_index_list.push(Array(col_count).fill(-1));
            const grid = container.find("pieces > right-content > content > grid").eq(i);
            for (let j = 0; j < pieces[i].length; ++j) {
                const piece_id = pieces[i][j];
                const disable_select = prohibitions[piece_id];
                this.addPieceHtml(grid, piece_id, getPiece(piece_id).colorIndex(), pieceInfo[piece_id]["talked"],  pieceInfo[piece_id]["alert"], disable_select, inferenceMode);
                element_index_list[i][j] = element_count;
                element_list.push(piece_id);
                element_count += 1;
            }
        }

        if(inferenceMode) {
            if(current_doubt.isAnswerFull(inferenceMode)) {
                mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("creating_inference_confirm") });
            } else if(mist_save.selected_slot_tag == undefined) {
                mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("creating_inference") });
            } else {
                mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("creating_inference_slot_select") });
            }
            const frames = container.find("doubt-tags > piece-frame");
            for(let i = 0; i < frames.length; ++i) {
                const frame = frames.eq(i);
                const index = frame.attr("id");
                if(current_doubt.getAnswerPieces(inferenceMode)[index] == null) {
                    Common.setVisible(frame.find("effect"), true);
                }
            }
            const pieces_grayout = container.find("pieces-grayout");
            Common.setVisible(pieces_grayout, mist_save.selected_slot_tag == undefined);
        }
        else if(do_question) {
            mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("question") });
        }

        
        this.createHoverEventInPiece(container, true);

        if(click_target != "disable_click"){
            
            this.createSelectEvent(container, click_target, inferenceMode, disable_select_chara_id, prohibitions, pieceInfo, "createQuestion");
        }


        const element_node_list = []
        for(let i = 0; i < element_list.length; ++i) {
            element_node_list.push(container.find(`#${element_list[i]}`));
        }
        const inference_mode_node_list = []
        if(inferenceMode) {
            this.appendInferenceModeButton(inference_mode_node_list);
        }
        
        this.registerFocus("pieces", element_node_list, element_index_list, inference_mode_node_list);

        
    }

    
    createTime(container, click_target, disable_select_chara_id, prohibition_ids, do_question) {
        
        if (this.is_tab_memory) {
            this.is_question = false;
        }

        this.unregisterFocus();

        const tab = container.find("tab-time");
        tab.addClass("select");
        tab.removeClass("disable");
        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("note_timeline") });
        const content = container.find("content");
        content.empty();

        
        const current_doubt = getDoubt(TYRANO.kag.stat.f.doubt_id);
        const inferenceMode = Boolean(current_doubt);
        const doubtHtml = this.getDoubtMiniHtml(current_doubt, inferenceMode);


        let filter_tag = mist_save.selected_slot_tag;
        if(!filter_tag && inferenceMode) {
            
            filter_tag = "all";
        }

        
        let rightContentGridItems = "";

        if(prohibition_ids === void 0) {
            prohibition_ids = {};
        }


        
        let time_info = {};
        
        let time_chara_count = {};
        let is_add_time_none = false;
        getPlayerPieceKeys().forEach((value, index, thisArray) => {
            let piece = piece_dict[value];
            if(piece.unixtime > 0) {
                time_info[piece.unixtime] = piece.display_time;
                if(!(piece.unixtime in time_chara_count)) {
                    time_chara_count[piece.unixtime] = {};
                }
                if(!(piece.chara_id in time_chara_count[piece.unixtime])) {
                    time_chara_count[piece.unixtime][piece.chara_id] = 0;
                }
                time_chara_count[piece.unixtime][piece.chara_id] = time_chara_count[piece.unixtime][piece.chara_id] + 1;
            }else{
                is_add_time_none = true;
            }
        });

        
        let time_count = {};
        let time_offset = {};
        for(let time in time_chara_count) {
            time_count[time] = 0;
            for(let chara in time_chara_count[time]) {
                if(time_count[time] < time_chara_count[time][chara]) {
                    time_count[time] = time_chara_count[time][chara];
                }
            }
        }

        let sortedTimeKeys = Object.keys(time_info).map(k => Number(k)).sort(function(a, b) { return a-b; });
        
        const time_none_value = -1;

        
        if(is_add_time_none){
            sortedTimeKeys.push(time_none_value);
        }
        let rightContentTimes = "";
        let rightHeaderGridItems = "";
        const itemHeight = 180;
        const itemPadding = 15;
        let total_count = 0;
        for(const key of sortedTimeKeys){
            let exist_time = key != time_none_value;
            if(exist_time){
                const t_key = key.toString();
                
                const height = time_count[t_key] * itemHeight + itemPadding * (time_count[t_key] - 1);
                rightContentTimes += `
                                 <time style="height: ${height}px;">
                                     <text>${time_info[t_key]}</text>
                                     <line></line>
                                 </time>
                `;
                time_offset[t_key] = total_count;
                total_count += time_count[t_key];
            }
            
        }

        
        let [pieceInfo,  pieces, prohibitions] = this.createPieceInfo(disable_select_chara_id, prohibition_ids, filter_tag);

        let col_count = 0;
        pieces.map(x => {if(x.length > col_count) {
            col_count = x.length;
        }});
        if(col_count <= 0) {
            const empty_text = getCommonHelpDirect("empty_pieces");
            const empty_html = `<empty_text>${empty_text}</empty_text>`
            content.html(empty_html);
            return;
        }

        let colorIdx = 0;
        let charList = getNpcListOrderedDisp();
        charList.unshift(getPlayer());
        for(const chr of charList){
            const chara_name = masterdata.names[chr.name_id];
            const name = chara_name ? chara_name.fullname : chr.sysname;
            colorIdx = chr.colorIndex();
            rightHeaderGridItems += `
                <grid>
                    <name-line class="color${colorIdx}">${name}</name-line>
                </grid>
            `;
            rightContentGridItems += `
                <grid class="time">
                </grid>
            `;
        }

        let contents_html = `
        <pieces type="${charList.length}">
            <left-content>
                ${inferenceMode ? 
                `<doubt style="visibility: hidden;">
                    <content class="doubt" type="4">
                        ${doubtHtml}
                    </content>
                </doubt>`: ""}
                <info style="visibility: hidden;">
                    <warning></warning>
                    <lens></lens>
                    <title></title>
                    <text></text>
                    <hash-tags>
                        <tag></tag>
                        <tag></tag>
                        <tag></tag>
                    </hash-tags>
                </info>
            </left-content>
            <empty></empty>
            <right-content>
                <header>
                    <empty></empty>
                    ${rightHeaderGridItems}
                </header>
                <content>
                    <times>
                        ${rightContentTimes}
                    </times>
                    ${rightContentGridItems}
                </content>
            </right-content>
        </pieces>
        <pieces-grayout></pieces-grayout>`;

        content.html(contents_html);
        const element_list = [];
        const element_index_list = [];
        for (let i = 0; i < pieces.length; ++i) {
            let usedSpaceDict = {};
            let element_count = {};
            element_index_list.push([]);
            for( const key of sortedTimeKeys){
                const item_count = time_count[key] - 1;
                usedSpaceDict[key] = "<empty></empty>";
                element_index_list[i].push(-1);
                for(let j = 0; j < item_count; j++) {
                    usedSpaceDict[key] += "<empty></empty>";
                    element_index_list[i].push(-1);
                }
                element_count[key] = 0;
            }
            for (let j = 0; j < pieces[i].length; ++j) {
                const piece_id = pieces[i][j];
                const piece = getPiece(piece_id);
                const key = Number(piece.unixtime);
                if(element_count[key] == 0) {
                    usedSpaceDict[key] = this.getAddPieceHtml(piece_id, getPiece(piece_id).colorIndex(), pieceInfo[piece_id]["talked"],  pieceInfo[piece_id]["alert"], prohibitions[piece_id], inferenceMode);
                    element_index_list[i][element_count[key] + time_offset[key]] = element_list.length;
                    element_list.push(piece_id);
                }
                else {
                    usedSpaceDict[key] += this.getAddPieceHtml(piece_id, getPiece(piece_id).colorIndex(), pieceInfo[piece_id]["talked"],  pieceInfo[piece_id]["alert"], prohibitions[piece_id], inferenceMode);
                    element_index_list[i][element_count[key] + time_offset[key]] = element_list.length;
                    element_list.push(piece_id);
                }
                element_count[key] += 1;
                
                if(key >= 0) {
                    if(time_chara_count[key][piece.chara_id] == element_count[key] && time_count[key] > element_count[key]) {
                        for(let i = element_count[key]; i < time_count[key]; i++) {
                            usedSpaceDict[key] += "<empty></empty>";
                        }
                    }
                }
            }
            const grid = container.find("pieces > right-content > content > grid").eq(i);
            for( const key of sortedTimeKeys){
                grid.append(usedSpaceDict[key]);
            }
        }

        if(inferenceMode) {
            if(current_doubt.isAnswerFull(inferenceMode)) {
                mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("creating_inference_confirm") });
            } else if(mist_save.selected_slot_tag == undefined) {
                mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("creating_inference") });
            } else {
                mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("creating_inference_slot_select") });
            }

            const frames = container.find("doubt-tags > piece-frame");
            for(let i = 0; i < frames.length; ++i) {
                const frame = frames.eq(i);
                const index = frame.attr("id");
                if(current_doubt.getAnswerPieces(inferenceMode)[index] == null) {
                    Common.setVisible(frame.find("effect"), true);
                }
            }

            const pieces_grayout = container.find("pieces-grayout");
            Common.setVisible(pieces_grayout, mist_save.selected_slot_tag == undefined);
        }
        else if(do_question) {
            mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("question") });
        }

        
        this.createHoverEventInPiece(container, false);

        if(click_target != "disable_click"){
            
            this.createSelectEvent(container, click_target, inferenceMode, disable_select_chara_id, prohibitions, pieceInfo, "createQuestionTimeline");
        }

        const element_node_list = []
        for(let i = 0; i < element_list.length; ++i) {
            element_node_list.push(container.find(`#${element_list[i]}`));
        }
        const inference_mode_node_list = []
        if(inferenceMode) {
            this.appendInferenceModeButton(inference_mode_node_list);
        }
        
        this.registerFocus("timeline", element_node_list, element_index_list, inference_mode_node_list);
        
    }

    
	getAddPieceHtml(piece_id, color_index, already_talked, alert_info, prohibition, enable_checkmark=false){
        const piece = getPiece(piece_id);
        let idx = 0;
        const peice_tag = piece.getTagList();
        const tag_index = this.getTagIndex(peice_tag[0]);
        const chara_alert = alert_info[0];
        const warningTag = chara_alert ? `<${chara_alert}></${chara_alert}>` : "";
        const lensTag = piece.detail ? "<lens></lens>" : "";

        let checkmark = "";
        if(mist_save.doubt_id && mist_save.current_slot && enable_checkmark) {
            const doubt = getDoubt(mist_save.doubt_id);
            if(doubt) {
                
                const current_set_piece_id = doubt.getAnswerPieces(true)[mist_save.current_slot];
                if(current_set_piece_id == piece_id) {
                    checkmark = "<check></check>";
                }
            }
        }
        const grayout = prohibition ? "grayout" : "";
        const is_new = piece_id in mist_save.player_pieces_new;
        const html = `
        <item id="${piece_id}" class="tyrano-focusable ${grayout}" tabindex="-1">
            <item-frame class="color${color_index}">
                    <tag class="tag${tag_index}"></tag>
                    <piece style="background-image: url(./data/image/detective/icon/${piece.resource2}.png);"></piece>
                    <grayout></grayout>
                    ${is_new ? "<new></new>" : ""}
                    ${warningTag}
                    ${lensTag}
                    ${checkmark}
            </item-frame>
            <select-frame></select-frame>
        </item>`;
		return html;
	}
    
    addPieceHtml(elem, piece_id, color_index, already_talked, alert_info, prohibition, enable_checkmark=false) {
		const html = this.getAddPieceHtml(piece_id, color_index, already_talked, alert_info, prohibition, enable_checkmark);
        elem.append(html);
    }

    getTagIndex(slot) {
        let tag_index = 0;
        switch(slot) {
            case "#アリバイ":
                tag_index = 1;
                break;
            case "#証言":
                tag_index = 2;
                break;
            case "#物証":
                tag_index = 3;
                break;
        }
        return tag_index;
    }
    
     
    getDoubtHtml(doubt, focusable=false, inferenceMode=true){
        let hasCharactor = getCharacter(doubt.chara_id);
        const player = getPlayer();
        if (hasCharactor == null) {
          if (player.id == doubt.chara_id) {
            hasCharactor = player;
          }
        }
        const icon_path = `data/${hasCharactor.doubtIconPath()}`;
        const player_icon_path = `data/image/${getPlayerInferenceIcon()}`;
        const inference = getInferenceFromDoubt(doubt, false, false);

        
        let doubtTagHtmlList = []
        doubt.require_slots.forEach((slot, index, array) => {
            
            const piece_id = doubt.getSlotData(index, inferenceMode);
            
            const tag_index = this.getTagIndex(slot);

            if(piece_id){
                const piece = getPiece(piece_id);
                const chr = getCharacter(piece.chara_id);
                doubtTagHtmlList.push(`
                      <piece-frame type="1" class="color${chr.colorIndex()}">
                          <icon style="background-image: url(data/image/${piece.resource});"></icon>
                          <name class="tag${tag_index}"></name>
                          <select-frame></select-frame>
                      </piece-frame>
                      `);
            }else{
                doubtTagHtmlList.push(`
                      <piece-frame type="0" class="slot${index + 1}">
                          <name class="tag${tag_index}"></name>
                          <text>未設定</text>
                      </piece-frame>
                      `);
            }
        });

        const doubtTagsHtml = doubtTagHtmlList.join("<cross></cross>");

        
        let inferenceText = ``;
        let inferenceResultHtml = ``;
        let inferenceReportStatus = ``;
        if(inference){
            inferenceText = `
                        <titlearea>
                            <title class="shadow-bold">${inference.name}</title>
                        </titlearea>
                        <text>
                            ${inference.desc}
                        </text>`;
            inferenceResultHtml = ["image0", "image1", "image2"][inference.convince_level_index];
            inferenceReportStatus = `image1`; 
            if(doubt.solved){ 
                
                inferenceReportStatus = doubt.result ? `image2` : `image0`;
            }
        }else{
            inferenceText = `<blank></blank>`;
            inferenceResultHtml = "blank";
        }

        const colorIndex = hasCharactor.colorIndex();
        const grayout = (doubt.solved && doubt.result) ? " grayout" : "";
        const is_new = !inference && hasDoubtNew(doubt.id);
        const item_html = `
            ${focusable ? `<item id="${doubt.id}" class="doubt-inference${grayout} tyrano-focusable" tabindex="-1">` : `<item id="${doubt.id}" class="doubt-inference${grayout}">`}
                <container>
                    <content class="doubt">
                        ${is_new ? "<new></new>" : ""}
                        ${inference ? `<result class="${inferenceReportStatus}"></result>`: ""}
                        <row1>
                            <circle class="color${colorIndex}">
                                <title>${hasCharactor.name}の疑問</title>
                            </circle>
                            <chara-image style="background-image: url(${icon_path});"></chara-image>
                        </row1>
                        <row2>
                            <titlearea>
                                <title class="shadow-bold color${colorIndex}">${doubt.title}</title>
                            </titlearea>
                            <text>${doubt.desc}</text>
                        </row2>
                        <row3>
                            <doubt-title>推理に必要な手がかり</doubt-title>
                            <doubt-line></doubt-line>
                            <doubt-tags>
                                ${doubtTagsHtml}
                            </doubt-tags>
                        </row3>
                    </content>

                    <arrow-center></arrow-center>

                    <content class="doubt">
                        <row1>
                            <circle>
                                <title>樹の推理</title>
                            </circle>
                            <chara-image style="background-image: url(${player_icon_path});"></chara-image>
                        </row1>
                        <row2>
                            ${inferenceText}
                        </row2>
                        <row3>
                            <inference-line></inference-line>
                            <inference-title>推理の説得力</inference-title>
                            <inference-status class="${inferenceResultHtml}"></inference-status>
                        </row3>
                    </content>
                    ${grayout ? '<div class=" grayout"></div>' : ""}
                </container>
            </item>`;

		return item_html;
    }

    
    createDoubt(container, funcRetrieveDoubtList, click_target) {
        const that = this;
        this.unregisterFocus();

        const tab = container.find("tab-doubt");
        tab.addClass("select");
        tab.removeClass("disable");
        
        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("note_doubt") });

        const content = container.find("content").eq(0);
        content.empty();

        
        funcRetrieveDoubtList = getDoubtAll;
        if(this.click_target === undefined) {
            this.click_target = click_target;
        }
        
        let doubtHtml = '';
        let count = 0;
        
        funcRetrieveDoubtList().sort((a, b) => (a.solved && a.result) - (b.solved && b.result)).forEach(doubt => {
            if(mist_save.doubt_filter != null && mist_save.npc != null && mist_save.npc_key != doubt.chara_id){
                
                return ;
            }
            doubtHtml += this.getDoubtHtml(doubt, true);
            count += 1;
        });
        if(count % 2 == 1) {
            doubtHtml += "<empty></empty>"
        }
        if(count == 0) {
            const empty_text = getCommonHelpDirect("empty_doubt");
            doubtHtml = `<empty_text>${empty_text}</empty_text>`
            content.html(doubtHtml);
            return;
        }
        const contents_html = `
            <doubt ${count == 0 ? 'style="overflow:hidden"' : ""}>
                ${doubtHtml}
            </doubt>`;
        content.html(contents_html);  

        const elem_items = content.find("doubt > item");
        elem_items.hover(function() {
            $(this).addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, function() {
            $(this).removeClass("hover");
        });
        const element_node_list = [];
        const element_index_list = [];
        element_index_list.push(Array(Math.floor((count + 1) / 2)).fill(-1));
        element_index_list.push(Array(Math.floor((count + 1) / 2)).fill(-1));
        for(let i = 0; i < elem_items.length; ++i) {
            const node = elem_items.eq(i);
            Common.makeFocusable(node);
            element_node_list.push(node);
            element_index_list[i % 2][Math.floor(i / 2)] = i;
        }
        this.registerFocus("doubt", element_node_list, element_index_list);
        if (elem_items.length > 0 && $(".mouse_disable").length > 0) {
            this.setFocusPieceFrame(0);
        }

        if(isModeInvestigation()){
            if(click_target != "disable_click"){
                if(this.click_target){
                    elem_items.click(function(e) {
                        if (mist_temp.is_tutorial) return;

                        const id = $(this).attr("id");
                        clearDoubtsNew(id);
                        $(this).find("new").remove();

                        elem_items.removeClass("select");
                        $(this).addClass("select");

                        e.stopPropagation();
                        TYRANO.kag.stat.is_stop = false;
                        mist_save.doubt_id = this.id;
                        const doubt = getDoubt(this.id);
                        if (doubt.solved && doubt.result){
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                            that.createTextDialog(getCommonHelpDirect("doubt_end_slots"), () => {
                                elem_items.removeClass("select");
                            });
                            return;
                        }

                        if(doubt.hasInference()) {
                            mist_save.doubt = doubt;
                            const target = that.click_target;
                            TYRANO.kag.ftag.startTag("jump",{target: target});
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                        }
                        else {
                            doubt.beginCreateAnswer();
                            
                            mist_system.FooterContainer.back();
                            mist_system.NoteContainer2.open_create_interfance = true;
                            mist_system.NoteContainer2.createQuestion();
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                       }
                    });
                }else{
                    
                    elem_items.click(function() {
                        if (mist_temp.is_tutorial) return;

                        const id = $(this).attr("id");
                        clearDoubtsNew(id);
                        $(this).find("new").remove();

                        elem_items.removeClass("select");
                        $(this).addClass("select");

                        
                        const doubt = getDoubt(id);
                        if (doubt.solved && doubt.result){
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                            that.createTextDialog(getCommonHelpDirect("doubt_end_slots"), () => {
                                elem_items.removeClass("select");
                            });
                            return;
                        }

                        
                        if (!mist_system.isOpenDeducation) {
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                            that.createTextDialog(getCommonHelpDirect("deducation_close"), () => {
                                elem_items.removeClass("select");
                            });
                            return;
                        }

                        TYRANO.kag.stat.is_stop = false;
                        mist_save.doubt_id = this.id;

                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                        const inference_help = doubt.shouldDisplayInferenceHelp();
                        if(!inference_help){
                            TYRANO.kag.variable.sf.NoteContainer2.callCreateInference();
                        }else{
                            that.unregisterFocus();
                            mist_system.Dialog.createYesNoDialogID("INFERENCE_DISPLAYHINT", ()=>{
                                setTimeout(function(){
                                    that.createTextDialog(inference_help, ()=>{
                                        TYRANO.kag.variable.sf.NoteContainer2.callCreateInference();
                                    })
                                }, 10);
                           },  ()=>{
                               TYRANO.kag.variable.sf.NoteContainer2.callCreateInference();
                           }
                           );
                        }
                    });
                }
            }
        }
        if (isModeDebate()) {
            
            elem_items.click(function() {
                if (mist_temp.is_tutorial) return;

                const id = $(this).attr("id");
                clearDoubtsNew(id);
                $(this).find("new").remove();
                that.createTextDialog(getCommonHelpDirect("deducation_debate"));
            });
        }
        if (isModeVote()) {
            
            elem_items.click(function() {
                if (mist_temp.is_tutorial) return;

                const id = $(this).attr("id");
                clearDoubtsNew(id);
                $(this).find("new").remove();
                that.createTextDialog(getCommonHelpDirect("deducation_vote"));
            });
        }

        
    }

    
    callCreateInference() {
        const doubt = getDoubt(mist_save.doubt_id);
        doubt.beginCreateAnswer();
        
        mist_system.FooterContainer.back();

        this.open_create_interfance = true;
        mist_temp.note_create_interfance_question_id = undefined;
        mist_temp.note_create_interfance_question_scroll = 0;
        mist_temp.note_create_interfance_time_id = undefined;
        mist_temp.note_create_interfance_time_scroll = 0;
        this.createQuestion();
    }

    
    getDoubtTagsHtml(doubt, empty, enable_modify=false, inferenceMode=false){
        let doubtTagHtmlList = []
        doubt.require_slots.forEach((slot, index, array) => {
            let colorIndex = 0;
            let image = "";
            let tyrano_focusable = "";
            let tabindex = "";
            const piece_id = doubt.getSlotData(index, inferenceMode);
            
            const tag_index = this.getTagIndex(slot);

            if(enable_modify) {
                tyrano_focusable = "tyrano-focusable";
                tabindex = 'tabindex="1"';
            }
            if(piece_id && !empty){
                const piece = getPiece(piece_id);
                const chr = getCharacter(piece.chara_id);
                colorIndex = chr.colorIndex();
                image = `data/image/${piece.resource}`;

                doubtTagHtmlList.push(`
<piece-frame type="1" id="${index}" class="color${colorIndex} ${tyrano_focusable} ${enable_modify && mist_save.selected_slot_tag && mist_save.current_slot == index ? `select` : ""} slot${index + 1}" ${tabindex}>
<icon style="background-image: url(${image});"></icon>
<name class="tag${tag_index}"></name>
<select-frame></select-frame>
<checkmark></checkmark>
</piece-frame>
                `);
            }else{
                doubtTagHtmlList.push(`
                      <piece-frame type="0" id="${index}" class="${tyrano_focusable} ${enable_modify && mist_save.selected_slot_tag && mist_save.current_slot == index ? `select` : ""} slot${index + 1}" ${tabindex} >
                          <name class="tag${tag_index}"></name>
                          <text>未設定</text>
                          <effect></effect>
                          <checkmark></checkmark>
                      </piece-frame>
                `);
            }

        });
        return doubtTagHtmlList.join("<cross></cross>");
    }

    getDoubtMiniHtml(doubt, inferenceMode, enable_modify=true){
        if(!doubt){ return ""; }
        let hasCharactor = getCharacter(doubt.chara_id);
        const player = getPlayer();
        if (hasCharactor == null) {
          if (player.id == doubt.chara_id) {
            hasCharactor = player;
          }
        }
        const color_index = hasCharactor.colorIndex();
        const icon_path = `data/${hasCharactor.doubtIconPath()}`;
        const is_answer_full = doubt.isAnswerFull(inferenceMode);
        const empty_answer = doubt.isEmptyAnswer(inferenceMode);
        let resultHtml =`
           <row1> 
                <circle class="color${color_index}">
                    <title>${hasCharactor.name}の疑問</title>
                </circle>
                <chara-image style="background-image: url(${icon_path});"></chara-image>
           </row1>
           <row2>
                <titlearea>
                    <title class="shadow-bold color${color_index}">${doubt.title}</title>
                </titlearea>
                <text>${doubt.desc}</text>
           </row2>`;


        
        const doubtTagsHtml = this.getDoubtTagsHtml(doubt, false, enable_modify, inferenceMode);

        resultHtml += `
                        <row3>
                            <doubt-title>推理に必要な手がかり</doubt-title>
                            <doubt-line></doubt-line>
                            <doubt-tags>
                                ${doubtTagsHtml}
                            </doubt-tags>
                        </row3>`;
        if(enable_modify){
            resultHtml += `
                        <row4>
                            <reset-button ${!empty_answer ? `type="0"`: `type="3"`} class="tyrano-focusable" tabindex="1">手がかりを外す</reset-button>
                            <ok-button ${is_answer_full ? `type="0"`: `type="3"`} class="tyrano-focusable" tabindex="1">推理する<effect></effect><check></check></ok-button>
                        </row4>`;
        }

        return resultHtml;
    }

    createQuestion(click_target, disable_select_chara_id, prohibition_ids, do_question) {
        this.save_cursor = true;
        const container = this.createContainer();
        this.createPiece(container, click_target, disable_select_chara_id, prohibition_ids, do_question);
        this.addTabEventOnlyPiece(container, click_target, disable_select_chara_id, prohibition_ids, do_question);
        mist_system.save_cursor_note_tab_index = 2;
    }

    createQuestionWithFade(click_target, disable_select_chara_id, prohibition_ids, do_question) {
        const that = this;

        
        this.callNextOrder = TYRANO.kag.stat.is_adding_text;
        stopGameProgress();

        this.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                this.createQuestion(click_target, disable_select_chara_id, prohibition_ids, do_question);
                that.fadeIn();
            });
        });
    }

    createQuestionTimeline(click_target, disable_select_chara_id, prohibition_ids, do_question) {
        this.save_cursor = true;
        const container = this.createContainer();
        this.createTime(container, click_target, disable_select_chara_id, prohibition_ids, do_question);
        this.addTabEventOnlyPiece(container, click_target, disable_select_chara_id, prohibition_ids);
        mist_system.save_cursor_note_tab_index = 3;
    }

    addTabEventOnlyPiece(container, click_target, disable_select_chara_id, prohibition_ids, do_question) {
        const piece = container.find("tab-piece");
        const time = container.find("tab-time");
        container.find("tab-summary").addClass("disable");
        container.find("tab-doubt").addClass("disable");
        container.find("tab-person").addClass("disable");
        container.find("tab-map").addClass("disable");
        const tabClickSe = "system/se_sys02.mp3";
        const tabList = [];
        tabList.push(piece);
        tabList.push(time);

        piece.click(() => {
            if (mist_temp.is_tutorial) return;

            for(let item of tabList) {
                item.removeClass("select");
            }
            mist_system.save_cursor_note_tab_index = 2;
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: tabClickSe, stop:true });
            this.createPiece(container, click_target, disable_select_chara_id, prohibition_ids, do_question);
        });
        piece.hover(() => {
            piece.addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            piece.removeClass("hover");
        });
        time.click(() => {
            if (mist_temp.is_tutorial) return;

            for(let item of tabList) {
                item.removeClass("select");
            }
            mist_system.save_cursor_note_tab_index = 3;
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: tabClickSe, stop:true });
            this.createTime(container, click_target, disable_select_chara_id, prohibition_ids, do_question);
        });
        time.hover(() => {
            time.addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            time.removeClass("hover");
        });

        
        const tabLeft = container.find("tab-left");
        tabLeft.click((e) => {
            if (mist_temp.is_tutorial) return;

            mist_system.NoteContainer2.tabLeftMove();
            e.stopPropagation();
        });
        tabLeft.hover((e) => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        },
        (e) => {
        });

        const tabRight = container.find("tab-right");
        tabRight.click((e) => {
            if (mist_temp.is_tutorial) return;

            mist_system.NoteContainer2.tabRightMove();
            e.stopPropagation();
        });
        tabRight.hover((e) => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        },
        (e) => {
        });
    }


    
    addTabEvent() {
        const tabClickSe = "system/se_sys02.mp3";
        const container = $("note-container2");
        const tabList = [];
        const summary = container.find("tab-summary");
        const doubt = container.find("tab-doubt");
        const piece = container.find("tab-piece");
        const time = container.find("tab-time");
        const person = container.find("tab-person");
        const map = container.find("tab-map");

        tabList.push(summary);
        tabList.push(doubt);
        tabList.push(piece);
        tabList.push(time);
        tabList.push(map);
        tabList.push(person);

        summary.click(() => {
            if (mist_temp.is_tutorial) return;

            for(let item of tabList) {
                item.removeClass("select");
            }
            this.createSummary(container);
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: tabClickSe, stop:true });
            if (this.save_cursor) {
                mist_system.save_cursor_note_tab_index = 0;
            }
        });
        summary.hover(() => {
            summary.addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            summary.removeClass("hover");
        });
        doubt.click(() => {
            if (mist_temp.is_tutorial) return;

            for(let item of tabList) {
                item.removeClass("select");
            }
            this.createDoubt(container);
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: tabClickSe, stop:true });
            if (this.save_cursor) {
                mist_system.save_cursor_note_tab_index = 1;
            }
        });
        doubt.hover(() => {
            doubt.addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            doubt.removeClass("hover");
        });
        piece.click(() => {
            if (mist_temp.is_tutorial) return;

            for(let item of tabList) {
                item.removeClass("select");
            }
            this.createPiece(container);
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: tabClickSe, stop:true });
            if (this.save_cursor) {
                mist_system.save_cursor_note_tab_index = 2;
            }
        });
        piece.hover(() => {
            piece.addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            piece.removeClass("hover");
        });
        time.click(() => {
            if (mist_temp.is_tutorial) return;

            for(let item of tabList) {
                item.removeClass("select");
            }
            this.createTime(container);
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: tabClickSe, stop:true });
            if (this.save_cursor) {
                mist_system.save_cursor_note_tab_index = 3;
            }
        });
        time.hover(() => {
            time.addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            time.removeClass("hover");
        });
        map.click(() => {
            if (mist_temp.is_tutorial) return;

            for(let item of tabList) {
                item.removeClass("select");
            }
            this.createMap(container);
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: tabClickSe, stop:true });
            if (this.save_cursor) {
                mist_system.save_cursor_note_tab_index = 4;
            }
        });
        map.hover(() => {
            map.addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            map.removeClass("hover");
        });
        person.click(() => {
            if (mist_temp.is_tutorial) return;

            for(let item of tabList) {
                item.removeClass("select");
            }
            this.createPerson(container);
            TYRANO.kag.ftag.startTag("PLAY_SE",{storage: tabClickSe, stop:true });
            if (this.save_cursor) {
                mist_system.save_cursor_note_tab_index = 5;
            }
        });
        person.hover(() => {
            person.addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            person.removeClass("hover");
        });

        
        const tabLeft = container.find("tab-left");
        tabLeft.click((e) => {
            if (mist_temp.is_tutorial) return;

            mist_system.NoteContainer2.tabLeftMove();
            e.stopPropagation();
        });
        tabLeft.hover((e) => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        },
        (e) => {
        });

        const tabRight = container.find("tab-right");
        tabRight.click((e) => {
            if (mist_temp.is_tutorial) return;

            mist_system.NoteContainer2.tabRightMove();
            e.stopPropagation();
        });
        tabRight.hover((e) => {
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        },
        (e) => {
        });
    }

    createMap(container) {
        this.unregisterFocus();

        const tab = container.find("tab-map");
        tab.addClass("select");
        tab.removeClass("disable");

        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("note_map") });
        const content = container.find("content");
        content.empty();
 
        const map_info = masterdata.get_map.filter(a => a.chapter == mist_save.chapter)[0];
        const map_name = map_info.name;
        const contents_html = `
            <map>
                <map-title>
                    ${(map_info.year && map_info.year.length > 0) ? `<element class="note-container2 year y${map_info.year}" style="transform: scale(0.8);"></element>`:""}
                    <text class="shadow-bold">${map_name}</text>
                </map-title>
                <map-title-line></map-title-line>
                <map-image style="background-image: url(${map_info.image_path});"></map-image>
                <empty></empty>
           </map>`;
        content.html(contents_html);
    }
    getMapHtml(map_id) {
        const map = masterdata.get_map.find(x => x.id == map_id);

        const map_name = map.name;
        const contents_html = `
            <map>
                <map-title>
                    ${(map.year && map.year.length > 0) ? `<element class="note-container2 year y${map.year}" style="transform: scale(0.8);"></element>`:""}
                    <text class="shadow-bold">${map_name}</text>
                </map-title>
                <map-title-line></map-title-line>
                <map-image style="background-image: url(${map.image_path});"></map-image>
                <empty></empty>
            </map>`;

        return contents_html;
    }

    
    personContentHtml(person){
        let result = "";

        let item_list = "";
        const visible_person = person.filter(p => existPersonInfo(p.group, p.year) == true);
        
        visible_person.sort(function(a, b) {return a.disporder - b.disporder});
        const info = visible_person[0];

        visible_person.forEach(p => {
            item_list += this.personContentItemHtml(p);
        });

        result = `
            <content class="person">
                <up class="shadow-bold">
                    <ruby>${TYRANO.kag.variable.tf.names[info.group].fullname}<rt>${TYRANO.kag.variable.tf.names[info.group].ruby}</rt></ruby>
                    <line></line>
                    <arrow></arrow>
                </up>
                <items>
                    ${item_list}
                </items>
            </content>`;
        return result;
    }
    personContentSingleHtml(group, year){
        const person = masterdata.note_person[group];
        let result = "";

        const visible_person = person.find(p => (p.group == group && p.year == year));
        result = `
            <content class="person">
                <items>
                    ${this.personContentItemHtml(visible_person)}
                </items>
            </content>`;
        return result;
    }
    personContentItemHtml(person_item) {
        return `
            <item id="${person_item.year}">
                <left>
                    <element class="note-container2 year y${person_item.year}" style="z-index: 1"></element>
                    <thumbnail style="background-image: url(${person_item.image});"></thumbnail>
                </left>
                <right>
                    <director>${person_item.director}</director>
                    <text>${person_item.memo}</text>
                </right>
                ${getPersonInfo(person_item.group).is_new_back ? "<new></new>" : ""}
            </item>`;
    }

    
    createHoverEventInPerson(container){
        const elem_items = container.find("name-box");
        elem_items.off();
        elem_items.hover(function() {
            $(this).addClass("select");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        },
        function() {
            $(this).removeClass("select");
        });
        elem_items.click(function() {
            if (mist_temp.is_tutorial) return;
            
            const element = $(this);
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            container.find("select-cursor").hide();
            element.find("select-cursor").show();
            const id = element.attr("id");
            const content = container.find("content > person > content");
            content.empty();
            const person_info = getPersonInfo(id);
            person_info.is_new_back = person_info.is_new;
            person_info.is_new = false;
            Common.setVisible(element.find('new'), person_info.is_new);
    
            const content_html = TYRANO.kag.variable.sf.NoteContainer2.personContentHtml(masterdata.note_person[id]);
            content.append(content_html);
            Common.setFocus(element);
        });
        for(let i = 0; i < elem_items.length; ++i) {
            Common.makeFocusable(elem_items.eq(i));
        }
        if (elem_items.length > 0) {
            if($('.mouse_disable').length > 0) {
                Common.setFocus(elem_items.eq(0));
            }
        }
    }

    
    createPerson(container) {
        this.unregisterFocus();
        const tab = container.find("tab-person");
        tab.addClass("select");
        tab.removeClass("disable");

        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("note_profile") });
        const content = container.find("content");
        content.empty();

        let name_html_list = "";
        let orderd_list = {};
        Object.keys(masterdata.note_person).forEach(chara_name_id => {
            const dipsorder  = Math.min(...masterdata.note_person[chara_name_id].map((p) => p.disporder));
            orderd_list[dipsorder] = chara_name_id;
        });

        
        let visible_flag = {};
        Object.keys(masterdata.note_person).forEach(chara_name_id => {
            visible_flag[chara_name_id] =  masterdata.note_person[chara_name_id].filter(p => existPersonInfo(p.group, p.year)).length > 0;
        });

        Object.keys(orderd_list).sort().forEach((disporder, index) => {
            const chara_name_id = orderd_list[disporder];
            if(!visible_flag[chara_name_id]) { return ; } 

            const key = `${mist_save.chapter}_${chara_name_id}`;
            const person_info = getPersonInfo(chara_name_id);
            person_info.is_new_back = person_info.is_new;
            name_html_list += `
                <name-box class="tyrano-focusable " id="${chara_name_id}" tabindex="-1">
                    ${person_info.is_new ? "<new></new>" : ""}
                    <select-cursor ${index == 0 ? "": `style="display:none"`}></select-cursor>
                    <name class="shadow-bold">${TYRANO.kag.variable.tf.names[chara_name_id].fullname}</name>
                </name-box>`;
        });

        
        const content_chara_id = orderd_list[Object.keys(orderd_list).sort()[0]];
        const content_html = this.personContentHtml(masterdata.note_person[content_chara_id]);
        const contents_html = `
            <person>
                <characters>
                    ${name_html_list}
                </characters>
                
                <content>
                    ${content_html}
                </content>
            </person>`;
        content.html(contents_html);
        this.createHoverEventInPerson(container);
    }

    createSummary(container)
    {
        this.unregisterFocus();
        const tab = container.find("tab-summary");
        tab.addClass("select");
        tab.removeClass("disable");

        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("note_summary") });
        const content = container.find("content");
        content.empty();
        const case_summary = masterdata.case_summary[mist_save.chapter];

        const year = "1991";
        const title = "写真館のぼや騒ぎ";
        const text = `${case_summary.text}`;
        
        const contents_html = `
            <summary>
                <summary-title>
                    ${(case_summary.year && case_summary.year.length > 0) ? `<element class="note-container2 year y${case_summary.year}" style="transform: scale(0.8);"></element>`:""}
                    <text class="shadow-bold">${case_summary.title}</text>
                </summary-title>
                <summary-title-line></summary-title-line>
                <summary-text>
                    ${text}
                </summary-text>
            </summary>`;
        content.html(contents_html);
    }

    setAllTabDisable(container)
    {
        container.find("tab-summary").addClass("disable");
        container.find("tab-doubt").addClass("disable");
        container.find("tab-person").addClass("disable");
        container.find("tab-map").addClass("disable");
        container.find("tab-piece").addClass("disable");
        container.find("tab-time").addClass("disable");

        container.find("tab-left").addClass("disable");
        container.find("tab-right").addClass("disable");
    }

    setAllTabCursor(container, cursor)
    {
        container.find("tab-summary").css("cursor", cursor);
        container.find("tab-doubt").css("cursor", cursor);
        container.find("tab-person").css("cursor", cursor);
        container.find("tab-map").css("cursor", cursor);
        container.find("tab-piece").css("cursor", cursor);
        container.find("tab-time").css("cursor", cursor);

        container.find("tab-left").css("cursor", cursor);
        container.find("tab-right").css("cursor", cursor);
    }

    createDoubtListForReportWithFade(click_target) {
        const that = this;
        this.help_text_tag = "select_doubt";

        
        this.callNextOrder = TYRANO.kag.stat.is_adding_text;
        stopGameProgress();

        this.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                that.createDoubtListForReport(click_target);
                that.fadeIn();
                mist_system.save_cursor_note_tab_index = 1;
            });
        });
    }

    createDoubtListForReport(click_target) {
        const container = this.createContainer();
        this.setAllTabDisable(container);
        this.createDoubt(container, enableReportDoubtList, click_target);
        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect(this.help_text_tag) });
        this.back_create_interfance_func = "createDoubtListForReport";
    }

    createDoubtListWithFade(click_target) {
        const that = this;
        this.help_text_tag = "deduction";

        
        this.callNextOrder = TYRANO.kag.stat.is_adding_text;
        stopGameProgress();

        this.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                that.createDoubtListForReport(click_target);
                that.fadeIn();
                mist_system.save_cursor_note_tab_index = 1;
            });
        });
    }

    createDoubtList(click_target) {
        const container = this.createContainer();
        this.setAllTabDisable(container);
        this.createDoubt(container, undefined, click_target);
        this.back_create_interfance_func = "createDoubtList";

        mist_system.FooterContainer.updateHelp({ help: getCommonHelpDirect("deduction") });
        
        this.callNextOrder = TYRANO.kag.stat.is_adding_text;
        stopGameProgress();
    }

    createDoubtNormal() {
        const container = this.createContainer();
        this.createDoubt(container);
        this.addTabEvent();
    }


    createView() {
        const that = this;
        that.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                that.save_cursor = true;
                const container = this.createContainer();
                if (!mist_system.config_is_save_cursor || !mist_system.save_cursor_note_tab_index) {
                    
                    that.createSummary(container);
                }
                else {
                    switch (mist_system.save_cursor_note_tab_index) {
                        case 0: that.createSummary(container); break;
                        case 1: that.createDoubt(container); break;
                        case 2: that.createPiece(container); break;
                        case 3: that.createTime(container); break;
                        case 4: that.createMap(container); break;
                        case 5: that.createPerson(container); break;
                        default: break;
                    }
                }
                that.addTabEvent();
    
                
                that.callNextOrder = TYRANO.kag.stat.is_adding_text;
                stopGameProgress();
    
                Common.removePreventScene("Note");
                that.fadeIn();
            });
        });
    }

    fadeOutContainer(time) {
        const container = $("note-container2");
        container.fadeOut(time);
    }

    getAnimationPlay(container, info, info_disp_callback, get_message_id) {
        const that = this;

        
        
        info.forEach((value, i, array) => {
            value.forEach((elem) => {
                Common.setVisible(elem, false);
            });
        });
        mist_system.FooterContainer.updateHelp({help: ""});
        mist_system.FooterContainer.hide();

        const note_in_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        this.fadeIn(() => {
            that.partAnimationPlay(container, info, 0, info_disp_callback, get_message_id);
        }, note_in_time);
    }

    partAnimationPlay(container, info, play_index, info_disp_callback, get_message_id)
    {
        const that = this;
        mist_system.FooterContainer.hide();
        container.removeClass("note-container2-click-next");
        container.off();
        const info_first_in_time = parseInt(Common.getDefineLabel("@note_acquire_info_fade_first_time"));
        const info_in_time = parseInt(Common.getDefineLabel("@note_acquire_info_fade_time"));
        const wait_time = parseInt(Common.getDefineLabel("@note_acquire_note_wait"));

        let total_time = 0;
        const part = info[play_index];
        for(let i = 0; i < part.length; ++i) {
            const in_time = i == 0 ? info_first_in_time : info_in_time;
            setTimeout(function() {
                if(info_disp_callback) {
                    
                    info_disp_callback(part[i], play_index, i);
                }
                Common.setVisible(part[i], true);
                part[i].hide();
                part[i].fadeIn(in_time);
            },
            total_time);
            total_time += in_time;
        }
        total_time += wait_time;

        
        setTimeout(function() {

            if(Common.isSkipAwaitInput()) {
                
                play_index += 1;
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                if(info.length <= play_index) {
                    that.getInfoCloseFooter(get_message_id);
                }
                else {
                    that.partAnimationPlay(container, info, play_index, info_disp_callback, get_message_id);
                }
                return;
            }
            container.addClass("note-container2-click-next");
            container.click(() => {
                
                container.off();

                play_index += 1;
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                if(info.length <= play_index) {
                    that.getInfoCloseFooter(get_message_id);
                }
                else {
                    that.partAnimationPlay(container, info, play_index, info_disp_callback, get_message_id);
                }
            });
        },
        total_time);
    }

    getInfoCloseFooter(msg_id) {
        const container = $("note-container2");
        container.removeClass("note-container2-click-next");
        const detail_dialog = $("note-container2 > div");
        if(detail_dialog) {
            detail_dialog.remove();
        }
        mist_system.FooterContainer.hide();
        
        const note_fade_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        
        this.closeFooterEvent(note_fade_time);
    }

    getQuestion(piece_id) {
        const that = this;

        
        this.callNextOrder = true;
        stopGameProgress();

        const note_in_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        this.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                const container = that.createContainer(
                    () => {
                        const container = $(".note-container2-click-next");
                        if(container.length > 0) {
                            container.click();
                        }
                    }
                );
                const is_mouse_disable = $("html").hasClass("mouse_disable");

                that.force_focus_id = piece_id;
                that.setAllTabDisable(container);
                if(mist_system.save_cursor_note_tab_index == 3) {
                    
                    that.createTime(container, "disable_click");
                }
                else {
                    mist_system.save_cursor_note_tab_index = 2;
                    that.createPiece(container, "disable_click");
                }

                container.find("item").addClass("grayout");
                $(`#${piece_id}`).removeClass('grayout');
                $(`#${piece_id}`).trigger('mouseover');
                $(`#${piece_id}`).removeClass("select");
                
                that.clearItemEvent(container);
                
                const elem_item_frames = container.find("item-frame,select-frame");
                elem_item_frames.css("cursor", "default");

                that.setAllTabCursor(container, "default");

                
                container.find("right-content > content").css("overflow-y", "hidden");
                if(!is_mouse_disable) {
                    $("html").removeClass("mouse_disable");
                    TYRANO.kag.key_mouse.util.setMouseHoverMask(false);
                }


                
                const targetPiece = $(`#${piece_id}`);
                const pieceInfo = container.find("content > pieces > left-content > info");

                that.getAnimationPlay(container, [[targetPiece, pieceInfo]], undefined, "msg_get_piece");
            });
        }, note_in_time);
    }

    setSelectPiece(piece_elem, show_detail=false) {
        const that = this;
        const id = piece_elem.attr("id");
        const color = Common.getClassByName(piece_elem.find("item-frame"), "color");
        const piece = getPiece(id);

        const info = $("note-container2 > content > pieces > left-content > info");
        info.removeClass(function(index, className) {
            return (className.match(/\bcolor\S+/g) || []).join(' ');
        });
        info.addClass(color);
        info.find("title").removeClass(function(index, className) {
            return (className.match(/\bcolor\S+/g) || []).join(' ');
        });
        info.find("title").addClass(color);
        info.find("title").html(piece.title);
        info.find("text").html(piece.desc);

        info.find("lens").remove();
        if($(this).find("lens").length > 0){
            info.append("<lens>");
        }
        info.find("warning").remove();
        if($(this).find("warning").length > 0){
            info.append("<warning>");
        }
        info.find("alert").remove();
        if($(this).find("alert").length > 0){
            info.append("<alert>");
        }
        const tags = Object.keys(piece.tag_list);
        const elem_tags = info.find("hash-tags");
        elem_tags.empty();
        tags.forEach(x => {
            const tag_index = that.getTagIndex(x);
            elem_tags.append(`<tag class="tag${tag_index}"></tag>`);
        });

        if(show_detail && piece.detail) {
            const detail_dialog = $("note-container2 > div");
            detail_dialog.find("img").attr("src", `data/image/${piece.detail}`);
        }
    }

    getQuestions(piece_ids, show_detail) {
        const that = this;

        
        this.callNextOrder = true;
        stopGameProgress();

        const note_fade_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        that.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                const container = that.createContainer(
                    () => {
                        const container = $(".note-container2-click-next");
                        if(container.length > 0) {
                            container.click();
                        }
                    }
                );

                const is_mouse_disable = $("html").hasClass("mouse_disable");

                that.setAllTabDisable(container);
                that.createPiece(container, "disable_click");
                
                
                that.clearItemEvent(container);
                const elem_item_frames = container.find("item-frame,select-frame");
                elem_item_frames.css("cursor", "default");

                that.setAllTabCursor(container, "default");

                
                const info = [];
                const pieceInfo = container.find("content > pieces > left-content > info");
                let detail_dialog = undefined;
                if(show_detail) {
                    
                    container.append(`<div class="note-dialog">
                    <piece-detail-window>
                        <img src="">
                    </piece-detail-window>
                    </div>`);
                    detail_dialog = $("note-container2 > div");
                    detail_dialog.hide();
                }
                for(let i = 0; i < piece_ids.length; ++i) {
                    const item = $(`#${piece_ids[i]}`);
                    const piece = getPiece(piece_ids[i]);
                    if(show_detail && piece.detail) {
                        info.push([item, pieceInfo]);
                        info.push([detail_dialog]);
                    }
                    else {
                        info.push([item, pieceInfo]);
                    }
                    item.hide();
                }

                if(!is_mouse_disable) {
                    $("html").removeClass("mouse_disable");
                    TYRANO.kag.key_mouse.util.setMouseHoverMask(false);
                }
                
                that.getAnimationPlay(container, info, (info, info_index, part_index) => {
                    if(detail_dialog == info) {
                        
                        mist_system.FooterContainer.show();
                        
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                    }
                    else if(part_index == 0) {
                        if(info_index != 0) {
                            
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "mysSE/se_mys17.mp3", stop: true });
                        }
                        
                        container.find("item").addClass("grayout");
                        info.removeClass("grayout");
                        
                        Common.setVisible(pieceInfo, false);
                        if(detail_dialog) {
                            detail_dialog.hide();
                        }
                        that.setSelectPiece(info, show_detail);
                    }
                }, "msg_get_piece");
            });
        }, note_fade_time);
    }

    getDoubt(doubt_id) {
        const that = this;

        
        this.callNextOrder = true;
        stopGameProgress();

        mist_system.save_cursor_note_tab_index = 1;
        const note_fade_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        that.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                const container = that.createContainer(
                    () => {
                        const container = $(".note-container2-click-next");
                        if(container.length > 0) {
                            container.click();
                        }
                    }
                );

                const is_mouse_disable = $("html").hasClass("mouse_disable");

                that.setAllTabDisable(container);
                that.createDoubt(container, undefined, "disable_click");
                
                that.clearItemEvent(container);
                container.find("item").addClass("grayout");
                
                that.setAllTabCursor(container, "default");
                
                const doubt_elem = $(`#${doubt_id}`);
                doubt_elem.removeClass("grayout");
                const row2 = doubt_elem.find("row2");
                const row3 = doubt_elem.find("row3");

                if(!is_mouse_disable) {
                    $("html").removeClass("mouse_disable");
                    TYRANO.kag.key_mouse.util.setMouseHoverMask(false);
                }

                that.getAnimationPlay(container, [[doubt_elem, row2, row3]], undefined, "msg_get_doubt");
            });
        }, note_fade_time);
    }

    getMap(map_id) {
        const that = this;

        
        this.callNextOrder = true;
        stopGameProgress();

        mist_system.save_cursor_note_tab_index = 4;
        const note_fade_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        that.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                const container = that.createContainer(
                    () => {
                        const container = $(".note-container2-click-next");
                        if(container.length > 0) {
                            container.click();
                        }
                    }
                );
                const is_mouse_disable = $("html").hasClass("mouse_disable");

                that.setAllTabDisable(container);
                that.createMap(container);

                that.setAllTabCursor(container, "default");

                if(!is_mouse_disable) {
                    $("html").removeClass("mouse_disable");
                    TYRANO.kag.key_mouse.util.setMouseHoverMask(false);
                }

                
                const map =  container.find('content > map');
                const map_master = masterdata.get_map.find(x => x.id == map_id);
                that.getAnimationPlay(container, [[map]], undefined, map_master.title);
            });
        }, note_fade_time);
    }

    getPerson(person_id, year) {
        const that = this;

        
        this.callNextOrder = true;
        stopGameProgress();

        mist_system.save_cursor_note_tab_index = 5;
        const note_fade_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        that.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                const container = that.createContainer(
                    () => {
                        const container = $(".note-container2-click-next");
                        if(container.length > 0) {
                            container.click();
                        }
                    }
                );

                const is_mouse_disable = $("html").hasClass("mouse_disable");

                that.setAllTabDisable(container);
                that.createPerson(container);
                const wait_time = Common.getDefineLabel("@note_acquire_fade_time");
                const content = container.find("content > person > content");
                content.empty();
                const content_html = that.personContentHtml(masterdata.note_person[person_id]);
                content.append(content_html);

                
                $("name-box").off();
                $("name-box").css("cursor", "default");

                that.setAllTabCursor(container, "default");

                if(!is_mouse_disable) {
                    $("html").removeClass("mouse_disable");
                    TYRANO.kag.key_mouse.util.setMouseHoverMask(false);
                }

                const person_content = container.find('content > person > content');
                const person_elem = container.find('content > items').find(`#${year}`);
                const left = person_elem.find("left");
                const right = person_elem.find("right");

                that.getAnimationPlay(container, [[person_content, person_elem, left, right]], undefined, "msg_get_person");
            });
        }, note_fade_time);

    }

    getPersons(person_id, years) {
        const that = this;

        
        this.callNextOrder = true;
        stopGameProgress();

        mist_system.save_cursor_note_tab_index = 5;
        const note_fade_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        that.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                const container = that.createContainer(
                    () => {
                        const container = $(".note-container2-click-next");
                        if(container.length > 0) {
                            container.click();
                        }
                    }
                );

                const is_mouse_disable = $("html").hasClass("mouse_disable");

                that.setAllTabDisable(container);
                that.createPerson(container);
                const content = container.find("content > person > content");
                content.empty();
                const content_html = that.personContentHtml(masterdata.note_person[person_id]);
                content.append(content_html);

                
                $("name-box").off();
                $("name-box").css("cursor", "default");

                that.setAllTabCursor(container, "default");

                if(!is_mouse_disable) {
                    $("html").removeClass("mouse_disable");
                    TYRANO.kag.key_mouse.util.setMouseHoverMask(false);
                }

                const person_content = container.find('content > person > content');
                const person_elem = container.find('content > items');
                that.getAnimationPlay(container, [[person_content, person_elem]], undefined, "msg_get_person");
            });
        }, note_fade_time);

    }

    getSummary() {
        const that = this;

        
        this.callNextOrder = true;
        stopGameProgress();

        mist_system.save_cursor_note_tab_index = 0;
        const note_fade_time = parseInt(Common.getDefineLabel("@note_acquire_note_fade_time"));
        that.fadeOut(() => {
            Common.preloadAll(that.storages, () => {
                const container = that.createContainer(
                    () => {
                        const container = $(".note-container2-click-next");
                        if(container.length > 0) {
                            container.click();
                        }
                    }
                );

                const is_mouse_disable = $("html").hasClass("mouse_disable");

                that.setAllTabDisable(container);
                that.createSummary(container);

                that.setAllTabCursor(container, "default");

                const summary = container.find('content > summary');
                
                if(!is_mouse_disable) {
                    $("html").removeClass("mouse_disable");
                    TYRANO.kag.key_mouse.util.setMouseHoverMask(false);
                }
                
                that.getAnimationPlay(container, [[summary]], undefined, "msg_get_summary");
            });
        }, note_fade_time);
    }

    clseNoteCallCreateInference() {
        const that = this;
        
        
        const doubt = getDoubt(mist_save.doubt_id);

        
        mist_save.selected_slot_tag = undefined;
        mist_save.current_slot = 0;

        if(mist_save.enalbe_playlog){
            if(!mist_save.playlog_inference){mist_save.playlog_inference = {};}
            if(!mist_save.playlog_inference[doubt.id]) { mist_save.playlog_inference[doubt.id] = {"披露回数": 0, "構築回数": 0};}
            mist_save.playlog_inference[doubt.id]["構築回数"] += 1;
        }

        const charactor = getCharacter(doubt.chara_id);
        
        if(charactor && mist_save.detective_mode && isModeInvestigation()){
            
            consumeCostTemp(Number(getInferenceCost(charactor.credit_level)));
        }
        mist_save.inference = getInferenceFromDoubt(doubt, false, true);
        addInference(mist_save.inference);
        clearCreationInference();
        doubt.setSolvePieces(mist_save.inference.id);
        mist_save.createdInference = true;
        doubt.solved = false;
        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys14.mp3", stop: true });

        const returnDoubtList = function() {
            mist_system.FooterContainer.back();
            
            that.open_create_interfance = false;
            
            TYRANO.kag.stat.f.doubt_id = "";
            
            if(that.back_create_interfance_func) {
                that[that.back_create_interfance_func]();
            }
            else {
                that.createDoubtNormal();
            }
        };

        if(isModeDebate()) {
            that.open_create_interfance = false;
            that.back_create_interfance_func = undefined;

            
            TYRANO.kag.stat.f.doubt_id = "";

            that.fadeOut(() => {
                that.clearContainer();
                that.fadeIn(() => {
                    Common.clearDialogLayer();
                    
                    TYRANO.kag.ftag.startTag("jump",{target: "*ReturnMain" });
                });
            });
        }else{
            if(!TYRANO.kag.stat.f.player_inference_count) { TYRANO.kag.stat.f.player_inference_count = {}; }
    	    if(!TYRANO.kag.stat.f.player_inference_count[doubt.id]){ TYRANO.kag.stat.f.player_inference_count[doubt.id] = 0;}
            TYRANO.kag.stat.f.player_inference_count[doubt.id] += 1;
            TYRANO.kag.stat.f.player_inference_complete[doubt.id] =  mist_save.inference.convince_level_index == 2;

            const now_cost = getCost();
            
            if(now_cost <= 0) {
                Common.clearDialogLayer();
                that.unregisterFocus();
  
                setTimeout(function(){
                    returnDoubtList();
                }, 10);
                return;
            }

            
            TYRANO.kag.stat.f.doubt = getDoubt(TYRANO.kag.stat.f.doubt_id);
            if(charactor.id != TYRANO.kag.stat.f.npc_key){
                TYRANO.kag.stat.f.doubt_id = "";
                
                
                setTimeout(function(){
                    
                    
                    that.unregisterFocus();
                    mist_system.Dialog.createMoveSecretForInference(() => {
                        that.open_create_interfance = false;
                        that.back_create_interfance_func = undefined;

                        TYRANO.kag.stat.f.doubt_id = "";
                        mist_system.DetectiveContainer.hideEffect();
                        that.fadeOut(() => {
                            
                            mist_system.DetectiveContainer.offSelectEvent();
                            
                            TYRANO.kag.ftag.startTag("mask", {"time":1, "stop": true});
                            that.clearContainer();
                            that.fadeIn(() => {
                                const script_path = getCharaScriptBasePath(TYRANO.kag.stat.f.doubt.chara_id) + "secret_main.ks";
                                const jump_pm = { storage: script_path, target: "" };
                                TYRANO.kag.ftag.startTag("jump", jump_pm);
                            });
                        });

                    }, () => {
                        returnDoubtList();
                    });
                },10);
            }
            else {
                
                TYRANO.kag.stat.f.doubt = doubt;
                
                setTimeout(function(){
                    
                    
                    that.unregisterFocus();
                    mist_system.Dialog.createCheckShowInference(() => {
                        that.open_create_interfance = false;
                        that.back_create_interfance_func = undefined;

                        that.fadeOut(() => {
                            that.not_clear_doubt_id = true;
                            that.clearContainer();
                            that.fadeIn(() => {
                                const script_path = "detective/select_doubt.ks";
                                const jump_pm = { storage: script_path, target: "*ShowInference" };
                                TYRANO.kag.ftag.startTag("jump", jump_pm);
                            });
                        });
                    }, () => {
                        returnDoubtList();
                    });
                },10);
            }
        }
    }

    
    tabLeftMove() {
        return this.tabMove("left");
    }

    
    tabRightMove() {
        return this.tabMove("right");
    }

    
    tabMove(moveDir) {
        let ret = false;
        const container = $("note-container2");
        if(container.length > 0) {
            const tabEle = [];
            tabEle.push(container.find("tab-summary"));
            tabEle.push(container.find("tab-doubt"));
            tabEle.push(container.find("tab-piece"));
            tabEle.push(container.find("tab-time"));
            tabEle.push(container.find("tab-map"));
            tabEle.push(container.find("tab-person"));

            const select_index = tabEle.findIndex(x => x.hasClass("select"));
            let nextElement = undefined;
            if(moveDir == "left") {
                for(let i = 0; i < tabEle.length; ++i) {
                    let index = select_index - (i + 1);
                    if(index < 0) {
                        index += tabEle.length;
                    }
                    if(!tabEle[index].hasClass("disable")) {
                        nextElement = tabEle[index];
                        break;
                    }
                }
            }
            else if(moveDir == "right") {
                for(let i = 0; i < tabEle.length; ++i) {
                    let index = select_index + (i + 1);
                    if(index >= tabEle.length) {
                        index -= tabEle.length;
                    }
                    if(!tabEle[index].hasClass("disable")) {
                        nextElement = tabEle[index];
                        break;
                    }   
                }
            }
            if(nextElement) {
                nextElement.click();
                ret = true;
            }
        }
        return ret;
    }

    openPieceDetailWindow()
    {
        let ret = false;
        const container = $("note-container2");
        if(container.length > 0) {
            const pieces = container.find("pieces");
            if(pieces.length > 0) {
                const select_peice = pieces.find("item.select");
                if(select_peice.length > 0) {
                    const lens = select_peice.find("lens");
                    if(lens.length > 0) {
                        lens.click();
                        ret = true;
                    }
                }
            }
        }
        return ret;
    }

    setCloseButtonLable(label) {
        this.returnLabel = label;
    }

    startQuestion(click_target, disable_select_chara_id, prohibition_ids, do_question) {
        this.question_start = true;
        this.is_tab_memory = true;
        const that = this;
        this.fadeOut(() => {
            if ((mist_system.config_is_save_cursor && mist_system.save_cursor_note_tab_index == 3)
                || !this.is_question) {
                this.createQuestionTimeline(click_target, disable_select_chara_id, prohibition_ids, do_question);
                mist_system.save_cursor_note_tab_index = 3;
            }
            else {
                this.createQuestion(click_target, disable_select_chara_id, prohibition_ids, do_question);
                mist_system.save_cursor_note_tab_index = 2;
            }
            that.fadeIn();
        });
    }

    pauseQuestionMemory() {
        this.is_tab_memory = false;
    }

    appendInferenceModeButton(inference_mode_node_list) {
        
        const doubt = $("note-container2 > content > pieces > left-content > doubt");
        inference_mode_node_list.push(doubt.find("ok-button"));
        inference_mode_node_list.push(doubt.find("reset-button"));
        const piece_frame0 = doubt.find("doubt-tags > piece-frame#0");
        if(piece_frame0.length > 0) {
            inference_mode_node_list.push(piece_frame0);
        }
        const piece_frame1 = doubt.find("doubt-tags > piece-frame#1");
        if(piece_frame1.length > 0) {
            inference_mode_node_list.push(piece_frame1);
        }
        const piece_frame2 = doubt.find("doubt-tags > piece-frame#2");
        if(piece_frame2.length > 0) {
            inference_mode_node_list.push(piece_frame2);
        }
    }

    registerFocus(focusKey, element_node_list, element_index_list, inference_mode_node_list)
    {
        this.element_ids = [];
        const element_input_list = [];
        for(let i = 0; i < element_node_list.length; ++i) {
            this.element_ids.push(element_node_list[i].attr("id"));
            const element_input = [i, i, i, i];
            let row = -1;
            let col = -1;
            for(let j = 0; j < element_index_list.length; ++j) {
                col = element_index_list[j].findIndex(x => x == i);
                if(col >= 0) {
                    row = j;
                    break;
                }
            }

            
            for(let j = 1; j < element_index_list[row].length; ++j) {
                const targetCol = (col - j + element_index_list[row].length) % element_index_list[row].length;
                if(element_index_list[row][targetCol] >= 0) {
                    element_input[0] = element_index_list[row][targetCol];
                    break;
                }
            }
            if(element_input[0] == i) {
                for(let j = 1; j < element_index_list[row].length; ++j) {
                    let targetCol = (col - j + element_index_list[row].length) % element_index_list[row].length;
                    for(let k = 1; k < Math.ceil(element_index_list.length / 2); ++k) {
                        const targetRow2 = row - k;
                        const targetRow1 = row + k;
                        
                        if(targetRow2 >= 0 && element_index_list[targetRow2][targetCol] >= 0) {
                            element_input[0] = element_index_list[targetRow2][targetCol];
                            break;
                        }
                        if(targetRow1 < element_index_list.length && element_index_list[targetRow1][targetCol] >= 0) {
                            element_input[0] = element_index_list[targetRow1][targetCol];
                            break;
                        }
                    }
                    if(element_input[0] != i) {
                        break;
                    }
                }
            }

            
            for(let j = 1; j < element_index_list[row].length; ++j) {
                const targetCol = (col + j) % element_index_list[row].length;
                if(element_index_list[row][targetCol] >= 0) {
                    element_input[1] = element_index_list[row][targetCol];
                    break;
                }
            }
            if(element_input[1] == i) {
                for(let j = 1; j < element_index_list[row].length; ++j) {
                    let targetCol = (col + j) % element_index_list[row].length;
                    for(let k = 1; k < Math.ceil(element_index_list.length / 2); ++k) {
                        const targetRow2 = row - k;
                        const targetRow1 = row + k;
                        
                        if(targetRow2 >= 0 && element_index_list[targetRow2][targetCol] >= 0) {
                            element_input[1] = element_index_list[targetRow2][targetCol];
                            break;
                        }
                        if(targetRow1 < element_index_list.length && element_index_list[targetRow1][targetCol] >= 0) {
                            element_input[1] = element_index_list[targetRow1][targetCol];
                            break;
                        }
                    }
                    if(element_input[1] != i) {
                        break;
                    }
                }
            }

            
            for(let j = 1; j < element_index_list.length; ++j) {
                let targetRow = row - j;
                if(targetRow < 0) {
                    targetRow = (targetRow + element_index_list.length) % element_index_list.length;
                }
                if(element_index_list[targetRow][col] >= 0) {
                    element_input[2] = element_index_list[targetRow][col];
                    break;
                }
            }
            if(element_input[2] == i) {
                for(let j = 1; j < element_index_list.length; ++j) {
                    let targetRow = (row - j + element_index_list.length) % element_index_list.length;
                    for(let k = 1; k < Math.ceil(element_index_list[row].length / 2); ++k) {
                        const targetCol2 = col - k;
                        const targetCol1 = col + k;
                        
                        if(targetCol2 >= 0 && element_index_list[targetRow][targetCol2] >= 0) {
                            element_input[2] = element_index_list[targetRow][targetCol2];
                            break;
                        }
                        if(targetCol1 < element_index_list[targetRow].length && element_index_list[targetRow][targetCol1] >= 0) {
                            element_input[2] = element_index_list[targetRow][targetCol1];
                            break;
                        }
                    }
                    if(element_input[2] != i) {
                        break;
                    }
                }
            }

            
            for(let j = 1; j < element_index_list.length; ++j) {
                let targetRow = (row + j);
                if(targetRow >= element_index_list.length) {
                    targetRow = targetRow % element_index_list.length;
                }
                if(element_index_list[targetRow][col] >= 0) {
                    element_input[3] = element_index_list[targetRow][col];
                    break;
                }
            }
            if(element_input[3] == i) {
                for(let j = 1; j < element_index_list.length; ++j) {
                    let targetRow = (row + j) % element_index_list.length;
                    for(let k = 1; k < Math.ceil(element_index_list[row].length / 2); ++k) {
                        const targetCol2 = (col - k);
                        const targetCol1 = (col + k);
                        if(targetCol2 >= 0 && element_index_list[targetRow][targetCol2] >= 0) {
                            element_input[3] = element_index_list[targetRow][targetCol2];
                            break;
                        }
                        if(targetCol1 < element_index_list[targetRow].length && element_index_list[targetRow][targetCol1] >= 0) {
                            element_input[3] = element_index_list[targetRow][targetCol1];
                            break;
                        }
                    }
                    if(element_input[3] !=  i) {
                        break;
                    }
                }
            }
            element_input_list.push(element_input);
        }

        
        if(inference_mode_node_list && inference_mode_node_list.length > 0) {
            let leftRowTop = -1;
            let leftRow = -1;
            let rightRowTop = -1;
            let rightRow = -1;
            for(let i = 0; i < element_index_list.length; ++i) {
                for(let j = 0; j < element_index_list[i].length; ++j) {
                    if(element_index_list[i][j] >= 0) {
                        leftRowTop = element_index_list[i][j];
                        leftRow = i;
                        break;
                    }
                }
                if(leftRowTop >= 0) {
                    break;
                }
            }
            for(let i = element_index_list.length - 1; i >= 0; --i) {
                for(let j = 0; j < element_index_list[i].length; ++j) {
                    if(element_index_list[i][j] >= 0) {
                        rightRowTop = element_index_list[i][j];
                        rightRow = i;
                        break;
                    }
                }
                if(rightRowTop >= 0) {
                    rightRow = i;
                    break;
                }
            }

            const okbutton_index = element_node_list.length;
            const resetbutton_index = okbutton_index + 1;
            const piece_frame0_index = resetbutton_index + 1;
            const piece_frame1_index = piece_frame0_index + 1;
            const piece_frame2_index = piece_frame1_index + 1;
            const exist_piece_frame1 = inference_mode_node_list.length >= 4;
            const exist_piece_frame2 = inference_mode_node_list.length >= 5;

            let right_piece_index = piece_frame2_index;
            if(!exist_piece_frame2) {
                right_piece_index = piece_frame1_index;
            }
            if(!exist_piece_frame1) {
                right_piece_index = piece_frame0_index;
            }

            if(focusKey == "timeline") {
                for(let j = 0; j < element_index_list[leftRow].length; j++) {
                    
                    if(element_index_list[leftRow][j] >= 0) {
                        element_input_list[element_index_list[leftRow][j]][2] = right_piece_index;
                    }
                }
                for(let j = 0; j < element_index_list[rightRow].length; j++) {
                    
                    if(element_index_list[rightRow][j] >= 0) {
                        element_input_list[element_index_list[rightRow][j]][3] = piece_frame0_index;
                    }
                }
            } else {
                for(let j = 0; j < element_index_list[0].length; j++) {
                    for(let i = 0; i < element_index_list.length; i++) {
                        
                        if(element_index_list[i][j] >= 0) {
                            element_input_list[element_index_list[i][j]][2] = right_piece_index;
                            break;
                        }
                    }
                }
                for(let j = 0; j < element_index_list[0].length; j++) {
                    for(let i = element_index_list.length - 1; i >= 0; i--) {
                        
                        if(element_index_list[i][j] >= 0) {
                            element_input_list[element_index_list[i][j]][3] = piece_frame0_index;
                            break;
                        }
                    }
                }
            }

            for(let i = 0; i < inference_mode_node_list.length; ++i) {
                element_node_list.push(inference_mode_node_list[i]);
            }
            
            element_input_list.push([right_piece_index, right_piece_index, resetbutton_index, resetbutton_index]);
            element_input_list.push([piece_frame0_index, piece_frame0_index, okbutton_index, okbutton_index]);
            
            if(exist_piece_frame2) {
                element_input_list.push([resetbutton_index, resetbutton_index, -1, piece_frame1_index]);
                element_input_list.push([okbutton_index, okbutton_index, piece_frame0_index, piece_frame2_index]);
                element_input_list.push([okbutton_index, okbutton_index, piece_frame1_index, -1]);
            } else if(exist_piece_frame1) {
                element_input_list.push([resetbutton_index, resetbutton_index, -1, piece_frame1_index]);
                element_input_list.push([okbutton_index, okbutton_index, piece_frame0_index, -1]);
            } else {
                element_input_list.push([resetbutton_index, resetbutton_index, -1, leftRowTop]);
            }
            this.okbutton_index = okbutton_index;
            this.piece_frame_indexs = [piece_frame0_index, piece_frame1_index, piece_frame2_index];
        }

        
        let defaultIndex = 0;
        if(focusKey != "doubt") {
            const right_content = $("note-container2 > content > pieces > right-content > content");
            if(this.force_focus_id) {
                const index = this.element_ids.findIndex(x => x == this.force_focus_id);
                if(index >= 0) {
                    
                    let top = $(`#${this.force_focus_id}`).position().top - 90;
                    defaultIndex = index;
                    right_content.scrollTop(top <= 0 ? 0 : top);
                }
                
                this.force_focus_id = undefined;
            }
            else if(this.default_focus_piece_frame_no !== undefined && this.piece_frame_indexs) {
                defaultIndex = this.piece_frame_indexs[this.default_focus_piece_frame_no];
                right_content.scrollTop(this.default_focus_piece_scroll_top);

                this.default_focus_piece_scroll_top = undefined;
                this.default_focus_piece_frame_no = undefined;
            }
            else if (this.open_create_interfance || this.question_start) {
                
                if (focusKey == "pieces" && mist_temp.note_create_interfance_question_id) {
                    
                    right_content.scrollTop(mist_temp.note_create_interfance_question_scroll);
                    const index = this.element_ids.findIndex(x => x == mist_temp.note_create_interfance_question_id);
                    if(index >= 0) {
                        defaultIndex = index;
                    }
                }
                else if (mist_temp.note_create_interfance_time_id) {
                    
                    right_content.scrollTop(mist_temp.note_create_interfance_time_scroll);
                    const index = this.element_ids.findIndex(x => x == mist_temp.note_create_interfance_time_id);
                    if(index >= 0) {
                        defaultIndex = index;
                    }
                }
            }
        }
        
        this.noteFocusManager = new FocusManager(focusKey, element_node_list, element_input_list, defaultIndex);
    }

    unregisterFocus(is_clear = true) {
        if(this.noteFocusManager) {
            this.noteFocusManager.unregisterFocus();
            if(is_clear) {
                this.noteFocusManager = undefined;
                this.element_ids = undefined;
                this.piece_frame_indexs = undefined;
                this.okbutton_index = undefined;
            }
        }
    }

    reRegisterFocus() {
        if(this.noteFocusManager) {
            this.noteFocusManager.registerFocus();
            this.noteFocusManager.setLastFocus();
        }
    }

    setLastIndex(id) {
        if(this.noteFocusManager && this.noteFocusManager.uncontrollable) {
            const index = this.element_ids.findIndex(x => x == id);
            if(index >= 0) {
                this.noteFocusManager.setLastIndex(index);
            }
        }
    }

    setFocusOkButton() {
        if(this.noteFocusManager && this.okbutton_index) {
            this.noteFocusManager.setFocusIndex(this.okbutton_index);
        }
    }

    setFocusPieceFrame(no) {
        if(this.noteFocusManager && this.piece_frame_indexs && this.piece_frame_indexs.length > no) {
            this.noteFocusManager.setFocusIndex(this.piece_frame_indexs[no]);
        }
    }

    setFocusElement(id) {
        if(this.noteFocusManager && this.element_ids) {
            const search_id = id ? id : this.element_ids[0];
            const index = this.element_ids.findIndex(x => x == id);
            this.noteFocusManager.setFocusIndex(index >= 0 ? index : 0);
        }
    }
}
 
Common.sfAddClass(new NoteContainer2());
 
