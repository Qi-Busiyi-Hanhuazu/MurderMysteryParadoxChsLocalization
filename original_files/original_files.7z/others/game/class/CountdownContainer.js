
class CountdownContainer
{
    container_name = "mist-countdown-container";
	intervalId = 0;
    elapsed_time = 0;
	param = {
		interval: 33,
        start: 4000,
	};
    storages = [
        `data/image/adv/common/countdown/0.png`,
        `data/image/adv/common/countdown/1.png`,
        `data/image/adv/common/countdown/2.png`,
        `data/image/adv/common/countdown/3.png`,
        `data/image/adv/common/countdown/4.png`,
        `data/image/adv/common/countdown/5.png`,
        `data/image/adv/common/countdown/6.png`,
        `data/image/adv/common/countdown/7.png`,
        `data/image/adv/common/countdown/8.png`,
        `data/image/adv/common/countdown/9.png`,
        `data/image/adv/common/countdown/dot.png`,
        `data/image/adv/common/countdown/label.png`,
        `data/image/adv/common/countdown/small/0.png`,
        `data/image/adv/common/countdown/small/1.png`,
        `data/image/adv/common/countdown/small/2.png`,
        `data/image/adv/common/countdown/small/3.png`,
        `data/image/adv/common/countdown/small/4.png`,
        `data/image/adv/common/countdown/small/5.png`,
        `data/image/adv/common/countdown/small/6.png`,
        `data/image/adv/common/countdown/small/7.png`,
        `data/image/adv/common/countdown/small/8.png`,
        `data/image/adv/common/countdown/small/9.png`,

    ];

	constructor() { }

	load(){
        this.stop();
        this.intervalId = -1;
	}

    create()
    {
		let layer = TYRANO.kag.layer.getFreeLayer();

        const before_container = layer.find(`${this.container_name}`);
        if(before_container.length > 0) {
			this.stop();
        }

        
        let elem = $(`
			<${this.container_name}>
				<content>
					<img srd="" id="label"><img src="" id="sec10"><img src="" id="sec1"><img src="" id="dot"><img src="" id="msec10"><img src="" id="msec1">
				</content>
			</${this.container_name}>
		`);
		if(typeof layer === 'undefined'){
			console.error(`${this.layer_name} is not defined`)
			return ;
		}
        layer.append(elem);
        layer.show();
        layer.attr("ignore_visble", true);
    }

    
    start(mp)
    {
     	this.stop();
		const layer = TYRANO.kag.layer.getFreeLayer();
        let container = $(`${this.container_name}`);
		if(typeof layer === 'undefined' || container.length == 0){
			this.create();
            container = $(`${this.container_name}`);
		}

        if (container.length == 0){ 
			console.error('Countcown再生用レイヤーが作成できませんでした');
			return ;
		}

		let pm = Object.assign({}, this.param);
		pm = Object.assign(pm, mp);

        Common.preloadAll(this.storages, () => {
        	this.intervalId = setInterval(() =>{ this.proc(pm.start, pm.interval); }, Number(pm.interval));
        });
    }

	
	proc(start, time)
	{
		this.elapsed_time += time;
		let current = start - this.elapsed_time;
		if(current < 0 ){ current = 0; }
		const sec = parseInt(current / 1000);
		const msec = String(parseInt(current % 1000)).slice(0,2);

		const sec10 = this.storages[parseInt(sec / 10)];
		const sec1 = this.storages[parseInt(sec % 10)];
		const msec10 = this.storages[12+parseInt(msec / 10)];
		const msec1 = this.storages[12+parseInt(msec % 10)];
		const dot = this.storages[10];
		const label = this.storages[11];

		$(`${this.container_name} #label`).attr('src', label);
		$(`${this.container_name} #sec10`).attr('src', sec10);
		$(`${this.container_name} #sec1`).attr('src', sec1);
		$(`${this.container_name} #dot`).attr('src', dot);
		$(`${this.container_name} #msec10`).attr('src', msec10);
		$(`${this.container_name} #msec1`).attr('src', msec1);
	}

    
	stop()
	{
        if(this.intervalId > 0){
    		clearInterval(this.intervalId);
            this.intervalId = 0;
        }
		this.elapsed_time = 0;

        $(`${this.container_name}`).remove();
        
        

	}
}
Common.sfAddClass(new CountdownContainer());
