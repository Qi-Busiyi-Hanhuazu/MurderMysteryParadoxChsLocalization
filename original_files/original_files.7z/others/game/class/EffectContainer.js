
class EffectContainer
{
	intervalId = 0;
	
	layer_name = 'message11';
	param = {
		interval: 33,
		w: 512, 
        h: 256, 
        col: 4, 
        max: 32, 
        num: 0, 
		loop: true, 
        continue: false, 
        loop_begin: 0, 
        loop_end: -1, 
	};

	constructor() { }

	load(){
        this.stopAnimation();
        this.intervalId = -1;

        const img = $('mist-effect-container img');
        if (img.length == 0) return ;
        const pm = JSON.parse(img.attr('data-event-pm'));
        if (!pm) { return this.delete();} 
        this.intervalId = setInterval(() =>{ this.change(img); }, Number(pm.interval));
	}

    create()
    {
        
        const elem = $(`<mist-effect-container><sprite><img src="" id="effectImgId"></sprite></mist-effect-container>`);
		let layer = TYRANO.kag.layer.getLayer(this.layer_name, "fore");
		if(typeof layer === 'undefined'){
			console.error(`${this.layer_name} is not defined`)
			return ;
		}
        
        layer.find(".message_outer").remove();
        if(this.layer_name == "message11") {
            
            layer.find(".message_inner").hide();
            
            layer.find(".message_inner_original").hide();
            layer.find(".secret-talk-container").hide();
            layer.find("detective-new-container").hide();
        }
        else {
            layer.find(".message_inner").remove();
        }

		layer.css({'z-index': 10}); 
        layer.append(elem);
        layer.show();
        layer.attr("ignore_visble", true);
    }

    
    startEffect(file, mp)
    {
		let layer = TYRANO.kag.layer.getLayer(this.layer_name);
        let img = $('mist-effect-container img');
		if(typeof layer === 'undefined' || img.length == 0){
			this.create();
			img = $('mist-effect-container img');
		}

        if (img.length == 0){ 
			console.error('Effect再生用レイヤーが作成できませんでした');
			return ;
		}

        this.stopAnimation();
        this.intervalId = -1;

		let pm = Object.assign({}, this.param);
		pm = Object.assign(pm, mp);
        if(pm.loop_end == -1) { pm.loop_end = pm.max; }
        $('mist-effect-container > sprite').css({"height":pm.h, "width":pm.w});
        
        const scale_w = (Number(TYRANO.kag.config.scWidth) + 4) / Number(pm.w); 
        const scale_h = (Number(TYRANO.kag.config.scHeight) + 4) / Number(pm.h); 
        $('mist-effect-container > sprite').css("transform", `scale(${scale_w}, ${scale_h})`);

        img.attr("data-event-tag", "MIST_SERIALIZABLE");
        img.attr("data-event-pm", JSON.stringify(pm));
        if(!pm.continue){
    		img.attr('src', "");
    		img.hide();
        }
        img.on("load", (e) => {
            
            img[0].decode().then(() => {
                if(this.intervalId != -1){
                    
             		clearInterval(this.intervalId);
                     this.intervalId = -1;
                }
                let img = $('mist-effect-container img');
                img.show();
        		const pm = JSON.parse(img.attr('data-event-pm'));
        	    this.intervalId = setInterval(() =>{ this.change(img); }, Number(pm.interval));
                if(pm.playse){
                    setTimeout(() =>{ playSeRoundrobin(pm.playse, true); }, Number(pm.interval));
                }
            });
        });
		img.attr('src', file);
    }

    
	stopEffect()
	{
        if(this.intervalId > 0){
    		clearInterval(this.intervalId);
            this.intervalId = 0;
        }

        $('mist-effect-container').remove();
        let layer = TYRANO.kag.layer.getLayer(this.layer_name, "fore");
        layer.attr("ignore_visble", "");

	}

    
    change(target){
		let pm = JSON.parse(target.attr('data-event-pm'));
        if(this.dirty_param !== undefined){
            pm = Object.assign(pm, this.dirty_param);
            delete this.dirty_param;
        }
		let num = Number(pm.num) + 1;
        if( num >= Number(pm.loop_end) ){
			if(Common.toBool(pm.loop)){
	            num = pm.loop_begin;
			}else{
                this.stopEffect();
                return ;
			}
        }else{
			let col = Number(pm.col);
            target.css({
                'top': Math.floor(num / col) * Number(pm.h) * -1 + 'px',
                'left': num % col * Number(pm.w) * -1 + 'px'
            });
        }
		pm.num = num;
        target.attr("data-event-pm", JSON.stringify(pm));
    }

	delete(){
		clearInterval(this.intervalId);
        this.intervalId = 0;
        $('mist-effect-container').remove();
        let layer = TYRANO.kag.layer.getLayer(this.layer_name, "fore");
        layer.attr("ignore_visble", "");
	}

    stopAnimation(){
        if(this.intervalId != 0){
    		clearInterval(this.intervalId);
            this.intervalId = 0;
        }
    }

    playToFinish(){
        const target = $('mist-effect-container img');
        if (target.length == 0) return ;
		const pm = JSON.parse(target.attr('data-event-pm'));
        this.dirty_param = {
            loop_end: pm.max,
            loop: false
        }
    }
}
Common.sfAddClass(new EffectContainer());



class EffectContainerBG extends EffectContainer {
	layer_name = 'base';
}
Common.sfAddClass(new EffectContainerBG());

