
class TitleView {
	constructor() {
		
		if (mist_system.chapters == undefined) {
			mist_system.chapters = {};
		}
		masterdata.chapter.forEach(x => {
			if(!(x.chapter_id in mist_system.chapters)) {
				mist_system.chapters[x.chapter_id] = { is_release: false, is_new: true };
			}
		});
		mist_temp.title_last_focus_index = TYRANO.kag.menu.existSaveData() ? 1 : 0;
		this.createView();
	}

	createHtml() {
		const is_all_clear = mist_system.is_clear_scenario && mist_system.is_clear_bonus_scenario;
		const exist_save = TYRANO.kag.menu.existSaveData();

		
		const store = mist_save.trial_version ? `<div class="title-open-steam" letter="13"><p style="width:480px; height:100%;">Steam®︎ストアページを開く</p><line style="visibility: hidden;"></line><cursor style="visibility: hidden;"></check></div>` : ``;
		const logo =  mist_save.trial_version ? "data/image/title/new/logo_trial.png" : "data/image/title/new/logo.png";

		
		
		
		
		
		return $(`
<div class="title-container">
	<video src="data/video/en011.mp4" style="width: 1920px;" loop autoplay muted></video>
	<title-grid-container>
		<div class="title-logo"><img src="${logo}" style="width: 1050px; height: 426px;" /></div>
		<div class="title-start" letter="5"><p style="width:380px; height:100%;">はじめから</p><line style="visibility: hidden;"></line><cursor style="visibility: hidden;"></cursor></div>
		<div class="title-load ${(exist_save || mist_save.trial_version) ? '' : 'grayout'}" letter="5"><p style="width:380px; height:100%;">つづきから</p><line style="visibility: hidden;"></line><cursor style="visibility: hidden;"></cursor></div>
		<div class="title-chapter" letter="9">
			<new></new>
			<p style="width:380px; height:100%;">チャプターセレクト</p>
			<badge>
				<number>1</number>
				<video class="layer_blend_mode blendlayer blendvideo" style="position: relative; width: 80px; height: 80px; background-color: black; top: -62px; left: -26px; background-size: cover; mix-blend-mode: screen;" src="./data/video/ef025.mp4" autoplay="" playsinline="1" loop=""></video>
			</badge>
			<line style="visibility: hidden;"></line>
			<cursor style="visibility: hidden;"></cursor>
		</div>
		<div class="title-collection" letter="6">
			<new></new>
			<p style="width:380px; height:100%;">コレクション</p>
			<line style="visibility: hidden;"></line>
			<cursor style="visibility: hidden;"></cursor>
		</div>
		<div class="title-option" letter="5"><p style="width:380px; height:100%;">オプション</p><line style="visibility: hidden;"></line><cursor style="visibility: hidden;"></cursor></div>
		${store}
		<div class="title-end" letter="8"><p style="width:380px; height:100%;">ゲームを終了する</p><line style="visibility: hidden;"></line><cursor style="visibility: hidden;"></cursor></div>
	</title-grid-container>
	
	${is_all_clear ? `<end></end><end-copy-right></end-copy-right>` : `<copy-right></copy-right>`}
</div>`);
	}

	createView() {
		
		Common.resetTempVolume();
		applyAutoSpeedWithText();

		
		mist_save.chapter_select_start = false;

		
		mist_system.FooterContainer.hide();
		const layer = TYRANO.kag.layer.getFreeLayer();
		layer.show();
		layer.append(this.createHtml());

		if (!mist_system.is_clear_scenario || mist_save.trial_version) {
			layer.find(".title-chapter").hide();
			layer.find(".title-collection").hide();
		}
		else {
			Common.setVisible(layer.find(".title-chapter > new"), !mist_system.open_chapter);
			Common.setVisible(layer.find(".title-collection > new"), !mist_system.open_collection);
		}

		
		this.updateBadge();

		const that = this;
		if (mist_system.is_clear_scenario && !mist_system.is_play_release_chapter) {
			const wait_time = parseInt(Common.getDefineLabel("@title_messaging_wait"));
			Common.setVisible(layer.find(".title-chapter > new"), true);
			Common.setVisible(layer.find(".title-collection > new"), true);
			setTimeout(() => {
				
				mist_system.Dialog.createTextDialog(getCommonHelpDirect("release_chapter_collection_1"), undefined, false, () => {
					setTimeout(() => {
						mist_system.Dialog.createTextDialog(getCommonHelpDirect("release_chapter_collection_2"), undefined, true, () => {
							mist_system.is_play_release_chapter = true;
							Common.new_help("44", "true");
							Common.new_help("45", "true");
							Common.saveSystem();
							that.addEvent();
						});
					}, wait_time);
				});
			}, 1000);

		}
		else if (mist_system.chapters["extra"] && mist_system.chapters["extra"].is_release && !mist_system.is_play_release_bonus) {
			Common.setVisible(layer.find(".title-chapter > badge"), false);
			const wait_time = parseInt(Common.getDefineLabel("@title_messaging_wait"));
			setTimeout(() => {
				
				mist_system.Dialog.createTextDialog(getCommonHelpDirect("release_extra_1"), undefined, false, () => {
					Common.setVisible(layer.find(".title-chapter > badge"), true);

					setTimeout(() => {
						mist_system.Dialog.createTextDialog(getCommonHelpDirect("release_extra_2"), undefined, true, () => {
							mist_system.is_play_release_bonus = true;
							Common.saveSystem();
							that.addEvent();
						});
					}, wait_time);
				});
			}, 1000);
		}
		else {
			this.addEvent();
		}


		stopGameProgress();
	}

	updateBadge() {
		if(!mist_system.chapters["extra"]){
			return ;
		}
		const layer = TYRANO.kag.layer.getFreeLayer();
		Common.setVisible(layer.find(".title-chapter > badge"), mist_system.chapters["extra"].is_release && mist_system.chapters["extra"].is_new);
		Common.setVisible(layer.find(".title-chapter > new"), !mist_system.open_chapter);
		Common.setVisible(layer.find(".title-collection > new"), !mist_system.open_collection);
	}

	addEvent() {
		mist_temp.disable_footer_action = true;
		let clickable_list = {
			"title-start": { type: "func", func: "checkInitialStart", args: [{ type: "jump", storage: "scenario_start.ks", exp: "TYRANO.kag.variable.tf.jump_story_file='LB_scene1_1.ks'; TYRANO.kag.variable.tf.jump_label='';" }] },
			"title-load": { type: "role", func: "displayLoad" },
			"title-chapter": { type: "role", func: "displayChapter" },
			"title-collection": { type: "role", func: "displayGallery" },
			"title-option": { type: "role", func: "displayOption" },
			"title-end": { type: "dialog", func: "createYesNoDialogID", args: ["TITLE_ENDGAME", "*title_exit", "*title_cancel", "false", "true"] },
		};

		
		if (mist_save.trial_version) {
			clickable_list = {
				"title-start": {type: "jump", storage: "scenario_start.ks", exp:"TYRANO.kag.variable.tf.jump_story_file='LB_scene1_1.ks'"},
				"title-load": { type: "role", func: "displayLoad" },
				"title-option": { type: "role", func: "displayOption" },
				"title-open-steam": {type: "dialog", func: "createYesNoDialogID", args:["TITLE_OPENSTEAM", "*title_open_steam", "*title_cancel", "true", "true"]},
				"title-end": { type: "dialog", func: "createYesNoDialogID", args: ["TITLE_ENDGAME", "*title_exit", "*title_cancel", "false", "true"] },
			};
		}

		let elem = $('.title-container');

		var that = this;
		let count = 0;
		const exist_save = TYRANO.kag.menu.existSaveData();
		Object.keys(clickable_list).forEach(function (key) {
			if (!exist_save && !mist_save.trial_version && key == "title-load") {
				++count;
				return;
			}
			let el = elem.find(`.${key}`);
			const el_text = el.find("p");
			el_text.off();
			el_text.click((e) => {
				if (mist_temp.is_tutorial) return;

				e.stopPropagation();
				Common.setBlock(true);
				Common.setVisible(el.find("cursor"), true);
				Common.setVisible(el.find("line"), true);
				if(key == "title-start") {
					TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys03.mp3", stop: true });
				}
				else {
					TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
				}
				setTimeout(() => {
					Common.setBlock(false);
					Common.setVisible(el.find("cursor"), false);
					Common.setVisible(el.find("line"), false);
					const def = clickable_list[key];
					delete mist_temp.disable_footer_action;
					if (def['type'] == "jump") {
						that.fadeOut(() => {
							restartGameProgress();
							TYRANO.kag.layer.getMenuLayer().hide();
							eval(def['exp']);
							TYRANO.kag.ftag.startTag("jump", def);
							that.focusManager.unregisterFocus();
						}, 500);
					} else if (def['type'] == "role") {
						that.focusManager.unregisterFocus();
						TYRANO.kag.layer.getMenuLayer().hide();
						TYRANO.kag.menu[def['func']](() => {
							that.focusManager.registerFocus();
							that.focusManager.setLastFocus();
							mist_temp.disable_footer_action = true;
							that.updateBadge();
						}, false);
					} else if (def['type'] == "dialog") {
						that.focusManager.unregisterFocus();
						mist_system.Dialog[def['func']](...def['args']);
					} else if (def['type'] == "func") {
						that[def['func']](...def['args']);
					}
				}, Common.durationSelected());
			});
			const index = count;
			el_text.hover(() => {
				
				var is_cursor_displayed = el.find("cursor").css("visibility") !== "hidden";
				if (is_cursor_displayed) return;
				el_text.addClass("selected");
				Common.setVisible(el.find("line"), true);
				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
				that.focusManager.setLastIndex(index);
			}, () => {
				var is_cursor_displayed = el.find("cursor").css("visibility") !== "hidden";
				if (is_cursor_displayed) return;
				el_text.removeClass("selected");
				Common.setVisible(el.find("line"), false);
			});
			++count;
		});

		let index_list = [
			[5, 1],		
			[0, 4],		
			[0, 0],		
			[0, 0],		
			[1, 5],		
			[4, 0],		
		];
		if (mist_save.trial_version) {
			
			index_list = [
				[4, 1],		
				[0, 2],		
				[1, 3],		
				[2, 4],		
				[3, 0],		
			];
		} else if (!exist_save) {
			
			index_list = [
				[5, 4],		
				[0, 0],		
				[0, 0],		
				[0, 0],		
				[0, 5],		
				[4, 0],		
			]
		}
		else if (mist_system.is_clear_scenario) {
			
			index_list = [
				[5, 1],		
				[0, 2],		
				[1, 3],		
				[2, 4],		
				[3, 5],		
				[4, 0],		
			];
		}
		let focus_list = [
			elem.find(".title-start").find("p"),		
			elem.find(".title-load").find("p"),			
			elem.find(".title-chapter").find("p"),		
			elem.find(".title-collection").find("p"),	
			elem.find(".title-option").find("p"),		
			elem.find(".title-end").find("p"),			
		];
		if (mist_save.trial_version) {
			focus_list = [
				elem.find(".title-start").find("p"),		
				elem.find(".title-load").find("p"),			
				elem.find(".title-option").find("p"),		
				elem.find(".title-open-steam").find("p"),	
				elem.find(".title-end").find("p"),			
			];
		}

		
		this.focusManager = new FocusManager("title",
			focus_list,
			index_list,
			mist_temp.title_last_focus_index,
			(index) => mist_temp.title_last_focus_index = index);
	}
	appendFadeContainer() {
		const layer = $(".title-container");
		const exist_container = layer.find("title-fade-container").length > 0;
		if (!exist_container) {
			layer.append(`<title-fade-container></title-fade-container>`);
		}
		layer.show();
		this.being_fadeout = true; 
		return layer.find("title-fade-container").eq(0);
	}
	fadeIn(callback, time) {
		const that = this;
		const fade_time = time ? time : parseInt(Common.getDefineLabel("@program_fade_time"));
		const fade = this.appendFadeContainer();
		fade.show().fadeOut(fade_time, "linear", function () {
			if (callback) {
				callback();
			}
			if (!that.being_fadeout) {
				
				fade.remove();
			}
		});
	}
	fadeOut(callback, time) {
		const fade = this.appendFadeContainer();
		const fade_time = time ? time : parseInt(Common.getDefineLabel("@program_fade_time"));
		fade.hide().fadeIn(fade_time, "linear", function () {
			this.being_fadeout = false;
			if (callback) {
				callback();
			}
		});
	}

	
	checkInitialStart(args) {
		mist_temp.disable_footer_action = true;
		const def = args;
		const that = this;
		that.focusManager.unregisterFocus();
		const jumpScenarioFunc = () => {
			delete mist_temp.disable_footer_action;
			restartGameProgress();
			TYRANO.kag.layer.getMenuLayer().hide();
			eval(def['exp']);
			TYRANO.kag.ftag.startTag("jump", def);
			that.focusManager.unregisterFocus();
		};
		
		if (mist_system.cleard_trial !== void 0 || mist_system.readed_decide_clear_trial) {
			
			mist_system.cleard_trial = false;
			that.fadeOut(() => {
				jumpScenarioFunc();
			}, 500);
			return;
		}
		mist_system.Dialog.createYesNoCancelDialogID("DECIDE_CLEARD_TRIAL",
			() => {
				that.fadeOut(() => {
					
					mist_system.readed_decide_clear_trial = true;
					mist_system.cleard_trial = true;
					jumpScenarioFunc();
				}, 500);
			},
			() => {
				that.fadeOut(() => {
					
					mist_system.readed_decide_clear_trial = true;
					mist_system.cleard_trial = false;
					jumpScenarioFunc();
				}, 500);
			},
			() => {
				
			},
			"system/se_sys03.mp3", "system/se_sys03.mp3", "system/se_sys01.mp3", false
		);
	}

}
