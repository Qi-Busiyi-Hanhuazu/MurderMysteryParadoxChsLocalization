
class DetectiveManager
{
    constructor()
    {
        this.characters = [];
        
        mist_save.talk_characters = ["", ""];
    }

    
    load()
    {
        if (masterdata.characters) {
            this.initailizeCharacters();
        }

        let container = $('detective-new-container');
        if (container.length == 0) return;
        mist_system.DetectiveContainer.load();
    }

    create()
    {
        
        mist_save.talk_characters = ["", ""];
        this.initailizeCharacters();
        this.createCharacters();
        mist_system.SecretTalkContainer.createContainer();
        mist_system.DetectiveContainer.create("message11");
        this.clearTalkCharacters();
		mist_system.DetectiveContainer.setVisibleTime(false);
    }

    clearTalkCharacters()
    {
        mist_save.talk_characters = ["", ""];
        mist_system.DetectiveContainer.updateCharacterCount([]);
    }

    
    clearTalkCharacter(position)
    {
        const index = position == "right" ? 1 : 0;
        const chara_id = mist_save.talk_characters[index];
        
        if (chara_id == "") return "";

        mist_save.talk_characters[index] = "";
        mist_system.DetectiveContainer.updateCharacterCount(mist_save.talk_characters);

        const chara = getCharacter(chara_id);
        const name = chara.id == "itsuki" ? "主人公" : chara.name;
        return name;
    }

    isEmptyTalkCharacters()
    {
        return mist_save.talk_characters.every(x => x == "");
    }

    getCharacters()
    {
        if(Object.keys(masterdata.characters_temp).length !== 0){
            return this.characters.concat(Object.values(masterdata.characters_temp));
        }
        return this.characters;
    }

    getCharacterByName(name)
    {
        switch (name) {
            case "主人公": name = "樹";
                break;
            case "NPC":  name = mist_save.npc_sysname;
                break;
        }

        return this.getCharacters().find(x => {
            if (x.j_name) return x.j_name == name;
            return x.name == name;
        });
    }

    getCharacterById(id)
    {
        return this.getCharacters().find(x => x.id == id);
    }

    
    initailizeCharacters() {
        let charas = getNpcListOrderedDisp();
        
        charas.unshift(mist_save.player);
        this.characters = charas;
    }

    
    createCharacters() {
        
        const player = getPlayer();
        this.newCharacter(player.id);

        
        const character_ids = getNpcListOrderedDisp().map(npc => npc.id);
        character_ids.forEach((id => {
            const npc = getCharacter(id);
            let npc_key = npc.id;
            let chara = getCharacter(npc_key);
            this.newCharacter(chara.id);
        }));
    }

    
    newCharacter(chara_id, is_npc = false) {
        const chara = getCharacter(chara_id);
        const name = chara_id == "itsuki" ? "主人公" : chara.name;

        
        TYRANO.kag.ftag.startTag("chara_new", {
            name: is_npc ? "NPC" : name,
            storage: `chara/${chara.resource}/${chara.defaultFace()}.png`,
            jname: name,
            width: 1920,
            height: 1180
        });
        
        
        
        if(is_npc){
            
            const prev_name = TYRANO.kag.stat.jcharas["NPC"];
            if(prev_name){
                TYRANO.kag.stat.jcharas[prev_name] = prev_name;
            }
            TYRANO.kag.stat.jcharas["NPC"] = name;
        }





[
"normal","close","sincere","earnest","earnestclose","determined","nervous","surprise","laugh","smile","what","boast","shy","happy","trance","badsurprise","doubt","panic","confused","stunned","trouble","sad","serious","frantic","scream","dark","anger","despair","cry","worry","void","starved","think","ruthless","mysterious","sadclose","frightened","faint","groan","mad","excited","crazy","grin","blood"
].forEach((face) => {
            
            TYRANO.kag.ftag.startTag("chara_face", {
                name: is_npc ? "NPC" : name,
                face: face,
                storage: `chara/${chara.resource}/${face}.png`
            });
            
            TYRANO.kag.ftag.startTag("chara_layer", {
                name: is_npc ? "NPC" : name,
                left: 0,
                top: 0,
                width: 1920,
                height: 1180,
                id: face,
                part: "eye",
                storage: `chara/${chara.resource}/${face}_eyes.png`
            });
        });
    }

    getTalkCharacterPositions()
    {
        return [
            mist_save.left_position,
            mist_save.right_position,
        ];
    }


    
    getCharacterName(chara_id) {
        const chara = getCharacter(chara_id);
        
        if (chara.j_name) return chara.id;
        
        if (chara_id == "itsuki") return "主人公";
        return chara.name;
    }

    
    showCharacterParams(chara_id, position)
    {
        const name = this.getCharacterName(chara_id);
        const pos = this.getTalkCharacterPositions();
        let tmp_pos = position;
        if(((position == void 0) || position == "") && isModeInvestigation()){ 
            tmp_pos = chara_id == "itsuki" ? "left" : "right";
        }

        const index = (function(position) {
            switch (position) {
                case "left": return 0;
                case "right": return 1;
            }
            
            const find_index = mist_save.talk_characters.findIndex(x => x == chara_id);
            return find_index == -1 ? 0 : find_index;
        })(tmp_pos);

        mist_system.last_talk = {pos_index: index, chara_id:chara_id}

        const prev_chara_id = mist_save.talk_characters[index];
        const is_change = mist_save.talk_characters[index] != chara_id;
        mist_save.talk_characters[index] = chara_id;
        
        const anthoer_index = index == 0 ? 1 : 0;
        const add_hide = mist_save.talk_characters[anthoer_index] == chara_id;
        if(add_hide){
            mist_save.talk_characters[anthoer_index]  = "";
        }
        mist_system.DetectiveContainer.updateCharacterCount(mist_save.talk_characters);

        let hide = [];
        let show = {};
        if (is_change) {
            if (prev_chara_id != "") {
                const prev_chara = getCharacter(prev_chara_id);
                const name = this.getCharacterName(prev_chara.id);
                hide.push({
                    name: name,
                    time: 100,
                    zindex: 0
                });
            }

            show = {
                name: name,
                left: pos[index].x,
                top: pos[index].y,
                time: 100,
                zindex: 0
            };
        }

        if(add_hide){
            hide.push({
                name: name,
                time: 0,
                zindex: 0
            });
        }

        return {
            show: show,
            hide: hide
        };
    }

    
    getDoubts(chara_id) {
        return getDoubtIds()
            .map(id => getDoubt(id))
            .filter(doubt => doubt.chara_id == chara_id);
    }

    
    getInferenceCount(chara_id) {
        return this.getDoubts(chara_id)
            .filter(doubt => !doubt.isAnswerFull() || (doubt.solved && !doubt.result)).length;
    }

    
    getBuiltInferenceCount(chara_id) {
        return this.getDoubts(chara_id)
            .filter(doubt => doubt.isAnswerFull() && !doubt.solved).length;
    }

    
    
    
    
    
    

    
    getDoubtCount(chara_id) {
        const doubts = getOwnerDoubts(chara_id);
        const haveDoubts = getDoubtIds();
        return doubts
            .filter(doubt => !haveDoubts.includes(doubt.id) && checkDoubtCondtions(doubt.conditions))
            .length;
    }

    
     getQuestionCount(chara_id) {
        
        const pieces = Object.keys(mist_save.player_pieces)
            .map(piece_id => getPiece(piece_id))
            .filter(piece => piece.chara_id != chara_id);
        return pieces.filter(piece => !alreadyTalked(`${chara_id}_${piece.id}`)).length;
    }

    getLastTalkInfo(){
        return mist_system.last_talk;
    }
}
 
Common.sfAddClass(new DetectiveManager());
