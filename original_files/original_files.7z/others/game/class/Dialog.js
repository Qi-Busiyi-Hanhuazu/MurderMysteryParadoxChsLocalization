

class Dialog
{
    
    load()
    {
        if ($('.dialog').length == 0) return;

        if ($('yesno-window').length > 0)
        {
            const window = $('yesno-window');
            this.setButtonEvent(window.find("decide-button"), mist_save.decide_click_target, null, null, "system/se_sys02.mp3");
            this.setButtonEvent(window.find("cancel-button"), mist_save.cancel_click_target, null, null, "system/se_sys01.mp3");
        }
    }

    
    createTextDialogDisplayOnly(text, cb)
    {
        let dialog = Common.createDialogBase(false);
        text = text ? text : "";

        const html = `
            <text-window class="dialog-close-button">
                <content>
                    <text>${text}<icon></icon></text>
                </content>
            </text-window>`;
        dialog.html(html);

        const is_show_footer = mist_system.FooterContainer.isVisible();
        if(is_show_footer) {
            mist_system.FooterContainer.hide(false);
        }
        

        const button_elem = $(".dialog");
        setEventUpdateDialogCloseBtn(button_elem, ()=>{
            if(is_show_footer) {
                mist_system.FooterContainer.show(false);
            }
            if (typeof cb == "function") {
                cb();
            }
        });

        Common.fadeInAnimation(dialog);
    }


    
    createTextDialog(text, close_target, enable_skip = false, callback = undefined, do_append = false)
    {
        let dialog = Common.createDialogBase(false);
        text = text ? text : "";
        mist_save.close_click_target = close_target;

        const html = `
            <text-window>
                <content>
                    <text>${text}<icon></icon></text>
                </content>
            </text-window>`;
        if(do_append) {
            dialog.append(html);
        }
        else {
            dialog.html(html);
        }

        const button_elem = $(".dialog");
        setEventUpdateDialogCloseBtn(button_elem, callback);

        Common.fadeInAnimation(dialog, () => {
            
            if(enable_skip && Common.isSkipAwaitInput()) {
                button_elem.click();
            }
        });

        
    }
    
    createYesNoDialog(text, decide_target, cancel_target, decide_btn_name, cancel_btn_name, focus_yes = true)
    {
        text = Common.replaceDefineLabelStringAll(text);
        let dialog = Common.createDialogBase(false);
        const html = `
            <yesno-window>
                <content-grid>
                    <text>${text}</text>
                </content-grid>
                ${this._yesNoButtonHtml(decide_btn_name, cancel_btn_name)}
            </yesno-window>`;

        const is_show_footer = mist_system.FooterContainer.isVisible();
        dialog.html(html);
        mist_save.decide_click_target = decide_target;
        mist_save.cancel_click_target = cancel_target;
        this._yesNoButtonSetting(dialog, decide_target, cancel_target, focus_yes,
            () => {
                if (mist_system.FooterContainer != null && is_show_footer) {
                    mist_system.FooterContainer.show(false);
                }
            });
        Common.fadeInAnimation(dialog);
        if (mist_system.FooterContainer != null && is_show_footer) {
            mist_system.FooterContainer.hide(false);
        }
    }

    
    createYesNoDialogID(dialog_id, decide_target, cancel_target, focus_yes = true, decide_se_decision = false)
    {
        console.log(`focus_yes:${focus_yes}`);
        const data = masterdata.define_dialog[dialog_id];
        let text = Common.replaceDefineLabelStringAll(data.text);

        
        if(dialog_id == "DETECTIVE_ENDPHASE"){
            text = text.format(getCost(), getInitCost());
        }else if(dialog_id == "VOTE_VOTE"){
            text = text.format(mist_system.DetectiveContainer.getSelectCharacter().sysname);
        }
        const decide_btn_name = Common.replaceDefineLabelStringAll(data.yes);
        const cancel_btn_name = Common.replaceDefineLabelStringAll(data.no);
        let dialog = Common.createDialogBase(false);
        let yesNoHtmlFunc = this._yesNoButtonHtml;
        
        if(data.yes_line == "1"){
            yesNoHtmlFunc = this._yesNoButtonHtmlLine;
        }
        const html = `
            <yesno-window>
                <content-grid>
                    <text>${text}</text>
                </content-grid>
                ${yesNoHtmlFunc(decide_btn_name, cancel_btn_name)}
            </yesno-window>`;

        dialog.html(html);
        const is_show_footer = mist_system.FooterContainer.isVisible();
        mist_save.decide_click_target = decide_target;
        mist_save.cancel_click_target = cancel_target;
        this._yesNoButtonSetting(dialog, decide_target, cancel_target, focus_yes,
            () => {
                if (mist_system.FooterContainer != null && is_show_footer) {
                    mist_system.FooterContainer.show(false);
                }
            }, decide_se_decision);

        let desice_width = data.yes_width ? data.yes_width : '650px';
        let cancel_width = data.no_width ? data.no_width : '650px';

        $('.dialog-decide-button').css('grid-template-columns', `1fr ${desice_width} 1fr`);
        $('.dialog-cancel-button').css('grid-template-columns', `1fr ${cancel_width} 1fr`);
        if(data.yes_line){
            $('.dialog-decide-button').siblings("line").css('background-image', `url(data/image/common/dialog/${data.yes_line})`);
            $('.dialog-decide-button').siblings("line").css('width', `${desice_width}`);
        }else{
            $('.dialog-decide-button').siblings("line").css('width', `100%`);
        }
        if(data.no_line){
            $('.dialog-cancel-button').siblings("line").css('background-image', `url(data/image/common/dialog/${data.no_line})`);
            $('.dialog-cancel-button').siblings("line").css('width', `${cancel_width}`);
        }else{
            $('.dialog-cancel-button').siblings("line").css('width', `100%`);
        }

        Common.fadeInAnimation(dialog);
        if (mist_system.FooterContainer != null && is_show_footer) {
            mist_system.FooterContainer.hide(false);
        }
    }

    
    createYesNoCancelDialogID(dialog_id, yes_target, no_target, cancel_target, yes_click_se="system/se_sys02.mp3", no_click_se="system/se_sys02.mp3", cancel_click_se="system/se_sys01.mp3", focus_yes = true)
    {
        const data = masterdata.define_dialog[dialog_id];
        let text = Common.replaceDefineLabelStringAll(data.text);
        const yes_btn_name = Common.replaceDefineLabelStringAll(data.yes);
        const no_btn_name = Common.replaceDefineLabelStringAll(data.no);
        const cancel_btn_name = Common.replaceDefineLabelStringAll(data.cancel);
        let dialog = Common.createDialogBase(false);
        let yesNoCancelButtonHtml = this._yesNoCancelButtonHtml;

        const html = `
            <yesnocancel-window>
                <content-grid>
                    <text>${text}</text>
                </content-grid>
                ${yesNoCancelButtonHtml(yes_btn_name, no_btn_name, cancel_btn_name)}
            </yesno-window>`;

        const is_show_footer = mist_system.FooterContainer.isVisible();
        dialog.html(html);
        this._yesNoCancelButtonSetting(dialog, yes_target, no_target, cancel_target, yes_click_se, no_click_se, cancel_click_se, focus_yes,
            () => {
                if (mist_system.FooterContainer != null && is_show_footer) {
                    mist_system.FooterContainer.show(false);
                }
            });

        let yes_width = data.yes_width ? data.yes_width : '650px';
        let no_width = data.no_width ? data.no_width : '650px';
        let cancel_width = data.cancel_width ? data.cancel_width : '650px';

        $('.dialog-yes-button').css('grid-template-columns', `1fr ${yes_width} 1fr`);
        $('.dialog-no-button').css('grid-template-columns', `1fr ${no_width} 1fr`);
        $('.dialog-cancel-button').css('grid-template-columns', `1fr ${cancel_width} 1fr`);

        if(data.yes_line){
            $('.dialog-yes-button').siblings("line").css('background-image', `url(data/image/common/dialog/${data.yes_line})`);
            $('.dialog-yes-button').siblings("line").css('width', `${yes_width}`);
        }else{
            $('.dialog-yes-button').siblings("line").css('width', `100%`);
        }
        if(data.no_line){
            $('.dialog-no-button').siblings("line").css('background-image', `url(data/image/common/dialog/${data.no_line})`);
            $('.dialog-no-button').siblings("line").css('width', `${no_width}`);
        }else{
            $('.dialog-no-button').siblings("line").css('width', `100%`);
        }
        if(data.cancel_line){
            $('.dialog-cancel-button').siblings("line").css('background-image', `url(data/image/common/dialog/${data.cancel_line})`);
            $('.dialog-cancel-button').siblings("line").css('width', `${cancel_width}`);
        }else{
            $('.dialog-cancel-button').siblings("line").css('width', `100%`);
        }

        Common.fadeInAnimation(dialog);
        if (mist_system.FooterContainer != null && is_show_footer) {
            mist_system.FooterContainer.hide(false);
        }
    }


    
    createPieceDetailDialog(piece_id, close_target, click_next=false, click_event=null)
    {
        const close_func = function(){
            if(Boolean(TYRANO.kag.stat.f.close_click_target)){
                TYRANO.kag.ftag.startTag("jump",{target: TYRANO.kag.stat.f.close_click_target });
            }
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
            Common.clearDialogLayer();
            mist_system.FooterContainer.back();
            if (click_event != null) {
                click_event();
            }
        };
        const display_param = {
            close_event_q_key: function(e){
                    e.stopPropagation();
                    close_func();
            },
            is_visible_footer_base: true
        }
        mist_system.FooterContainer.showDialogFooter(display_param);
        let piece = getPiece(piece_id);
        let dialog = Common.createDialogBase(false);
        mist_save.close_click_target = close_target;

        const html = `
            <piece-detail-window>
                <img src="./data/image/${piece.detail}">
            </piece-detail-window>`;
        dialog.html(html);

        const button_elem = $(".dialog");
        
        button_elem.addClass("dialog-piece-detail-close-button");
        setEventUpdateDialogCloseBtn(button_elem, function(){
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
            mist_system.FooterContainer.back();
            if (click_event != null) {
                click_event();
            }
        }, undefined);
        if(click_next) {
            button_elem.attr("click_next", true);
        }

        
        TYRANO.kag.key_mouse.vmouse.hide();

        Common.fadeInAnimation(dialog, () => {
            
            if(click_next && Common.isSkipAwaitInput()) {
                button_elem.click();
            }
        });
    }

    
    createPieceQuestionInference(decide_target, cancel_target)
    {
        let dialog = Common.createDialogBase(false);
        mist_save.decide_click_target = decide_target;
        mist_save.cancel_click_target = cancel_target;
        let piece = getPiece(mist_save.select_piece_id);
        let character = getCharacter(mist_save.npc_key);
        let owner = getCharacter(piece.chara_id);
        if(!owner && piece.chara_id == "itsuki")
        {
            owner = getPlayer();
        }

        let tag_html = "";
        let tagList = piece.getTagList();
        tagList.forEach((tag) => tag_html += `<tag>${tag}</tag>`);
        let cost = getAskCost(character.credit_level);

        const html = `
            <piece-window>
                <grid>
                    <title>${character.name}に質問する手がかりは……</title>
                    <content type="question">
                        <content-flex>
                            <icon-frame>
                                <icon style='background-image: url(./data/image/${piece.resource});'></icon>
                            </icon-frame>
                            <tags>
                                ${tag_html}
                            </tags>
                        </content-flex>
                        <name>${piece.title}</name>
                        <text>${piece.desc}</text>
                    </content>


                    <buttons-grid>
                        <cost-label>残り ${getCost()}分 → <font color='#5d9eff'>${getCost() - cost}分</font ></cost-label>
                        <decide-button class="dialog-decide-button"></decide-button>
                        <cancel-button class="dialog-cancel-button"></cancel-button>
                    </buttons-grid>
                </grid>
            </piece-window>`;

        dialog.html(html);

        const decide_button = dialog.find("decide-button");
        this.setButtonEvent(decide_button, decide_target, null, null, "system/se_sys02.mp3");
        const cancel_button = dialog.find("cancel-button");
        this.setButtonEvent(cancel_button, cancel_target, null, null, "system/se_sys01.mp3");

        Common.fadeInAnimation(dialog);
    }

    
    setButtonEvent(elem, target = "", storage = "", hover_on_callback = null, hover_off_callback = null, click_se = null, click_event = null)
    {
        this.setButtonEventCallback(elem,
            () => {
                if(!this.nowStopping) {
                    restartGameProgress(this.callNextOrder);
                    this.callNextOrder = false;
                }
                this.nowStopping = false;


                if(!$.isFunction(target)){
                    const jump_pm = { target: target, storage: storage };
                    if (jump_pm.target != "" || jump_pm.storage != "") {
                        TYRANO.kag.ftag.startTag("jump", jump_pm);
                    }
                }else{
                    
                    target();
                }
            },
            hover_on_callback,
            hover_off_callback,
            click_se,
            false,
            click_event
        );
    }
    setButtonEventCallback(elem, target, hover_on_callback = null, hover_off_callback = null, click_se = null, disable_call_clear=false, click_event = null)
    {
        if (elem.length == 0) return;

        

        
        elem.click((e) => {
            if (mist_temp.is_tutorial) return;
            
            e.stopPropagation();
            Common.setVisible(elem.find("cursor"), true);
            if (click_se != null) {
                TYRANO.kag.ftag.startTag("PLAY_SE", {storage: click_se, stop: true });
            }
            elem.off();
            elem.siblings().off();
            setTimeout(function(){
                if (target != null) {
                    target();
                }
                if(!disable_call_clear) {
                    Common.clearDialogLayer();
                }

                if (click_event != null) {
                    click_event();
                }
                
                Common.setBlock(true, "dialog", 100);
            }, Common.durationSelected());
        });
        
        elem.hover(() => {
            if (hover_on_callback != null) {
                hover_on_callback();
            }
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, () => {
            if (hover_off_callback != null) {
                hover_off_callback();
            }
        });

        
        Common.makeFocusable(elem);
    }

    
    createConfirmInference(decide_target, cancel_target)
    {
        let dialog = Common.createDialogBase(false);
        mist_save.decide_click_target = decide_target;
        mist_save.cancel_click_target = cancel_target;
        let doubt = mist_save.doubt;
        let charactor = getCharacter(doubt.chara_id);
        if(charactor == null)
        {
            let player = getPlayer();
            if(player.id == doubt.chara_id)
            {
                charactor = player;
            }
        }
        
        const cost = getCost();
        const new_cost = cost - getInferenceCost(charactor.credit_level);
        const html = `
            <inference-window>
                <title>${charactor.sysname}の疑問に対する、僕の答えは……</title>

                <doubt-title>${charactor.name}の疑問</doubt-title>
                ${doubt.getDoubtTableHtml()}

                <inference-title>樹の推理</inference-title>
                ${this.getInferenceHtml("select", doubt, true)}

                <cost-label>残り ${cost}分 → <font color='#5d9eff'>${new_cost}分</font></cost-label>
                <buttons-grid>
                    <decide-button class="dialog-decide-button"></decide-button>
                    <cancel-button class="dialog-cancel-button"></cancel-button>
                </buttons-grid>
            </inference-window>`;
        dialog.html(html);
        updateAnswerSlotsHtml(doubt);

        const decide_button = dialog.find("decide-button");
        this.setButtonEvent(decide_button, decide_target, null, null, "system/se_sys02.mp3");
        const cancel_button  = dialog.find("cancel-button");
        this.setButtonEvent(cancel_button, cancel_target, null, null, "system/se_sys01.mp3");
        Common.setFocus(decide_button);
        Common.fadeInAnimation(dialog);
    }

    
    createCheckShowInference(decide_target, cancel_target)
    {
        const doubt = mist_save.doubt;
        const character = getCharacter(doubt.chara_id);
        const consume_cost = getShowInferenceCost(character.credit_level);

        if (getCost() - consume_cost <= 0) {
            
            TYRANO.kag.variable.sf.Dialog.createTextDialog(helpMessage("warn_last_action_inference").text, undefined, false, () => {
                TYRANO.kag.variable.sf.Dialog.createShowInference(decide_target, cancel_target);
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            });
        }
        else {
            TYRANO.kag.variable.sf.Dialog.createShowInference(decide_target, cancel_target);
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
        }
    }
    createShowInference(decide_target, cancel_target)
    {
        const doubt = mist_save.doubt;
        const character = getCharacter(doubt.chara_id);
        const consume_cost = getShowInferenceCost(character.credit_level);
        const after_cost = Math.max(getCost() - consume_cost, 0);
 
        const doubt_html = TYRANO.kag.variable.sf.NoteContainer2.getDoubtHtml(doubt, false, false);
        const timeHtml = `<text>残り<span style="font-size: 48px">${getCost()}</span>分<arrow></arrow><span style="font-size: 48px; color: red;">${after_cost}</span><span style="color: red;">分</span></text>`

        const data = masterdata.define_dialog["DETECTIVE_SHOW_INFERENCE"];
        const html = `
            <inference-window2>
                <top></top>
                ${doubt_html}
                <bottom>
                    <title>${mist_save.npc}に推理を伝えますか？</title>
                    ${timeHtml}
                    <item>
                        <mist-button class="dialog-decide-button">${data.yes}</mist-button>
                        <line id="decide"></line>
                        <cursor id="decide"></cursor>
                    </item>
                    <item>
                        <mist-button class="dialog-cancel-button">${data.no}</mist-button>
                        <line id="cancel"></line>
                        <cursor id="cancel"></cursor>
                    </item>
                </bottom>
            </inference-window2>`;
        const dialog = Common.createDialogBase(false);
        dialog.html(html);


        dialog.find("inference-window2 > item").css("position", "relative");
        dialog.find("inference-window2 > item").removeClass("doubt-inference");
        dialog.find("inference-window2 > item").addClass("doubt-inference frame-white");

        const decide_button = dialog.find("bottom > item").eq(0);
        const yes_cursor = decide_button.find("cursor");
        const yes_line = decide_button.find("line");
        const yes_text = decide_button.find("mist-button");
        Common.setVisible(yes_cursor, false);
        Common.setVisible(yes_line, false);
        this.setButtonEvent(decide_button, decide_target, "",
            () => {
                Common.setVisible(yes_line, true);
                decide_button.addClass("selected");
                yes_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(yes_line, false);
                decide_button.removeClass("selected");
                yes_text.removeClass("selected-white-back");
            },
            "system/se_sys02.mp3"
        );

        const cancel_button = dialog.find("bottom > item").eq(1);
        const no_cursor = cancel_button.find("cursor");
        const no_line = cancel_button.find("line");
        const no_text = cancel_button.find("mist-button");
        Common.setVisible(no_cursor, false);
        Common.setVisible(no_line, false);
        this.setButtonEvent(cancel_button, cancel_target, "",
            () => {
                Common.setVisible(no_line, true);
                cancel_button.addClass("selected");
                no_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(no_line, false);
                cancel_button.removeClass("selected");
                no_text.removeClass("selected-white-back");
            },
            "system/se_sys01.mp3"
        );

        Common.setFocus(decide_button);
        Common.fadeInAnimation(dialog);
    }


    
    createMoveSecretForInference(decide_target, cancel_target)
    {
        const doubt = mist_save.doubt;
        const doubt_html = TYRANO.kag.variable.sf.NoteContainer2.getDoubtHtml(doubt);
        const character = getCharacter(doubt.chara_id);

        const data = masterdata.define_dialog["DETECTIVE_GO_SECRET"];
        const html = `
            <inference-window2>
                <top>
                </top>
                ${doubt_html}
                <button-grid>
                    <title>${character.name}に今すぐこの推理を伝えに行きますか？</title>
                    <warning>※${character.name}との密談へ移行します。</warning>
                    <item>
                        <mist-button class="dialog-decide-button">${data.yes}</mist-button>
                        <line id="decide"></line>
                        <cursor id="decide"></cursor>
                    </item>
                    <item>
                        <mist-button class="dialog-cancel-button">${data.no}</mist-button>
                        <line id="cancel"></line>
                        <cursor id="cancel"></cursor>
                    </item>
                </button-grid>
            </inference-window2>`;

        const dialog = Common.createDialogBase(false);
        dialog.html(html);


        dialog.find("inference-window2 > item").css("position", "relative");
        dialog.find("inference-window2 > item").removeClass("doubt-inference");
        dialog.find("inference-window2 > item").addClass("doubt-inference frame-white");

        const decide_button = dialog.find("button-grid > item").eq(0);
        const yes_cursor = decide_button.find("cursor");
        const yes_line = decide_button.find("line");
        const yes_text = decide_button.find("mist-button");
        Common.setVisible(yes_cursor, false);
        Common.setVisible(yes_line, false);
        this.setButtonEvent(decide_button, decide_target, "",
            () => {
                Common.setVisible(yes_line, true);
                yes_cursor.addClass("selected");
                yes_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(yes_line, false);
                yes_cursor.removeClass("selected");
                yes_text.removeClass("selected-white-back");
            },
            "system/se_sys02.mp3"
        );

        const cancel_button = dialog.find("button-grid > item").eq(1);
        const no_cursor = cancel_button.find("cursor");
        const no_line = cancel_button.find("line");
        const no_text = cancel_button.find("mist-button");
        Common.setVisible(no_cursor, false);
        Common.setVisible(no_line, false);
        this.setButtonEvent(cancel_button, cancel_target, "",
            () => {
                Common.setVisible(no_line, true);
                no_cursor.addClass("selected");
                no_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(no_line, false);
                no_cursor.removeClass("selected");
                no_text.removeClass("selected-white-back");
            },
            "system/se_sys01.mp3"
        );

        Common.setFocus(decide_button);
        Common.fadeInAnimation(dialog);
    }

    
    createConfirmInference2(decide_target, cancel_target)
    {
        this.createConfirmInference2Event(
            () => {
                const jump_pm = { target: decide_target, storage: "" };
                if (jump_pm.target != "" || jump_pm.storage != "") {
                    TYRANO.kag.ftag.startTag("jump", jump_pm);
                }
            },
            () => {
                const jump_pm = { target: cancel_target, storage: "" };
                if (jump_pm.target != "" || jump_pm.storage != "") {
                    TYRANO.kag.ftag.startTag("jump", jump_pm);
                }
            }
        )
    }
    
    createConfirmInference2Event(decide_event, cancel_event)
    {
        const data = masterdata.define_dialog["DETECTIVE_CREATE_INFERENCE"];
        const player = getPlayer();
        const doubt = getDoubt(mist_save.doubt_id);
        const character = getCharacter(doubt.chara_id);
        const consume_cost = getInferenceCost(character.credit_level);
        const after_cost = Math.max(getCost() - consume_cost, 0);
        const inference = getInferenceFromDoubt(doubt, true, true);
        const inference2 = getInferenceFromDoubt(doubt, false, true);
        console.log(inference2.convince_level_index);
        const convince_image = ["image0", "image1", "image2"][inference2.convince_level_index];
        let report_image = `image1`; 

        let doubt_html = TYRANO.kag.variable.sf.NoteContainer2.getDoubtMiniHtml(doubt, true, false);
        const player_icon_path = `data/image/${getPlayerInferenceIcon()}`;

        
        const timeHtml = isModeInvestigation() ? `<text>残り<span style="font-size: 48px">${getCost()}</span>分<arrow></arrow><span style="font-size: 48px; color: red;">${after_cost}</span><span style="color: red;">分</span></text>`
                                                : "";
        const html = `
            <inference-window3>
                <div></div>
                <item class="doubt-inference frame-white" style="left: -35px; top: 8px">
                    <container>
                        <content class="doubt">
                            <result id="after4" class="${report_image}" style="display:none"></result>
                            ${doubt_html}
                        </content>

                        <arrow-center></arrow-center>

                        <content class="doubt">
                            <row1>
                                <circle>
                                    <title>樹の推理</title>
                                </circle>
                                <chara-image style="background-image: url(${player_icon_path});"></chara-image>
                            </row1>
                            <row2>
                                <blank id="before1"></blank>
                                <titlearea>
                                    <title id="after1" class="shadow-bold" style="display:none">${inference2.name}</title>
                                </titlearea>
                                <line></line>
                                <text id="after2" style="display:none">${inference2.desc}</text>
                            </row2>
                            <row3>
                                <inference-line></inference-line>
                                <inference-title>推理の説得力</inference-title>
                                <inference-status id="before3" class="blank"></inference-status>
                                <inference-status id="after3" class="${convince_image}" style="display:none"></inference-status>
                            </row3>

                            <result class=""></result>
                        </content>
                    </container>
                </item>

                <bottom>
                    <title>疑問に対する答えを推理しますか？</title>
                    ${timeHtml}
                    <item>
                        <mist-button class="dialog-decide-button">${data.yes}</mist-button>
                        <line id="decide"></line>
                        <cursor id="decide"></cursor>
                    </item>
                    <item>
                        <mist-button class="dialog-cancel-button">${data.no}</mist-button>
                        <line id="cancel"></line>
                        <cursor id="cancel"></cursor>
                    </item>
                </bottom>
            </inference-window3>`;

        const dialog = Common.createDialogBase(false);
        dialog.html(html);

        const decide_button = dialog.find("bottom > item").eq(0);
        const yes_cursor = decide_button.find("cursor");
        const yes_line = decide_button.find("line");
        const yes_text = decide_button.find("mist-button");
        
        Common.setVisible(yes_cursor, false);
        Common.setVisible(yes_line, false);

        
        const fade_time = parseInt(Common.getDefineLabel("@create_inference_effect_fade_time"));
        const that = this;
        const get_interfance_func = function() {
            Common.setVisible(yes_line, false);
            dialog.find("mist-button").css("cursor", "default");

            
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys19.mp3", stop: true });
            let fadeTotalTime = 0;
            dialog.find("#before1").fadeOut(fade_time);

            fadeTotalTime += fade_time + 10;
            setTimeout(() => {
                dialog.find("#after1").fadeIn(fade_time);
                dialog.find("#after2").fadeIn(fade_time);
            }, fadeTotalTime);

            fadeTotalTime += fade_time + 10;
            setTimeout(() => {
                dialog.find("#before3").fadeOut(fade_time);
            }, fadeTotalTime);

            fadeTotalTime += fade_time + 10;
            setTimeout(() => {
                dialog.find("#after3").fadeIn(fade_time);
                dialog.find("#after4").fadeIn(fade_time);
            }, fadeTotalTime);

            fadeTotalTime += fade_time + 10;
            setTimeout(() => {
                if(Common.isSkipAwaitInput()) {
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                    TYRANO.kag.pushBackLog("", getCommonHelpDirect("msg_create_inference"), "add", true);
                    decide_event();
                    return;
                }
                const dialog = $(".dialog");
                dialog.addClass("create_inference_window_click");
                dialog.click(() => {
                    dialog.off("click");
                    dialog.removeClass("create_inference_window_click");
                    mist_system.FooterContainer.back();
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                    TYRANO.kag.pushBackLog("", getCommonHelpDirect("msg_create_inference"), "add", true);
                    decide_event();
                });
                mist_system.FooterContainer.showDialogFooter({
                    close_event_q_key: () => {
                        dialog.click();
                    },
                    is_visible_footer_base: true
                });
            }, fadeTotalTime);
        };

        const cancel_button = dialog.find("bottom > item").eq(1);
        const no_cursor = cancel_button.find("cursor");
        const no_line = cancel_button.find("line");
        const no_text = cancel_button.find("mist-button");
        Common.setVisible(no_cursor, false);
        Common.setVisible(no_line, false);

        Common.fadeInAnimation(dialog, () => {
            this.setButtonEventCallback(decide_button, get_interfance_func,
                () => {
                    Common.setVisible(yes_line, true);
                    yes_cursor.addClass("selected");
                    yes_text.addClass("selected-white-back");
                },
                () => {
                    Common.setVisible(yes_line, false);
                    yes_cursor.removeClass("selected");
                    yes_text.removeClass("selected-white-back");
                },
                "system/se_sys02.mp3",
                true,
            );
    
            this.setButtonEventCallback(cancel_button, cancel_event,
                () => {
                    Common.setVisible(no_line, true);
                    no_cursor.addClass("selected");
                    no_text.addClass("selected-white-back");
                },
                () => {
                    Common.setVisible(no_line, false);
                    no_cursor.removeClass("selected");
                    no_text.removeClass("selected-white-back");
                },
                "system/se_sys01.mp3",
            );
            Common.setFocus(cancel_button);
        });
    }

    
    getInferenceHtml(type, doubt, is_dummy)
    {
        const sf = TYRANO.kag.variable.sf;
        const inference = getInferenceFromDoubt(doubt, is_dummy);
		const icon_path = `./data/image/${getInferenceCommonIconPath()}`;
        const dummy_path = `./data/image/detective/common/dummy.png`;
        const _convince_path = `./data/image/detective/doubt_list/inference_frame/${inference.convince_level}.png`;
        const _convince_label_path = "./data/image/detective/doubt_list/inference_frame/convince.png";
        const title = inference.name;
        const desc = inference.desc.replace(/\[r\]/g, "<br />");
        const convince_path = is_dummy ? dummy_path : _convince_path;
        const convince_label_path = is_dummy ? dummy_path : _convince_label_path;

        return `
            <content type="${type}">
                <inference-grid>
                    <cell-icon style="background-image: url(${icon_path});"></cell-icon>
                    <cell-title>${title}</cell-title>
                    <cell-convince>
                        <convince style="background-image: url(${convince_path});"></convince>
                        <convince-label style="background-image: url(${convince_label_path});"></convince-label>
                    </cell-convince>
                    <cell-desc>${desc}</cell-desc>
                </inference-grid>
            </content>`;
    }

    
    _createPieceHtml(npc_name, chapter_path, piece_id, initialize)
    {
        let piece = getPiece(piece_id);
        let owner = getCharacter(piece.chara_id);
        if(!owner && (piece.chara_id == "itsuki"))
        {
            owner = getPlayer();
        }

        let tag_html = "";
        let tagList = piece.getTagList();
        tagList.forEach((tag) => tag_html += `<tag>${tag}</tag>`);
        const title = (initialize || !npc_name) ? "新たな【手がかり】をノートに書き留めた。" : `${npc_name}の【手がかり】をノートに書き留めた。`;
        return `
            <piece-window>
                <grid>
                    <title>${title}</title>
                    <content>
                        <content-flex>
                            <icon-frame>
                                <icon style='background-image: url(./data/image/${piece.resource});'></icon>
                            </icon-frame>
                            <tags>
                                ${tag_html}
                            </tags>
                        </content-flex>
                        <name>${piece.title}</name>
                        <text>${piece.desc}</text>
                    </content>
                    ${this._closeButtonHtml()}
                </grid>
            </piece-window>`;
    }

    
    _createDoubtHtml(npc_name, doubt_id)
    {
        const doubt = getDoubt(doubt_id);
        const title = npc_name ? `${npc_name}の【疑問】をノートに書き留めた。` : "新たな【疑問】をノートに書き留めた。";
        return `
            <doubt-window>
                <title>${title}</title>
                ${doubt.getDoubtTableHtml("dialog")}
                ${this._closeButtonHtml()}
            </doubt-window>
        `;
    }

    
    _createMapHtml(map_id)
    {
        const map = masterdata.get_map.find(x => x.id == map_id);
        if (map === undefined) {
            console.error(`${map_id}: マスターデータ[マップ獲得ダイアログ]に存在しないidです。`);
            return ``;
        }
        return `
        <map-window>
            <title>${map.title}</title>
            <info>※「推理ノート」内の【 マップ 】から確認できます。</info>
            <content>
                <picture style='background-image: url(${map.image_path});'>
                </picture>
            </content>
            ${this._closeButtonHtml()}
        </map-window>`;
    }
    
    createNoteQuestionWindow(chara_id, chara_name, piece_id,decide_target, cancel_target, cost, consume_cost)
    {
        const data = masterdata.define_dialog["DETECTIVE_QUESTION"];
        let dialog = Common.createDialogBase(false);
        const piece = getPiece(piece_id);
        const new_cost = Math.max(cost- consume_cost, 0);
        const color_index = getCharacter(piece.chara_id).colorIndex();

        const q = getQuestion(`${chara_id}_${piece_id}`);
        const quest_keys = ["cond1", "cond2", "cond3", "cond4", "cond5", "cond6", "cond7"];
        const q_cond_key = quest_keys.find(key => checkConditionsStr(q[key]));
        let alert = undefined;
        if(q_cond_key){
            const alert_icon = `${q_cond_key}_alert`;
            alert = q[alert_icon]; 
        }
        let tag_html = ``;
        const tags = Object.keys(piece.tag_list);
        tags.forEach(x => {
            const tag_index = mist_system.NoteContainer2.getTagIndex(x);
            tag_html += `<tag class="tag${tag_index}"></tag>`;
        });

        const html = `
            <note-question-window>
                    <content-grid>
                        <item>
                            <item-info class="color${color_index}">
                                ${alert ? `<${alert}></${alert}>` : ""}
                                <title class="color${color_index}">${piece.title}</title>
                                <text>${piece.desc}</text>
                                <hash-tags>
                                    ${tag_html}
                                </hash-tags>
                            </item-info>
                            <item-frame class="color${color_index}">
                                <piece style="background-image: url(./data/image/detective/icon/${piece.resource2}.png);"></piece>
                                ${alert ? `<${alert}></${alert}>` : ""}
                                <hash-tags>
                                    ${tag_html}
                                </hash-tags>
                                ${piece.detail ? "<lens></lens>": ""}
                            </item-frame>
                        </item>
                        <text-grid>
                        <text>${chara_name}にこの手がかりについて質問しますか？</text>
                        ${alert ? `<alert>※疑いが向くような質問は、信用度を減らす可能性があります。</alert>` : ""}
                        </text-grid>
                        <cost-grid>
                            <cost-label-start>残り<font style="font-size:48px">${cost}</font>分 </cost-label-start>
                            <cost-arrow></cost-arrow>
                            <cost-label-end><font style="font-size:48px">${new_cost}</font>分 </cost-label-end>
                        </const-grid>
                    </content-grid>
                    <bottom>
                        <item>
                            <mist-button class="dialog-decide-button">${data.yes}</mist-button>
                            <line id="decide"></line>
                            <cursor id="decide"></cursor>
                        </item>
                        <item>
                            <mist-button class="dialog-cancel-button">${data.no}</mist-button>
                            <line id="cancel"></line>
                            <cursor id="cancel"></cursor>
                        </item>
                    </bottom>
            </note-question-window>
            `;
        dialog.html(html);

        if(piece.detail) {
            const detail_html = `
                <piece-detail-window>
                    <img src="./data/image/${piece.detail}">
                </piece-detail-window>`;
            dialog.append(detail_html);
        }

        const lens = dialog.find("lens");
        const detail_window = dialog.find("piece-detail-window");
        const note_question_window = dialog.find("note-question-window");
        Common.setVisible(detail_window, false);
        lens.hover(function() {
            $(this).addClass("hover");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        },
        function() {
            $(this).removeClass("hover");
        });
        lens.click(function(e) {
            e.stopPropagation();

            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });

            Common.setVisible(detail_window, true);
            Common.setVisible(note_question_window, false);

            const button_elem = $(".dialog");
            
            const display_param = {
                close_event_q_key: function(e){
                        button_elem.off();
                        e.stopPropagation();
                        button_elem.removeClass("dialog-piece-detail-close-button");

                        Common.setVisible(detail_window, false);
                        Common.setVisible(note_question_window, true);
                        mist_system.FooterContainer.back();

                        TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys01.mp3", stop:true });
                },
                is_visible_footer_base: true
            }
            mist_system.FooterContainer.showDialogFooter(display_param);

            
            button_elem.addClass("dialog-piece-detail-close-button");
            button_elem.off();
            button_elem.click(function(e) {
                button_elem.off();
                e.stopPropagation();
                button_elem.removeClass("dialog-piece-detail-close-button");

                $(".dialog-close-button").off("click");
                $(".dialog-close-button").off("mouseenter");
                $(".dialog-close-button").off("mouseleave");

                Common.setVisible(detail_window, false);
                Common.setVisible(note_question_window, true);
                mist_system.FooterContainer.back();

                TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys01.mp3", stop:true });
            });
        });
        const decide_button = dialog.find("bottom > item").eq(0);
        const yes_cursor = decide_button.find("cursor");
        const yes_line = decide_button.find("line");
        const yes_text = decide_button.find("mist-button");
        Common.setVisible(yes_cursor, false);
        Common.setVisible(yes_line, false);
        const decide_event =  () => {

            const jump_pm = { target: decide_target, storage: "" };
            if (jump_pm.target != "" || jump_pm.storage != "") {
                TYRANO.kag.ftag.startTag("jump", jump_pm);
            }
        }
        const cancel_event =  () => {
            const jump_pm = { target: cancel_target, storage: "" };
            if (jump_pm.target != "" || jump_pm.storage != "") {
                TYRANO.kag.ftag.startTag("jump", jump_pm);
            }
        }
        this.setButtonEventCallback(decide_button, decide_event,
            () => {
                Common.setVisible(yes_line, true);
                yes_cursor.addClass("selected");
                yes_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(yes_line, false);
                yes_cursor.removeClass("selected");
                yes_text.removeClass("selected-white-back");
            },
            "system/se_sys02.mp3",
        );

        const cancel_button = dialog.find("bottom > item").eq(1);
        const no_cursor = cancel_button.find("cursor");
        const no_line = cancel_button.find("line");
        const no_text = cancel_button.find("mist-button");
        Common.setVisible(no_cursor, false);
        Common.setVisible(no_line, false);
        this.setButtonEventCallback(cancel_button, cancel_event,
            () => {
                Common.setVisible(no_line, true);
                no_cursor.addClass("selected");
                no_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(no_line, false);
                no_cursor.removeClass("selected");
                no_text.removeClass("selected-white-back");
            },
            "system/se_sys01.mp3",
        );

        Common.setFocus(decide_button);
        Common.fadeInAnimation(dialog);
    }

    openNoteQuestionPieceDetailWindow() {
        const note_question_window = $("note-question-window");
        const lens = note_question_window.find("lens");
        if(lens.length > 0) {
            lens.click();
            return true;
        }
        return false;
    }

    
    createChapterConfirmWindow(master, decide_target, cancel_target)
    {
        let dialog = Common.createDialogBase(false);
        const html = `
            <yesno-window>
                <chapter-content-grid>
                    <title>このチャプターからゲームを開始しますか？</title>
                    <warning>※オートセーブデータは上書きされます。</warning>
                    <thumbnail style="background-image: url(${master.image});"></thumbnail>
                    <text-chapter>${master.chapter_name}</text-chapter>
                    <text-title>${master.title}</text-title>
                </chapter-content-grid>
                ${this._yesNoButtonHtml("- はい", "- いいえ")}
            </yesno-window>`;

        dialog.html(html);
        this._yesNoButtonSetting(dialog, decide_target, cancel_target);
        Common.fadeInAnimation(dialog);
    }

    
    _closeButtonHtml()
    {
        return `
            <bottom>
                <close-button class='dialog-close-button event-setting-element'
                    data-event-tag='MIST_SERIALIZABLE'
                    data-event-pm='{"deserialize_func":"setEventUpdateDialogCloseBtn"}'>
                    閉じる
                </close-button>
            </bottom>`;
    }
    
    _yesNoButtonHtml(decide_name = "- 決定", cancel_name = "- キャンセル")
    {
        return `
        <dialog-yesno-button>
            <button-grid>
                <yesno-item>
                    <mist-button class="dialog-decide-button">${decide_name}</mist-button>
                    <line></line>
                    <cursor></cursor>
                </yesno-item>
                <yesno-item>
                    <mist-button class="dialog-cancel-button">${cancel_name}</mist-button>
                    <line></line>
                    <cursor></cursor>
                </yesno-item>
            </button-grid>
        </dialog-yesno-button>
        `;
    }

    
    _yesNoCancelButtonHtml(yes_name = "- はい", no_name="- いいえ", cancel_name = "- キャンセル")
    {
        return `
        <dialog-yesno-button>
            <button-grid>
                <yesno-item>
                    <mist-button class="dialog-yes-button">${yes_name}</mist-button>
                    <line></line>
                    <cursor></cursor>
                </yesno-item>
                <yesno-item>
                    <mist-button class="dialog-no-button">${no_name}</mist-button>
                    <line></line>
                    <cursor></cursor>
                </yesno-item>
                <yesno-item>
                    <mist-button class="dialog-cancel-button">${cancel_name}</mist-button>
                    <line></line>
                    <cursor></cursor>
                </yesno-item>
            </button-grid>
        </dialog-yesno-button>
        `;
    }

    
    _yesNoButtonHtmlLine(decide_name = "- 決定", cancel_name = "- キャンセル")
    {
        return `
        <dialog-yesno-button>
            <button-grid>
                <yesno-item>
                    <mist-button class="dialog-decide-button">${decide_name}</mist-button>
                    <line class="halfsize"></line>
                    <cursor></cursor>
                </yesno-item>
                <yesno-item>
                    <mist-button class="dialog-cancel-button">${cancel_name}</mist-button>
                    <line class="halfsize"></line>
                    <cursor></cursor>
                </yesno-item>
            </button-grid>
        </dialog-yesno-button>
        `;
    }

    
    _yesNoButtonSetting(dialogBase, decide_target, cancel_target, focus_yes = true, click_event = null, decide_se_decision = false)
    {
        if (decide_target === undefined || cancel_target === undefined) {
            console.error("ラベルが未設定です");
            return;
        }

        
        setFlagStopGameProgress(true);
        if(decide_target == ""){
            this.nowStopping = TYRANO.kag.stat.is_strong_stop;
            
            if(!this.nowStopping) {
                
                
                this.callNextOrder = TYRANO.kag.stat.is_adding_text;
                stopGameProgress();
            }
        }


        const decide_button = dialogBase.find("yesno-item").eq(0);
        const yes_cursor = decide_button.find("cursor");
        const yes_line = decide_button.find("line");
        const yes_text = decide_button.find("mist-button");
        const cancel_button = dialogBase.find("yesno-item").eq(1);
        const no_cursor = cancel_button.find("cursor");
        const no_line = cancel_button.find("line");
        const no_text = cancel_button.find("mist-button");

        Common.setVisible(yes_cursor, false);
        Common.setVisible(yes_line, false);
        this.setButtonEvent(decide_button, decide_target, "",
            () => {
                Common.setVisible(yes_line, true);
                decide_button.addClass("selected");
                yes_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(yes_line, false);
                decide_button.removeClass("selected");
                yes_text.removeClass("selected-white-back");
            },
            decide_se_decision ? "system/se_sys03.mp3" : "system/se_sys02.mp3",
            click_event
        );

        Common.setVisible(no_cursor, false);
        Common.setVisible(no_line, false);
        this.setButtonEvent(cancel_button, cancel_target, "",
            () => {
                Common.setVisible(no_line, true);
                cancel_button.addClass("selected");
                no_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(no_line, false);
                cancel_button.removeClass("selected");
                no_text.removeClass("selected-white-back");
            },
            "system/se_sys01.mp3",
            click_event
        );

        if (!focus_yes || focus_yes == "false") {
            Common.setFocus(cancel_button);
        }
        else {
            Common.setFocus(decide_button);
        }
    }

    _yesNoCancelButtonSetting(dialogBase, yes_target, no_target, cancel_target, yes_click_se, no_click_se, cancel_click_se, focus_yes = true, click_event = null)
    {
        if (yes_target === undefined || no_target === undefined || cancel_target === undefined) {
            console.error("ラベルが未設定です");
            return;
        }

        
        setFlagStopGameProgress(true);
        if(yes_target == ""){
            this.nowStopping = TYRANO.kag.stat.is_strong_stop;
            
            if(!this.nowStopping) {
                
                
                this.callNextOrder = TYRANO.kag.stat.is_adding_text;
                stopGameProgress();
            }
        }


        const yesno_items = dialogBase.find("yesno-item");
        const yes_button = yesno_items.eq(0);
        const yes_cursor = yes_button.find("cursor");
        const yes_line = yes_button.find("line");
        const yes_text = yes_button.find("mist-button");
        const no_button = yesno_items.eq(1);
        const no_cursor = no_button.find("cursor");
        const no_line = no_button.find("line");
        const no_text = no_button.find("mist-button");
        const cancel_button = yesno_items.eq(2);
        const cancel_cursor = cancel_button.find("cursor");
        const cancel_line = cancel_button.find("line");
        const cancel_text = cancel_button.find("mist-button");
        

        Common.setVisible(yes_cursor, false);
        Common.setVisible(yes_line, false);
        this.setButtonEvent(yes_button, yes_target, "",
            () => {
                Common.setVisible(yes_line, true);
                yes_button.addClass("selected");
                yes_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(yes_line, false);
                yes_button.removeClass("selected");
                yes_text.removeClass("selected-white-back");
            },
            yes_click_se,
            click_event
        );

        Common.setVisible(no_cursor, false);
        Common.setVisible(no_line, false);
        this.setButtonEvent(no_button, no_target, "",
            () => {
                Common.setVisible(no_line, true);
                no_button.addClass("selected");
                no_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(no_line, false);
                no_button.removeClass("selected");
                no_text.removeClass("selected-white-back");
            },
            no_click_se,
            click_event
        );

        Common.setVisible(cancel_cursor, false);
        Common.setVisible(cancel_line, false);
        this.setButtonEvent(cancel_button, cancel_target, "",
            () => {
                Common.setVisible(cancel_line, true);
                cancel_button.addClass("selected");
                cancel_text.addClass("selected-white-back");
            },
            () => {
                Common.setVisible(cancel_line, false);
                cancel_button.removeClass("selected");
                cancel_text.removeClass("selected-white-back");
            },
            cancel_click_se,
            click_event
        );

        if (!focus_yes || focus_yes == "false") {
            Common.setFocus(no_button);
        }
        else {
            Common.setFocus(yes_button);
        }
    }
}

Common.sfAddClass(new Dialog());
