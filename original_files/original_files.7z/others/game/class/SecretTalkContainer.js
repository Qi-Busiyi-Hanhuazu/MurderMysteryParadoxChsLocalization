
class SecretTalkContainer
{
    constructor()
    {
        
        this.container_class = "secret-talk-container";
        this.move_container_class = "items";
        this.select_class = "select-window";
        this.move_animeation_speed = 100;
    }

    
    setEvent()
    {
        $(".message10_fore").off("click");
        $(".message10_fore").click(() => {
            if (mist_temp.is_tutorial) return;

            TYRANO.kag.key_mouse.next();
            this._scrollBottom();
        });
    
        $(".message11_fore").off("click");
        $(".message11_fore").click(() => {
            if (mist_temp.is_tutorial) return;
            
            TYRANO.kag.key_mouse.next();
            this._scrollBottom();
        });

        
        const talk_container = $(".secret-talk-container");
        talk_container.off("scroll");
        talk_container.on("scroll", function() {
            const currentHeight = $(".secret-talk-container items").height();
            const baseHeight = talk_container.height(); 
            const original_pos = currentHeight - baseHeight;
            const scrollPosition = talk_container.scrollTop(); 
            const offsetY = original_pos-scrollPosition;
            if (Math.abs((currentHeight - scrollPosition) / baseHeight) <= 1.005) {
                mist_system.DetectiveContainer.showChoiceEffect();
            }else{
                mist_system.DetectiveContainer.hideChoiceEffect();
            }
        });
    }

    
    createContainer()
    {
        mist_save.secret_talk_now = true;

        const message10 = $(".message10_fore");
        const message11 = $(".message11_fore");
        
        let is_exist = message11.find(`.${this.container_class}`).length > 0;
        if(!is_exist)
        {
            message11.append(`
            <div class='${this.container_class}'>
                <${this.move_container_class}>
                </${this.move_container_class}>
            </div>
            `);
            message11.css("height", "1000px");
            message11.find(".message_outer").remove();
            message11.find(".message_inner").css({
                "top": 0,
                "z-index": -1,
            });
            message11.find(".message_inner").addClass("message_inner_original");
            message11.find(".message_inner").removeClass("message_inner");

            message10.css("text-align", "center");
            message10.find(".message_inner").css({
                "display":"flex",
                "align-items":"center",
                "justify-content":"center"
            });
        }
        
        message11.find(".message_inner_original").css("display", "");
        message11.find(".secret-talk-container").css("display", "");

        message10.css("z-index", 1000001);
        message11.css("z-index", 1000000);

        this.setEvent();
    }

    
    removeContainer()
    {
        Common.unregisterWheel("SecretTalk");
        mist_save.secret_talk_now = false;

        
        this.clearBallon();
        
        $(".message11_fore").css("z-index", "");
        $(".message11_fore").off("click");
        $(".message10_fore").css("z-index", "");
        $(".message10_fore").off("click");
        
        $(".message11_fore").find(".CREDIT_EFFECT").remove();

        $(`.${this.container_class}`).remove();
    }

    
    copyContainer()
    {
        
        let inner = $(".message11_fore").children(".secret-talk-container").find("window").first().find("inner");
        inner.append(inner.find(".message_inner").clone());

        let disp_message = inner.find(".message_inner").eq(1);
        
        disp_message.addClass("disp_message");
        disp_message.removeClass("message_inner");
        disp_message.find(".current_span").removeClass("current_span");
        
        
        disp_message.css("opacity", 0);
    }

    
    clearNotReadedSelectBallon()
    {
        const elem = $(`.${this.container_class}`).find("select-window").not(".readed");
        const is_clear = elem.length > 0;
        if (is_clear) { elem.remove(); }
        return is_clear;
    }

    
    clearBallon()
    {
        mist_save.is_monologue = false;
        $(".message11_fore").find(`${this.move_container_class}`).empty();
    }

    
    createBallon(is_monologue)
    {
        mist_save.is_monologue = is_monologue;

        const { window_type, css_color, is_nameplate } = this._getBallonStyle(is_monologue);
        mist_save.window_font_color = css_color;
        mist_save.window_font_size = null;
        mist_save.window_type = window_type;

        let message_layer = $(".message11_fore");
        let secret_talk_container = message_layer.children(`.${this.container_class}`).children(`${this.move_container_class}`);

        
        this._readedBallon(secret_talk_container);

        const nameplate_html = (function() {
            if (!is_nameplate) return "";
            if (is_monologue) return "";

            let jp_name = Common.getCharaName();
            
            if (jp_name == "NPC") {
                const character_list = mist_system.DetectiveManager.characters;
                const chara = character_list.find(x => x.id == mist_save.npc_key);
                jp_name = chara.name;
            } else if (jp_name == "主人公") {
                jp_name = mist_save.player.name;
            }

            const name_id = mist_system.DetectiveManager.getCharacterByName(jp_name).name_id;
            const obj = masterdata.names[name_id];
            if (obj === undefined) {
                console.error(`${jp_name} : 呼び名マスタの"sysname"に存在しない名前です。`);
                return "";
            }
            return `<chara-name-base>
                <name>${obj.fullname}</name>
                <line></line>
            </chara-name-base>`;
        })();

        secret_talk_container.prepend(`
        <window class="${window_type}">
            <inner></inner>
            ${nameplate_html}
        </window>`);


        let window = secret_talk_container.find("window").first();
        
        
        window.css("transition-duration", `${this.move_animeation_speed}ms`);

        let inner = window.find("inner");
        inner.append(message_layer.children(".message_inner_original").clone());

        let message_inner = inner.find(".message_inner_original");
        message_inner.removeClass("message_inner_original");
        message_inner.addClass("message_inner");
        message_inner.css("opacity", 1);
        message_inner.css("width", inner.css("width"));
        message_inner.css("height", inner.css("height"));
        message_inner.css("left", 0);

        this._moveAnimation(secret_talk_container);
    }

    
    createSelectBallon()
    {
        {
            const count = mist_system.DetectiveManager.getDoubtCount(mist_save.npc_key);
            mist_save.listeningTitle = this._createSelectRow(mist_save.listeningTitle, mist_save.listeningTime, "1", count);
            if(count > 0){
                const x = 642;
                const y = 327;
                TYRANO.kag.ftag.startTag("layermode_movie",{name:`badge-movie-choice`,video:"ef025.mp4",zIndex:"999999999",skip:"false",width:"80",height:"80",top:y,left:x,mode:"screen",loop:"true",fit:"false",stop:"true"});
            }
        }
        {
            const count = mist_system.DetectiveManager.getInferenceCount(mist_save.npc_key);
            mist_save.inferenceTitle = this._createSelectRow(mist_save.inferenceTitle, mist_save.inferenceTime, "2", count);
        }
        {
            const count = mist_system.DetectiveManager.getBuiltInferenceCount(mist_save.npc_key);
            mist_save.showInferenceTitle = this._createSelectRow(mist_save.showInferenceTitle, mist_save.showInferenceTime, "3", count);
        }
        {
            const count = mist_system.DetectiveManager.getQuestionCount(mist_save.npc_key);
            mist_save.doubtTitle = this._createSelectRow(mist_save.doubtTitle, mist_save.doubtTime, "4", count);
        }
		{
            mist_save.choiceEndSecretTitle = this._createSelectRow(mist_save.choiceEndSecretTitle, 0, "icon0", 0, false);
		}
        const choices = [
            { text: mist_save.listeningTitle,        exp: mist_save.expListeningCost, target: "*doListening" },
            { text: mist_save.inferenceTitle,        exp: mist_save.expListeningCost, target: "*CallCreateInference" },
            { text: mist_save.showInferenceTitle,    exp: mist_save.expListeningCost, target: "*doInference" },
            { text: mist_save.doubtTitle,            exp: mist_save.expListeningCost, target: "*doDoubt" },
            { text: mist_save.choiceEndSecretTitle,  exp: mist_save.expListeningCost, target: "*ConfirmJumpSecretToDebate" },
        ];
        const topic = guidanceMessage("secret_top").text;
        this.createSelect(topic, choices, "default");
    }

    
    _createSelectRow(text, time, _icon_class, count, visible_icon = true) {
        const icon_type = `type${_icon_class}`;
        const icon_class = count == 0 ? `disable` : ``;
        const icon_style = visible_icon ? "" : "hidden";
        const badge_style = count == 0 ? "hidden" : "visible";
        const time_content = time == 0 || getCost() <= 1 ? "" : `-${time}分`;
        return `
            <icon class="${icon_type} ${icon_class}" style="visibility: ${icon_style};">
                <badge style="visibility: ${badge_style};"><number>${count}</number></badge>
            </icon>
            <text>${text}</text>
            <time>${time_content}</time>
            <cursor></cursor>`;
    }

    
    createSelect(topic, choices, type="")
    {
        const leftOneCost = getCost() <= 1;
        let container = $(".message11_fore").children(`.${this.container_class}`).children(`${this.move_container_class}`);
        const is_clear = this.clearNotReadedSelectBallon();

        let selection = [];
        let selectionHtml = "";
        choices.forEach((choice, index) => {
            const select_id = `select${index + 1}`;
            selection.push(`#${select_id}`);
            const text = type === "default" ? choice.text : `‐${choice.text}`;
            selectionHtml += `<li id='${select_id}' type="${type}">${text}<line></line><cursor></cursor></li>`;
        });

        this._readedBallon(container);

        
        
        if(leftOneCost && isModeInvestigation()) {
            const leftOneTopic = getCommonHelpDirect("left_one_sercret_select_topic");
            if(leftOneTopic)
            {
                topic = leftOneTopic;
            }
        }

        container.prepend(`
        <select-window type="${choices.length}">
            <div>
                <text>${topic}</text>
                <ul>
                    ${selectionHtml}
                </ul>
            </div>
        </select-window>`);

        choices.forEach((choice, index) => {
            const idx = index + 1;
            const id = "#select{0}".format(idx);
            const pm = {idx: idx, exp: `${choice.exp}`, target: choice.target,deserialize_func: "setSecretTalkSelectOption"}; 
            
            if (type === "") {
                pm.text = choice.text;
            }
            let elem = $(id);
            Common.makeFocusable(elem);
            setSecretTalkSelectOption(elem, pm);
            Common.addDataEvent(elem, pm);

        });

        
        if (!is_clear) {
            this._moveAnimation(container);
        }
    }

    
    footerBack() {
        if(mist_temp.secret_talk_select_list !== undefined) {
            Common.setFocus(mist_temp.secret_talk_select_list[mist_temp.secret_talk_container_last_select_index + 1]);
        }
    }

    
    _getBallonStyle(is_monologue)
    {
        const chara_name = Common.getCharaName();
        const player_name = "主人公";
        const leftWindow = () => {
            return {
                window_type: "pc",
                css_color: "0xFFFFFF",
                is_nameplate: true,
            }
        };
        const leftMonologueWindow = () => {
            return {
                window_type: "pc-mono",
                css_color: "0xFFFFFF",
                is_nameplate: true,
            };
        };
        const infoWindow = () => {
            return {
                window_type: "info",
                css_color: "0x000000",
                is_nameplate: false,
            };
        };
        const rightWidow = () => {
            return {
                window_type: "npc",
                css_color: "0xFFFFFF",
                is_nameplate: true,
            };
        };

        const chara = mist_system.DetectiveManager.getCharacterByName(chara_name);
        if (chara) {
            const index = mist_save.talk_characters.findIndex(x => x == chara.id);
            switch (index) {
                case 0:
                    return is_monologue ? leftMonologueWindow() : leftWindow();
                case 1:
                    return rightWidow();
            }
        }

        
        
        if(chara_name == '')
        {
            return infoWindow();
        }
        else if(chara_name != player_name)
        {
            return rightWidow();
        }
        else if(chara_name == player_name && is_monologue)
        {
            return leftMonologueWindow();
        }

        return leftWindow();
    }

    
    _readedBallon(container)
    {
        const prev_window = container.children().first();
        if (prev_window.length == 0) return;

        
        if (container.children().length >= 80) {
            container.children().last().remove();
        }

        prev_window.addClass("readed");
        const is_select = prev_window[0].localName == "select-window";
        
        if (is_select) {
            $(`video[data-video-name="badge-movie-choice"]`).remove(); 
            prev_window.find("li").each(function() {
                const elem = $(this);
                elem.off("click");
                elem.removeAttr("id");
                Common.makeUnfocusable(elem);
                Common.deleteDataEvent(elem);
            });
        } else {






















            prev_window.find("line").addClass("off");
        }
    }

    
    _scrollBottom()
    {
        let container = $(`.${this.container_class}`);
        container.scrollTop(container.get(0).scrollHeight);
    }

    
    _moveAnimation(move_container)
    {
        if (move_container.children().length == 1) return;
        
        if(move_container.is(':animated')){
            move_container.stop(true, true);
        }

        this._scrollBottom();

        const firstItem = move_container.children().first();
        const height = firstItem.outerHeight(true);
        
        move_container.css("top", height);
        
        move_container.animate({
            top: "0px",
        }, this.move_animeation_speed);
    }

    
     setMoveAnimationSpeed(speed)
     {
         this.move_animeation_speed = speed;
     }
}

Common.sfAddClass(new SecretTalkContainer());
