
class TutorialDialog {
    constructor() {
        this.master = [];
        this.page = 0;
        this.target = "";
        this.cls_callback = undefined;
        this.creating = undefined;
        this.isAlwaysCloseButton = false;
        this.tutorial_bgm_back = undefined;
    }

    
    load()
    {
        
        if (mist_system.tutorial === undefined) return;
        this.master = mist_system.tutorial.master;
        this.page = mist_system.tutorial.page;
        this.target = mist_system.tutorial.target;
        this.addEvent();
    }

    addEvent()
    {
        
        let dialog = $(".dialog");

        
        const left_button = dialog.find("cell_left");
        left_button.hover(function() {
            $(this).addClass("select");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, function() {
            $(this).removeClass("select"); 
        });
        left_button.click((e) => {
            if (this.isStartPage) {
                return;
            }
            e.stopPropagation();
            this.prev();
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
        });

        
        const right_button =  dialog.find("cell_right");
        right_button.hover(function() {
            $(this).addClass("select");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, function() {
            $(this).removeClass("select"); 
        });
        right_button.click((e) => {
            e.stopPropagation();
            if (this.isEndPage)
            {
                
                this.close();
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys09.mp3", stop: true });
            }
            else
            {
                this.next();
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            }
        });

        
        const right_button2 =  dialog.find("cell_right2");
        right_button2.hover(function() {
            $(this).addClass("select");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        }, function() {
            $(this).removeClass("select"); 
        });
        right_button2.click((e) => {
            e.stopPropagation();
            this.close();
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys09.mp3", stop: true });
        });

        
        const close_button =  dialog.find("close-button");
        close_button.hover(function() {
            $(this).addClass("select");
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys09.mp3", stop: true });
        }, function() {
            $(this).removeClass("select"); 
        });

        const that = this;
        const close_func = function(){
            if (!that.isEndPage && !that.isAlwaysCloseButton) {
                return;
            }
            
            if(that.isAlwaysCloseButton){
                xClickCallback = undefined;
            }
            that.close();
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys09.mp3", stop: true });
        }
        if(this.isAlwaysCloseButton){
            
            xClickCallback = close_func;
        }
        close_button.click((e) => {
            e.stopPropagation();
            close_func();
        });
        Common.makeFocusable(left_button);
        Common.makeFocusable(right_button);
        Common.makeFocusable(right_button2);
    }

    
    create(group = "", target = "", cls_callback = undefined, ballback_obj = undefined, is_game_stop = true, add_backlog = true, is_always = false) {
        if(this.creating) {
            
            return;
        }
        mist_temp.is_tutorial = true;
        this.tutorial_bgm_back = undefined;

        
        mist_system.tutorial = {
            master: masterdata.tutorial[group],
            page: 0,
            target: target,
        };
        this.master = mist_system.tutorial.master;
        this.page = mist_system.tutorial.page;
        this.target = mist_system.tutorial.target;
        this.cls_callback = cls_callback;
        this.ballback_obj = ballback_obj;

        if (!mist_system.tutorial_group) {
            mist_system.tutorial_group = {};
        }

        if(mist_system.tutorial_group[group] && !is_always){
            
            this.close(true);

            return ;
        }

        
        this.isAlwaysCloseButton = is_always;

        
        this.tutorial_bgm_back = getSystemBgmTempVolume();
        setTempBgmVolume(getSystemBgmTempVolume() / 2);

        
        if (add_backlog) {
            console.log("add_backlog");
            mist_save.backlog_item_type = "tutorial";
            mist_save.backlog_item_id = group;
            const tempMono = mist_save.is_monologue;
            mist_save.is_monologue = false;

            const title = this.master[this.page].title;
            TYRANO.kag.pushBackLog("", `チュートリアル${title}`, "add", true);
            if (TYRANO.kag.stat.f_chara_ptext == "true") {
                TYRANO.kag.stat.f_chara_ptext = "false";
                TYRANO.kag.stat.log_join = "true";
            }
            mist_save.backlog_item_type = undefined;
            mist_save.backlog_item_id = undefined;
            mist_save.is_monologue = tempMono;
        }
        

        this.creating = group;
        let dialog = Common.createDialogBase(false);
        const window = `
            <tutorial-window>
                <cell-top>
                    <cell-image></cell-image>
                </cell-top>

                <cell-mid>
                    <title>チュートリアル：密談相手を選択</title>
                    <cell-line></cell-line>
                    <cell-text>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting
                    </cell-text>
                </cell-mid>

                <cell-bottom>
                    <cell_left2></cell_left2>
                    <cell_left></cell_left>
                    <page>
                        <text></text>
                    </page>
                    <cell_right></cell_right>
                    <cell_right2></cell_right2>
                </cell-bottom>
                <close-button class="dialog-close-button"></close-button>
            </tutorial-window>`;
        dialog.html(window);
        dialog.css("background-color", "rgba(0, 0, 0, 0.9)")
        this.addEvent();
        this.update();

        Common.fadeInAnimation(dialog);
        mist_system.tutorial_group[group] = true;

        
        if (group == 941 || group == 942) {
            mist_system.tutorial_group[941] = true;
            mist_system.tutorial_group[942] = true;
        }

        Common.saveSystem();
        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys08.mp3", stop: true });

        
        setFlagStopGameProgress(true);
        if(target == "" && is_game_stop == true){
            this.nowStopping = TYRANO.kag.stat.is_strong_stop;
            
            if(!this.nowStopping) {
                
                
                this.callNextOrder = TYRANO.kag.stat.is_adding_text;
                stopGameProgress();
            }
        }
        this.creating = undefined;
    }

    
    get isStartPage() {
        return this.page == 0;
    }

    
    get isEndPage() {
        return this.page == this.master.length - 1;
    }

    
    get havePager() {
        return this.master.length > 1;
    }


    
    set updatePage(value) {
        this.page = Common.clamp(value, 0, this.master.length - 1);
        mist_system.tutorial.page = this.page;
    }

    
    setVisible(elem, is_visible)
    {
        elem.css("visibility", is_visible ? "visible" : "hidden");
    }

    
    update() {
        const window = $("tutorial-window");
        this.setVisible(window.find("cell_left"), !this.isStartPage);
        this.setVisible(window.find("cell_right"), !this.isEndPage);
        this.setVisible(window.find("cell_right2"), this.isEndPage);
        this.setVisible(window.find("close-button"), this.isEndPage || this.isAlwaysCloseButton);
        if (this.isEndPage) {
            
            this.isAlwaysCloseButton = true;
        }

        const right_button = window.find("cell_right");
        window.find("text").html(`${this.page + 1} / ${this.master.length}`);

        const { title, image, text } = this.master[this.page];
        if (title !== "")
        {
            window.find("title").html(title);
        }
        const cell_image = window.find("cell-image");
        if (image !== ""){
            
            cell_image.css("background-image", `url(${image})`);
        }
        this.setVisible(cell_image, image !== "")
        window.find("cell-text").html(Common.autoBRText(text, 36));
    }

    
    prev() {
        this.updatePage = --this.page;
        this.update();
    }

    
    next() {
        this.updatePage = ++this.page;
        this.update();
    }

    
    close(immediately_close=false) {
        delete mist_system.tutorial;
        mist_temp.is_tutorial = false;

        
        if (this.tutorial_bgm_back != undefined) {
            setTempBgmVolume(this.tutorial_bgm_back);
        }
        
        
        setFlagStopGameProgress(false);
        if(this.target){
            TYRANO.kag.ftag.startTag("jump", { target: this.target });
        }
        if(this.cls_callback){
            if(!this.nowStopping) {
                
                if(!immediately_close){
                    
                    
                    TYRANO.kag.layer.showEventLayer(); 
                }
                restartGameProgress(this.callNextOrder);
                this.callNextOrder = false;
            }
            this.nowStopping = false;

            Common.clearDialogLayer();
            this.cls_callback.apply(this.ballback_obj);
            return ;
        }

        Common.clearDialogLayer();
    }

    
    checkAndBack() {
        const tutorial_window = $('tutorial-window');
        if (tutorial_window.length > 0)
        {
            const l = tutorial_window.find("cell_left");
            l.click();
            return true;
        }
        return false;
    }

    
    checkAndNext() {
        const tutorial_window = $('tutorial-window');
        if (tutorial_window.length > 0)
        {
            const l = tutorial_window.find("cell_right");
            l.click();
            return true;
        }
        return false;
    }
}

Common.sfAddClass(new TutorialDialog());
