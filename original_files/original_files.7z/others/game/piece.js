Piece = class{
  resource_path = "detective/icon";
  detail_path = "item";
  ignore_replace_key = "*"; 
  constructor(id, chara_id, unixtime, display_date, display_time, title, desc, tag_info){
    this.id = id;
	this.chara_id = chara_id;
    this.title = title;
	this.desc = desc;
	this.tag_info = tag_info; 
	this.unixtime = 0;
	this.display_date = display_date;
	this.display_time = display_time;
  }
  setup(){
	this.desc = Common.replaceDefineLabelStringAll(Common.replaceDefineColorString(this.desc));
	if(typeof this.tag_info === "undefined"){
		this.tag_info = "";
	}else{
		this.tag_info = Common.replaceDefineLabelStringAll(this.tag_info);
	}
	
	const result = this.desc.indexOf(this.ignore_replace_key, 0);
	if(result != -1){ this.desc = this.desc.replace(this.ignore_replace_key, ""); }
	if(this.display_time && result != 0){
		this.desc = this.display_time + "。" + this.desc;
	}
	
	if(this.unixtime <= 0){
		this.unixtime = -1;
	}
	this.tag_list = this.parseTag();
	this.removeTag();
	this.completionPath();
  }

  completionPath(){
	
	this.resource2 = this.resource;
	if(this.resource) {
		if(this.resource.indexOf(this.resource_path) == -1){
			this.resource = `${this.resource_path}/${this.resource}.png`;
		}
	}

	if(this.detail) {
		if(this.detail.indexOf(this.detail_path) == -1){
			this.detail = `${this.detail_path}/${this.detail}.png`;
		}
	}
  }

  getTagStr(tag){
	if(!this.tag_list[tag]){
		return this.getTagStrOld(tag);
		return "";
	}
	return this.tag_list[tag];

  }
  getTagList() {
	if(Object.keys(this.tag_list).length ==0){
		return this.getTagListOld();
	}
	return Object.keys(this.tag_list);
  }

  
  getTagStrOld(tag){
	let begin = this.tag_info.indexOf(">", this.tag_info.indexOf(tag, 0)) + 1;
	let end = this.tag_info.indexOf("<", begin);
	if(end == -1){
		end = this.tag_info.length;
	}
	return this.tag_info.substring(begin, end);
  }

  
  getTagListOld(){
	let ret = []
    let end = 0;
	let begin = this.tag_info.indexOf("<", end);
	while (begin >= 0) {
		end = this.tag_info.indexOf(">", begin + 1);
		ret.push(this.tag_info.substring(begin + 1, end));
		begin = this.tag_info.indexOf("<", end);
	}
	return ret;
  }
  
  parseTag() {
	let ret = {};
    let end = 0;
	const b_tag = "[#";
	const be_tag = "[/#";
	const e_tag = "]";
	const str = this.desc;
	let begin = str.indexOf(b_tag, end);
	while (begin >= 0) {
		
		end = str.indexOf(e_tag, begin + 1);
		const key = str.substring(begin + 1, end);
		
		begin = str.indexOf(b_tag, end);

		let str_begin = end + 1;
		let str_end = str.indexOf(be_tag, str_begin);
		const tag_str = str.substring(str_begin, str_end);
		ret[key] = tag_str;
	}
	return ret;
  }

  removeTag() {
	this.getTagList().forEach(tag => {
		const reg = RegExp(`\\[${tag}\\]|\\[/${tag}\\]`, 'g')
		this.desc = this.desc.replace(reg, "");
	});
  }

  colorIndex() {
	return getCharacter(this.chara_id).colorIndex();
  }
}



function setupPieceMaster(data){
	var tmp = JSON.parse(data)
	piece_dict = {};
	orderd_piece_keys = [];
	tmp.forEach(function(item, index, array) {
		let piece = Object.assign(new Piece(), item);
		piece.setup();
		piece_dict[piece.id] = piece;
		orderd_piece_keys.push(piece.id);
	});
}

function getPiece(id){
	return piece_dict[id];
}

function getPieceMaster(){
	return piece_dict;

}
