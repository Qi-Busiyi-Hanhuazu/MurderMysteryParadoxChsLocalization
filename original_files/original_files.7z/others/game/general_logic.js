
function preparePlayBgm(){
	if(TYRANO.kag.stat.f.preparedPlayBgm){
		return ;
	}
	TYRANO.kag.stat.f.preparedPlayBgm = true;
	TYRANO.kag.stat.f.current_play_bgm = "";
	TYRANO.kag.stat.f.prev_play_bgm = "";
}

function shouldPlayBgm(file){
	file = Common.replaceDefineLabelString(file);
	preparePlayBgm();
	return (TYRANO.kag.stat.f.current_play_bgm != file && file != "");
}

function playBgm(file){
	file = Common.replaceDefineLabelString(file);
	if(!shouldPlayBgm(file)){
		return ;
	}

	TYRANO.kag.stat.f.prev_play_bgm = TYRANO.kag.stat.f.current_play_bgm;
	TYRANO.kag.ftag.startTag("xchgbgm", {"storage":file, time:100, stop:true});
	TYRANO.kag.stat.f.current_play_bgm = file;
}

function playPrevBgm(){
	playBgm(TYRANO.kag.stat.f.prev_play_bgm);
}

function notPlayingPlayBgm(file){
    if (TYRANO.kag.stat.f.current_play_bgm != "") {
        return;
    }
    playBgm(file);
}


function loadJSScripts(files){
    files.forEach(file => {
        $.ajax({
            async: false,
            url: file,
            dataType: "script"
        });
    });
}



function loadDetectiveMasterFile(chapter){
    const available_chapters = ["prologue", "1", "2", "3", "4", "5"];
    if(!available_chapters.includes(chapter)){
        return ;
    }
    TYRANO.kag.variable.sf.detective_path = 'detective/';
    TYRANO.kag.variable.sf.detective_chapter_path = 'detective/chapters/{0}/'.format(chapter);
    TYRANO.kag.variable.sf.chapter_path = `chapters/${chapter}`;

    
    const base_path = `./data/others/data/${chapter}`;
    const chapter_files = [
        "character.js",
        "debate_topic.js",
        "doubt.js",
        "piece.js",
        "approach_condition.js",
        "piece_convincing.js",
        "npc_vote.js",
        "conversation.js",
        "guidance.js",
        "common_condition.js",
        "question.js",
        "note_person.js",
    ];

    const shouldLoadFiles = chapter_files.map(f => `${base_path}/${f}`);
	loadJSScripts(shouldLoadFiles);
}


function loadDetectiveMasterData(){
    const available_chapters = ["prologue", "1", "2", "3", "4", "5"];
    if(!available_chapters.includes(mist_save.chapter)){
        return ;
    }

    setupCommonConditionMaster(common_condition_rawdata());
    setupDebateTopicMaster(debate_topics());
    setupDoubtMaster(doubt_rawdata());
    setupPieceMaster(piece_rawdata());
    setupCharacterMaster(character_rawdata());
    setupCharacterCredit();
    setupApproachConditionMaster(approach_condition_rawdata());
    setupPieceConvincing(piece_convincing_rawdata());
    setupNpcVoteMaster(npc_vote_rawdata());
    setupBackgroundMaster();
    setupConversationMaster(conversation_rawdata());
    setupGuidanceMaster(guidance_rawdata());
    setupQuestionMaster(question_rawdata());

    masterdata.note_person = (function() {
        let json = JSON.parse(note_person_rawdata());
        
        json.forEach(data => {
            if(data.image.indexOf('./data/fgimage/chara/') == -1) {data.image = `./data/fgimage/chara/${data.image}/facephoto.png`;}
        });
        return Common.groupBy(json, "group");
    })();

    
    mist_system.DetectiveManager.load();
}
