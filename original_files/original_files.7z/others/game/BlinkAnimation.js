
class BlinkAnimation
{
    constructor()
    {
        this.ANIMATION_CLASS = "blink";
        if (typeof blink_rawdata !== 'function') {
            console.error("目パチデータが作成されてません");
            return;
        }
        this.map = JSON.parse(blink_rawdata());
    }

    
    load()
    {
        Object.keys(this.map).forEach((selector) => {
            if ($(selector).length == 0) return;
            this.setAnimationEvent($(selector));
        });
    }

    
    create()
    {
        console.error("BlinkAnimation: 目パチはマスターデータで事前作成してください。");
    }

    
    animation(mp, is_load = true, on_complete=undefined)
    {
        const chara = TYRANO.kag.stat.charas[mp.name];
        const id = mp.eye;
        if (chara["_layer"] === undefined) return "";
        const part = chara["_layer"]["eye"];
        if (part === undefined) return "";

        
        if (!$("." + mp.name).length) {
            part.current_part_id = id;
            
            
            mp.time = 1;
            TYRANO.kag.ftag.startTag("chara_part", mp);
            return "";
        } 

        if(part[id] === undefined) {
            console.error(`eye : ${mp.name}の[${id}] はありません`);
            return "";
        }

        part.current_part_id = id;
        const storage = `./data/fgimage/${part[id].storage}`;
        const selector = $(`.${mp.name} .eye`);
        if (selector.length == 0) return;

        if (!is_load) {
            return storage;
        }

        this.removeAnimationClass(selector);
        selector.off('animationiteration');
        
        
        TYRANO.kag.preload(storage, () => {
            
            const classlist = Common.getClassList(selector);
            for (var i = 0; i < classlist.length; i++) {
                if (classlist[i] === "eye") continue;
                if (classlist[i] === "part") continue;
                selector.removeClass(classlist[i]);
            }

            
            selector.addClass(id);
            const part_data = part[part.current_part_id];
            const src = `./data/fgimage/${part_data.storage}`;
            selector.attr("src", mist_save.blank_image);
            selector.css({
                "background": `url(${src}) 0 0 no-repeat`,
                "left": `${part_data.left}px`,
                "top": `${part_data.top}px`,
                "width": `${part_data.width}px`,
                "height": `${part_data.height}px`,
            });
            this.setAnimationEvent(selector);

            if(on_complete) {
                on_complete();
            }
        });
        return "";
    }

    
    setVisible(mp)
    {
        if (!mp.name || !mp.part) return false;
        const chara = TYRANO.kag.stat.charas[mp.name];
        if (!chara["_layer"] || !chara["_layer"][mp.part]) return false;

        const elem = $(`.${mp.name} .${mp.part}`);
        if (!elem.length) return false;

        const visible_str = Common.toBool(mp.is_hidden) ? "hidden" : "visible";
        elem.css("visibility", visible_str);
        return true;
    }

    stopAllAnimation()
    {
        const selector = $(`.eye`);
        if (selector.length == 0) return;
        const that = this;
        selector.each(function(index, elem){
            const element = $(elem);
            that.removeAnimationClass(element);
            element.css("visibility", "hidden");
            element.off('animationiteration');
        });
    }
    
    setAnimationEvent(elem)
    {
        if (elem.length == 0) return;
        if (!(elem.selector in this.map)) {
            console.error(`${elem.selector} : 目パチデータがないです。`);
            return;
        }

        const length = this.map[elem.selector];
        this.removeAnimationClass(elem);
        
        const first_time = Common.randomRange(0, 2000);
        setTimeout(() => {
            
            this.addRandomAnimationClass(elem, length);
        }, first_time);

        
        elem.off('animationiteration');
        
        
        elem.on('animationiteration', () => {
            
            this.removeAnimationClass(elem);
            
            const time = Common.randomRange(1000, 5000);
            setTimeout(() => {
                
                this.addRandomAnimationClass(elem, length);
            }, time);
        });
        
        
    }

    
    removeAnimationClass(elem)
    {
        const class_list = Common.getClassList(elem);
        for (let i = 0; i < class_list.length; ++i)
        {
            if (class_list[i].indexOf(this.ANIMATION_CLASS) != -1)
            {
                elem.removeClass(class_list[i]);
            }
        }
    }

    
    addRandomAnimationClass(elem, length)
    {
        if (elem.length == 0) return;
        const index = Common.randomRange(0, length);
        elem.addClass(`${this.ANIMATION_CLASS}${index}`);
    }

    
    createBlinks()
    {
        const characters = JSON.parse(blink_chara_rawdata());
        const faces = (function() {
            const json = JSON.parse(blink_face_rawdata());
            return json.reduce((obj, x) => {
                obj[x.id] = x.faces.split(",").map(face => face.trim()).filter(face => face !== "");
                return obj;
            }, {});
        })();
        const master_animations = JSON.parse(blink_animation_rawdata());
        const animations = master_animations.map(x => {
            const keyframes = x.keyframes.split(",").map(k => k.trim());
            return {
                id: x.id,
                duration: x.duration,
                keyframes: keyframes.map(keyframe => keyframe.split("=")),
            };
        });


        let css_list = [];
        let js_obj = {};
        characters.forEach(chara => {
            const animation_ids = chara.animation_ids.split(",").map(x => x.trim());
            const anime = animation_ids.map(x => animations.find(y => y.id == x));
            const face_list = faces[chara.face_id];
            const mp = {
                anime: anime,
                name: chara.name,
                width: chara.width,
                part: "eye",
                face_id: chara.face_id,
            }
            const mp2 = {
                anime: anime,
                name: `${chara.name}_up`,
                width: chara.width,
                part: "eye",
                face_id: chara.face_id,
            }

            {
                const { style, selector, count } = this.createCssStyle(face_list, mp);
                if (style !== undefined) {
                    css_list.push(style);
                    js_obj[selector] = count;
                }
            }
            {
                const { style, selector, count } = this.createCssStyle(face_list, mp2);
                if (style !== undefined) {
                    css_list.push(style);
                    js_obj[selector] = count;
                }
            }
        });


        this.output(css_list, js_obj);
    }

    
    createCssStyle(face_list, mp)
    {
        const animation_name = `${mp.name}_${mp.part}`;
        const width = mp.width === undefined ? TYRANO.kag.stat.charas[mp.name]["origin_width"] : mp.width;

        let keyframes_css = "";
        let animations_css = "";
        mp.anime.forEach((anime, i) =>
        {
            let keyframe = "";
            anime.keyframes.forEach((blink) =>
            {
                const percent = blink[0];
                const position = (parseInt(blink[1]) * parseInt(width)) * -1;
                keyframe += ` ${percent} { background-position: ${position}px 0;}`;
            });
            const anim_index = `${animation_name}${i}_${mp.face_id}`;
            keyframes_css += `@keyframes ${anim_index} { ${keyframe} }\n`;

            
            face_list.forEach(face => {
                animations_css += `.${mp.name} > .${mp.part}.${face}.${this.ANIMATION_CLASS}${i} { animation: ${anim_index} ${anime.duration}s steps(1) infinite; }\n`;
            });
        });

        const style =
`/* 目パチアニメーション ${mp.name} */
.${mp.name} > .${mp.part} { object-fit: cover; object-position: 0% 0%; }
${keyframes_css}${animations_css}`;
        return {
            style: style,
            selector: `.${mp.name} .${mp.part}`,
            count: mp.anime.length,
        };
    }

    
    output(css_list, js_obj)
    {
        const path = require('path');
        const fs = require('fs');

        
        const css_dir = path.join(__dirname, "data/others/css");
        const css_path = path.join(css_dir, "blink_animations.css");
        const css_str = css_list.join("\n");
        console.log(css_path);
        fs.writeFile(css_path, css_str, (err) => {
            if (err) {
                console.error(`${css_path}: 失敗 ${err}`);
                return;
            } 
        });

        
        const data_system_dir = path.join(__dirname, "data/others/data/system");
        let json = JSON.stringify(js_obj);
        json = `function blink_rawdata(){ return '${json}'; }`;
        const js_path = path.join(data_system_dir, "blink_rawdata.js");
        console.log(js_path);
        fs.writeFile(js_path, json, (err) => {
            if (err) {
                console.error(`${js_path}: 失敗 ${err}`);
                return;
            } 
        });
    }
}

Common.sfAddClass(new BlinkAnimation());
