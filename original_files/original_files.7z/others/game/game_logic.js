
function getCharaScriptBasePathRoot(npc_key){
	return "detective/chapters/{0}/{1}/".format(TYRANO.kag.stat.f.chapter, npc_key);
}

function getCharaScriptBasePath(npc_key){
	return "detective/chapters/{0}/{1}/{1}_".format(TYRANO.kag.stat.f.chapter, npc_key);
}

function getFilePath(fname, npc_key){
	npc_key = npc_key || TYRANO.kag.stat.f.npc_key;
	return getCharaScriptBasePathRoot(npc_key) + fname;
}


function getHavingInferenceCount(npc_key){
	let count = 0;
	
	let doubt_charas= [];
	if(npc_key && npc_key in TYRANO.kag.stat.f.player_active_doubts){
		doubt_charas = TYRANO.kag.stat.f.player_active_doubts[npc_key];
	}else{
	
		doubt_charas = Object.values(TYRANO.kag.stat.f.player_active_doubts).map(idx => Object.values(TYRANO.kag.stat.f.player_active_doubts)[idx]);
	}
	doubt_charas.forEach((value) => {
		const doubt = getDoubt(value);
		if(doubt && doubt.hasInference()){
			count += 1;
		}
	});
	return count;
}


function getDebateCharacters(){
	
	let list = getCharacterListForDebateStatement();
	
	const data = getCommonCondition('debate_order');
	if(!data){
		return list;
	}
	const order = data.value;
	
	return list.sort((a,b) => {
		let o1 = 10000
		let o2 = 10000
		if(order[a.id]){ o1 = Number(order[a.id]); }
		if(order[b.id]){ o2 = Number(order[b.id]); }
		return o1 - o2
	});
	
}

function getDebateTopic(character){
	
	for(let [key, value] of Object.entries(debate_topic_dict)) {
        if(value.chara_id == character.id && checkConditionsStr(value.condition)){
			return value;
		}
	}
	return false;
}


function getPlayerDebateTopic(){
	let id = getPlayer().id
	for(let [key, value] of Object.entries(debate_topic_dict)) {
        if(value.chara_id == id && value.action_type == "推理" && checkConditionsStr(value.condition)){
			return value;
		}
	}
	return false;
}


function getPlayerPieceKeys(filter){
	return getPlayerPieceKeysImpl(orderd_piece_keys, filter);
}

function getPlayerPieceKeysInventory(filter){
	return getPlayerPieceKeysImpl([...TYRANO.kag.stat.f.player_pieces_orderd].reverse(), filter);
}

function getPlayerPieceKeysImpl(master_piece_keys, filter){
	
	let result = new Array();
	filter = filter || "";

	
	master_piece_keys.forEach((value) => {
		if(TYRANO.kag.stat.f.player_pieces[value]){
			if(filter == "" || piece_dict[value].getTagList().includes(filter)){
				result.push(value);
			}
		}
	});

	return result;
}


function getCreatingInference(piece_ids, doubt){
	let inference = getInference(piece_ids);
	inference.convince_level = calcConvinceLevel(doubt);
	inference.title = generateInferenceTitle(doubt);
	inference.desc = generateInferenceText(doubt);
	return inference;
}

function generateInferenceTitle(doubt, inferenceMode=false){
	let result = "";
	doubt.require_slots.forEach((slot, index) => {
		let piece = null;
		
		if(inferenceMode && doubt.unsettled_answer_slots) {
			piece = getPiece(doubt.unsettled_answer_slots[index]);
		}
		else {
			piece = getPiece(doubt.answer_slots[index]);
		}
		if(piece){
			result += '「{0}」'.format(piece.title);
			if(index < doubt.require_slots.length - 1){
				result += "と"
			}
		}
	});
	return '{0}'.format(result);
}

function generateInferenceText(doubt, inferenceMode = false){
	let result = '疑問の答えには';

	doubt.require_slots.forEach((slot, index) => {
		let piece = null;
		
		if(inferenceMode && doubt.unsettled_answer_slots) {
			piece = getPiece(doubt.unsettled_answer_slots[index]);
		}
		else {
			piece = getPiece(doubt.answer_slots[index]);
		}
		
		if(piece){
			result += '「{0}」'.format(piece.getTagStr(slot));
			if(index < doubt.require_slots.length - 1){
				result += "と"
			}
		}
	});
	result += "が関係しているはずだ。";
	return result;
}

function getDetectiveConvinceValue(){
	let dict = getDetectiveSetting("CONVINCE_VALUES");
	Object.keys(dict).forEach(function(key, index) {
	  dict[key] = Number(dict[key]);
	});
	return dict;
}

function getDetectiveConvinceMathValue(){
	let dict = getDetectiveSetting("DEFAULT_CONVINCE_VALUE");
	return dict.match;
}

function getDetectiveConvinceNoMathValue(){
	let dict = getDetectiveSetting("DEFAULT_CONVINCE_VALUE");
	return dict.nomatch;
}

function requireConvincingLevelDoubt(){
	let dict = getDetectiveSetting("DEFAULT_CONVINCE_VALUE");
	return dict.require;
}

function getConvinceValue(){
	
	return getDetectiveConvinceValue();
}

function getConvinceLevelValue(){
	return Object.values(getDetectiveConvinceValue());
}
function getConvinceLevelDef(){
	return Object.keys(getDetectiveConvinceValue());
}

function compareConvinceLevelStr(left, right){
	let left_index = 0;
	let right_index = 0;
	const len = getConvinceLevelDef().length - 1;
	getConvinceLevelDef().forEach((val, index) => {
		if(val == left){ left_index = (len - index); }
		if(val == right){ right_index = (len - index); }
	});

	return left_index >= right_index;
}

function calcConvinceLevel(doubt, inferenceMode = false){





    const result_good = "A";
    const result_not_bad = "B-";
    const result_bad = "C-";
	if(!doubt.isAnswerFull(inferenceMode)){
		return result_bad;
	}

    
    const count = doubt.answer_slots.length;
    let correct_count = 0;
    const correct_value = getDetectiveConvinceMathValue();
    const answer_pieces = doubt.getAnswerPieces(inferenceMode);
    answer_pieces.forEach((piece_id, index) => {
        const result = getPieceConvincing(doubt.id, index, piece_id, answer_pieces.slice(0, index));
        if(result == correct_value){
            correct_count +=  1;
        }
    });

    if(count == correct_count){
        return result_good;
    }else if(correct_count > 0){
        return result_not_bad;
    } 
    return result_bad;
}

function calcConvinceLevelOld(doubt, inferenceMode = false){
	
	if(!doubt.isAnswerFull(inferenceMode)){
		return "C-";
	}






	const convince_level = getConvinceValue();




	const convince_table = 	getConvinceLevelValue();
	const convince_table_def = getConvinceLevelDef();

	
	const max_rate = 100;
	let rate = 0;
	let value = 0;
	const id = doubt.id;
	doubt.getAnswerPieces(inferenceMode).forEach((piece_id, index) => {
		rate += max_rate;
		value += convince_level[calcConvinceLevelWithDoubtSlotImpl(id, index, piece_id)];
	});

	
	let ratio = (value / rate) * max_rate;

	const len = convince_table.length;
	let index = 0;
	let result = convince_table[index];
	while(index < len){
		if(result <= ratio){
			break;
		}
		index += 1;
		result = convince_table[index];
	}
	return convince_table_def[index];
}

function calcConvinceLevelWithDoubtSlotImpl(doubt_id, slot_index, piece_id){
	const convince_level = getConvinceLevelDef();
	let result = convince_level[convince_level.length - 1];

	
	let tmp = getPieceConvincing(doubt_id, slot_index, piece_id);
	if(tmp){
		return tmp;
	}

	return result;
}

function initVote(){
	
	TYRANO.kag.stat.f.vote_for = {};
    delete TYRANO.kag.stat.f.max_voted_chara_id;
	Object.keys(getNpcList()).forEach(key => TYRANO.kag.stat.f.vote_for[key] = 0);
	TYRANO.kag.stat.f.vote_for[getPlayer().id] = 0;
    TYRANO.kag.stat.f.player_voted_id = "";
    delete TYRANO.kag.stat.f.vote_result;
    TYRANO.kag.stat.f.max_voted_count = 0;
    TYRANO.kag.stat.f.criminal_npc = "";
    TYRANO.kag.stat.f.vote_result_file = "";
}

function voteFor(chara_id){
	if(!TYRANO.kag.stat.f.vote_for[chara_id]){
		TYRANO.kag.stat.f.vote_for[chara_id] = 0;
	}
	TYRANO.kag.stat.f.vote_for[chara_id] += 1;
}

function getCostImpl(key, credit_level){
    return getDetectiveSetting(key).val.split('|')[credit_level];
}

function getSecretCost(credit_level){
	return getCostImpl('CONSUME_COST_SECRET', credit_level);
}

function getAskCost(credit_level){
	return getCostImpl('CONSUME_COST_ASK', credit_level);
}

function getListenCost(credit_level){
	return getCostImpl('CONSUME_COST_LISTEN', credit_level);
}

function getInferenceCost(credit_level){
	return getCostImpl('CONSUME_COST_INFERENCE', credit_level);
}

function getShowInferenceCost(credit_level){
	return getCostImpl('CONSUME_COST_SHOW_INFERENCE', credit_level);
}

function replaceTag(str){
	return str.replace(/\[r\]/g, "<br>");
}


function getPlayer(){
	return TYRANO.kag.stat.f.player;
}

function sort_num_block(a, b) {
    const sa = String(a).replace(/(\d+)/g, m => m.padStart(5, '0'));
    const sb = String(b).replace(/(\d+)/g, m => m.padStart(5, '0'));
    return sa < sb ? -1 : sa > sb ? 1 : 0;
}

function getCreditPointDoubt(doubt, level){
	return Number(getDetectiveSetting("DOUBT_CREDIT_POINT")[level]);
}

function calcGetCreditPointDoubt(doubt, addPoint){
	if(addPoint == 0){ return addPoint; }

	const tmp = doubt.last_credit_point + addPoint;
	if(addPoint < 0){
		if(tmp <= doubt.min_credit_point){
			addPoint = doubt.min_credit_point - doubt.last_credit_point;
		}
	}else{
		if(tmp >= this.max_credit_point){
			addPoint = doubt.max_credit_point - doubt.last_credit_point;
		}
	}

	doubt.last_credit_point = doubt.last_credit_point + addPoint;
	return addPoint;
}




var _safty_check_p = "";
function p_lex(p) {
  _safty_check_p = p;
  p = p.replace(/(\(|\)|\[|\]|\{|\}|\"|\,)/g, ' $1 ');
  return p.split(/\s+/).filter(x => x != '');
}

p_syn_rp = {'(':')','{':'}','[':']','"':'"'};
function p_syn(p) {
  var t = p.shift();
  let _safty_count = 0;
  if (['(','{','[','"'].includes(t)) {
    var r = [];
    while (p[0] != p_syn_rp[t]) {
      r = r.concat([p_syn(p)]);
      _safty_count += 1;
      if(_safty_count >= 10000){
          alert("Condition 構文に誤りがあります : " + _safty_check_p);
		  return "";
      }
    }
    p.shift();
    return r;
  } else {
    return t;
  }
}

function isCreditLevel(str){
	const result = str.split('.');
	return getCharacter(result[0]).credit_level == Number(result[1]);
}

function underCreditLevel(str){
	const result = str.split('.');
	return getCharacter(result[0]).credit_level < Number(result[1]);
}

function isFlag(str){
	const result = str.split('.');
	if(TYRANO.kag.stat.f[result[0]] == null) { return false; }
	if(result.length == 3){
		
		const op = result[1];
		if(op == "gte"){ return Number(TYRANO.kag.stat.f[result[0]]) >= Number(result[2]); }
		return false;
	}else{
		return TYRANO.kag.stat.f[result[0]].toString() == result[1];
	}
}

function isNotFlag(str){
	const result = str.split('.');
	if(TYRANO.kag.stat.f[result[0]] == null) { return false; }
	return !(isFlag(str));
}



function checkOneConditions(conditions, begin_idx){
	const func = getCondFunction(conditions[begin_idx]);
	const args = conditions[begin_idx + 1];
	let result = true;
	if(args && args.length > 0){
		args.forEach((arg, index) => {
			if(!func(arg)){
				result = false;
			}
		});
	}else{
		if(!func()){
			result = false;
		}
	}
	return result;
}

function parseConditions(str){
	let result = p_syn(p_lex(str));
	if(result.length == 0){
		alert("フォーマットエラー：" + str);
		return false;
	}
	return result;
}







function checkConditions(conditions){
	let result = false;
	let index = 0;
	let expression = null;
	while(index < conditions.length){
		if(typeof(conditions[index]) == "object"){
			
			const condition = conditions[index];
			const tmp = checkConditions(condition);
			if(expression == null){
				result = tmp;
			}else{
				if(expression == "or"){
					result = result || tmp;
				}else if(expression == "and"){
					result = result && tmp;
				}
			}
			expression = null;
		}else{
			const isFunc = getCondFunction(conditions[index]);
			if(isFunc){
				const tmp = checkOneConditions(conditions, index);
				++ index;	
				if(expression == null){
					result = tmp;
				}else{
					if(expression == "or"){
						result = result || tmp;
					}else if(expression == "and"){
						result = result && tmp;
					}
				}
				expression = null;
			}else{
				expression = conditions[index];
			}
		}
		++ index;
	}
	return result;
}

function checkDoubtCondtions(cond_str){
	if(!cond_str){ return true; }
	
	let coditions = p_syn(p_lex(cond_str));

	return checkConditions(coditions);
}

function checkConditionsStr(cond_str){
	if(!cond_str){ return true; }
	
	let coditions = p_syn(p_lex(cond_str));
	return checkConditions(coditions);
}

function clearNpcName(){
	TYRANO.kag.stat.f.npc = "";
	TYRANO.kag.stat.f.npc_sysname = "";
	TYRANO.kag.stat.f.npc_nickname = "";
}

function setNpcName(npc){
    if(!npc || npc == void 0){
        return ;
    }
	TYRANO.kag.stat.f.npc = npc.name;
	TYRANO.kag.stat.f.npc_sysname = npc.sysname;
	TYRANO.kag.stat.f.npc_nickname = npc.nickname;
	TYRANO.kag.variable.tf.names.NPC = TYRANO.kag.variable.tf.names[npc.name_id];
	
	Object.keys(TYRANO.kag.variable.tf.names).forEach((name_id) => {
		TYRANO.kag.variable.tf.names[name_id]["NPC"] = TYRANO.kag.variable.tf.names[name_id][npc.id];
	});

}

function getBgm(condition_key){
	const data = getCommonCondition(condition_key);
	if(data){
		return data.value.BGM;
	}
	return "";
}

function secretBgm(npc_key){
	let bgm = getCharacter(npc_key).getSecretBgm();
	if(bgm == ""){
		bgm = getBgm("BGM_IN_SECRET");
	}
	return bgm;
}

function selectTalkBgm(){
	return getBgm("BGM_IN_SELECT_TALK");
}

function debateBgm(){
	return getBgm("BGM_IN_DEBATE");
}

function voteBgm(){
	return getBgm("BGM_IN_VOTE");
}

function voteContinue(){
	return getBgm("BGM_IN_CONTINUE");
}


function autoArrangePosition(conversastions){
    
    
    const last_index = conversastions.length - 1;
    let begin_pos = 0; 
    let before_talker = "";
    if(conversastions[0].type == "debate"){
        const tmp = mist_system.DetectiveManager.getLastTalkInfo();
        begin_pos = tmp.pos_index;
        before_talker = tmp.chara_id;
    }
    let position_map = [];
    let specifid_position_map = {};
	let current_pos = begin_pos;
	conversastions.forEach((data,index) => {
        if(data.talker == "system") { return ; }
        if(before_talker != data.talker){
            current_pos = (current_pos + 1) % 2;
        }
        before_talker = data.talker;
        
        if(data.talker == "itsuki"){
            current_pos = 2;
        }else{
            if(index == last_index && data.type == "debate"){
                current_pos = data.position == "left" ? 2 : 3;
            }
        }
        if(data.position != ""){
            current_pos = data.position == "left" ? 4 : 5;
        }
        if(current_pos > 1){ specifid_position_map[index] = current_pos; }

        conversastions[index].position = (current_pos % 2) == 0 ? "left" : "right"
    });


    let before_index = -1;
    for (const [index, pos_val] of Object.entries(specifid_position_map)) {
        conversastions[index].position = (pos_val % 2) == 0 ? "left" : "right"
        
        let current_talker = conversastions[index].talker;
        let current_pos_val = pos_val;
        for(let i = index - 1; i > before_index; i --){
            if(conversastions[i].talker == "system"){ continue; }
            if(conversastions[i].talker == current_talker){
                
            }else{
                
                current_pos_val += 1;
                current_talker = conversastions[i].talker;
            }
            conversastions[i].position = (current_pos_val % 2) == 0 ? "left" : "right"
        }
        before_index = index;
    }

    return conversastions;

}



function nextConversation(topic_id, type){
	let conversastions = getConversation(topic_id);
	if(!conversastions){ return false; }
	
	let flag = TYRANO.kag.stat.f.conversations_flag || [];
	let conversationTopic = conversastions.filter(c => c.type == type && checkConditionsStr(c.condition));
	let array = conversationTopic.filter(c => c.react_to_talk_id == 0);
	if (array.length === 0) {
		return false;
	}

	let conversation = array[0];
	let result = [];
	result.push(conversation);
	
	let talk_id = Number(conversation.talk_id);
	while(talk_id){
		let tmp = conversationTopic.filter(c => {
			const tmp = c.react_to_talk_id.split(',');
  			for (let i = 0; i < tmp.length; i ++) {
				if(Number(tmp[i]) == talk_id){ return true; }
			}
			return false;
		});
		if (tmp.length === 0) {
			talk_id = 0;
			break;
		}
		result.push(tmp[0]);
		talk_id = Number(tmp[0].talk_id);
	}

    
	autoArrangePosition(result);

	return result;
}


function helpMessage(phase){
	const result = getCommonHelp(phase);
	ret = result.find(help => checkConditionsStr(help.condition));
	return ret;
}

function guidanceMessage(phase){
	let result = getGuidance(phase);
	return result.find(guidance => checkConditionsStr(guidance.condition));
}

function guidanceConversation(phase){
	let result = getGuidance(phase);
	if(!result) { return null;}
	let ret = result.find(guidance => checkConditionsStr(guidance.condition));
	if(!ret) { return null;}
	return Object.assign(new Conversation(), {face: ret.face, talker:"itsuki",text:ret.text, type:"secret"}); 
}

function getCommonCondition(name){
	let result = null;
	let data = getCommonConditionChapter(name);
	if(data){
		result = data.find(cond => checkConditionsStr(cond.condition));
	}
	if(!result){
		data = getDetectiveCommonCondition(name);
		if(data){
			result = data.find(cond => checkConditionsStr(cond.condition));
		}
	}
	return result;
}


function checkCommonCondition(condition_name){
	const result = getCommonCondition(condition_name);
	if(!result){ return false; }

	return checkConditionsStr(result.condition);
}



function getCommonConditionConversation(condition_name){
	const result = getCommonCondition(condition_name);
	if(!result){ return null; }
	const data = result.value;
	if(!data || data.ref != Conversation.name){ return null; }
	return nextConversation(data.topic_id, data.type);
}

function getApproachData(timing){


	if(!approach_condition_timing_dict[timing]) { return null; }
	let approach_list = approach_condition_timing_dict[timing].filter(approach => !alreadyHappenedApproach(approach.id));

	let candidates = approach_list.filter(approach => checkConditionsStr(approach.condition));
	if(!candidates || candidates.length == 0){ return null; }
	
	candidates.sort((first, second) => second.priority - first.priority);
	return candidates[0];
}

function needEndSecretMode(){
	
	return !haveCost();
}

function isLastAction(dummy){
	
	let credit_level = 0;
	if(TYRANO.kag.stat.f.npc_key){
		credit_level = getCharacter(TYRANO.kag.stat.f.npc_key).credit_level;
	}
	const costTargets = [getSecretCost, getAskCost, getListenCost, getInferenceCost, getShowInferenceCost];
	const costs = costTargets.map(f => f(credit_level));
	const min_cost = costs.reduce((a,b)=>a<b?a:b);
	return !canActConsumeAfter(min_cost);
}

function isLastActionCreateInference(){
	const cost = getInferenceCost(0);
	return isModeInvestigation() && !canActConsumeAfter(cost)
}

function isLastActionAsk(){
	let credit_level = 0;
	if(TYRANO.kag.stat.f.npc_key){
		credit_level = getCharacter(TYRANO.kag.stat.f.npc_key).credit_level;
	}
	const cost = getAskCost(credit_level);
	return !canActConsumeAfter(cost)
}

function notCompleteDoubtCount(npc_key){
	
	const doubts = getOwnerDoubts(npc_key);
	return doubts.map(d => d.result).filter(r => r == false).length;
}


function setModeInvestigation(){
	TYRANO.kag.stat.f.detective_phase = "investigate";
}

function isModeInvestigation(){
	return TYRANO.kag.stat.f.detective_phase == "investigate";
}

function setModeDebate(){
	TYRANO.kag.stat.f.detective_phase = "debate";
}

function isModeDebate(){
	return TYRANO.kag.stat.f.detective_phase == "debate";
}

function setModeVote(){
	TYRANO.kag.stat.f.detective_phase = "vote";
}

function isModeVote(){
	return TYRANO.kag.stat.f.detective_phase == "vote";
}


function getDetectiveSetting(name){
	let result = null;
	let data = getDetectiveCommonSetting(name);
	if(data){
		if(checkConditionsStr(data.condition)){
			result = data.value;
		}
	}
	return result;
}


function getInferenceCommonIconPath(){
	return getDetectiveCommonSetting("INFERENCE_COMMON_ICON").value.path;
}

function getTimeWarning(before_time, consume_time){
	const data = getCommonCondition('time_warning');
	if(!data){ return null;}
	const warnings = Object.keys(data.value);
	const result = warnings.filter(t => (before_time > Number(t) && Number(t) >= (before_time - consume_time)) ? true : false);
	if(result && result.length > 0){
		TYRANO.kag.stat.f.TimeWarning = Math.min(...result.filter(n => Number(n)));
	}
}


function setDisableUIInfo(){
    TYRANO.kag.stat.f.disable_ui_info = true;
}
function setEnableUIInfo(){
    TYRANO.kag.stat.f.disable_ui_info = false;
}
function isEnableUIInfo(){
    const flag_f = TYRANO.kag.stat.f;
    
    return (flag_f.detective_phase == "investigate") && (flag_f.disable_ui_info == void 0 || flag_f.disable_ui_info == false)

}

function getPlayerInferenceIcon(){
	const dict = getDetectiveSetting("INFERENCE_COMMON_ICON");
    return dict["path"];
}

function getPersonInfo(group, year){
    const result =  masterdata.note_person[group].filter(p => p.year == year);
    if(result.length > 0) {  return result[0]; }
    return "";
}


function initApproachData(){
    TYRANO.kag.stat.f.approach_data = null;
    TYRANO.kag.stat.f.approach_script = "";
    TYRANO.kag.stat.f.end_approach = "";
    TYRANO.kag.stat.f.is_approaching = false;
}

function initDebateData(){
    delete TYRANO.kag.stat.f.suspect_chara;
    delete TYRANO.kag.stat.f.debate_topic;
}

function initializeSystemData(){
    TYRANO.kag.stat.current_save_str = "";
    TYRANO.kag.stat.f.backlog = [];
}


