

tyrano.plugin.kag.layer.showFixLayer = function () {
    const fixLayers = $(".fixlayer");
    const count = fixLayers.length;
    for(let i = 0; i < count; ++i) {
        const fixLayer = fixLayers.eq(i);
        const visible = fixLayer.attr("l_visible");
        if(visible === undefined || visible == "true") {
            fixLayer.show();
        }
    }
}


tyrano.plugin.kag.layer.hideMessageLayers = function () {
    
    if (this.kag.stat.display_link == true) {
        return false;
    }

    this.kag.stat.is_hide_message = true;

    
    this.kag.trigger("messagewindow-hide");

    var num_message_layer = parseInt(this.kag.config.numMessageLayers);

    for (var i = 0; i < num_message_layer; i++) {
        const layer = this.getLayer("message" + i);
        const ignoreVisibleControll = layer.attr("ignore_visble");
        
        if(ignoreVisibleControll !== "true") {
            layer.hide();
        }
    }

    
    this.hideFixLayer();
}


tyrano.plugin.kag.layer.showEventLayer = function (type) {
    this.layer_event.show();
    if(!mist_system || !mist_system.FooterContainer || !mist_system.FooterContainer.deactive){ return ; }
    mist_system.FooterContainer.active();
}


tyrano.plugin.kag.layer.hideEventLayer = function () {
    this.layer_event.hide();
    if(!mist_system || !mist_system.FooterContainer || !mist_system.FooterContainer.deactive){ return ; }
    mist_system.FooterContainer.deactive();
}
