


tyrano.plugin.kag.menu.showMenu = function (focus_index = 0, call_back = undefined) {
    if (
        this.kag.layer.layer_event.css("display") == "none" &&
        this.kag.stat.is_strong_stop != true
    ) {
        return false;
    }

    
    if (this.kag.stat.is_wait == true) {
        return false;
    }

    this.kag.setSkip(false, {}, true);
    var that = this;

    this.kag.stat.is_auto_wait = false;

    var layer_menu = this.kag.layer.getMenuLayer();

    layer_menu.empty();

    var button_clicked = false;

    this.kag.html(
        "menu",
        {
            novel: $.novel,
        },
        function (html_str) {
            var j_menu = $(html_str);

            
            TYRANO.kag.variable.tf.is_return_menu = true;

            
            mist_system.FooterContainer.mark();

            const close_event = function(e){
                mist_temp.menuFocusManager.unregisterFocus();
                layer_menu.hide();
                layer_menu.empty();
                TYRANO.kag.variable.tf.is_return_menu = false;
                mist_system.FooterContainer.markBack();
                if (that.kag.stat.visible_menu_button == true) {
                    $(".button_menu").show();
                }
                e.stopPropagation();
                
                mist_system.FooterContainer.active(true);

            };

            const footer_display_data = {
                is_visible_close_button_q_key:true,
                close_event_q_key:close_event,
                help_text:getCommonHelpDirect("menu")
            };
            mist_system.FooterContainer.showMenuFooter(footer_display_data);

            layer_menu.append(j_menu);

            layer_menu.find(".menu_close").click(function (e) {
                if (mist_temp.is_tutorial) return;

                layer_menu.hide();
                mist_system.FooterContainer.back();
                if (that.kag.stat.visible_menu_button == true) {
                    $(".button_menu").show();
                }

                e.stopPropagation();
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys09.mp3", stop: true });
                
                mist_system.FooterContainer.active(true);
            });

            layer_menu.find(".menu_window_close").click(function (e) {
                if (mist_temp.is_tutorial) return;

                
                that.kag.layer.hideMessageLayers();

                layer_menu.hide();
                if (that.kag.stat.visible_menu_button == true) {
                    $(".button_menu").show();
                }

                e.stopPropagation();
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
            });

            
            const click_event = function(e, target, on_action) {
                if (mist_temp.is_tutorial) return;

                
                if (button_clicked == true) {
                    return;
                }
                button_clicked = true;
                Common.setBlock(true);
                e.stopPropagation();
                mist_temp.menuFocusManager.unregisterFocus();

                const cursor_elem = target.find("select-cursor");
                Common.setVisible(cursor_elem, true);
                const line_elem = target.find("select-line");
                Common.setVisible(line_elem, true);
                
                setTimeout(() => {
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                    Common.setBlock(false);
                    Common.setVisible(cursor_elem, false);
                    Common.setVisible(line_elem, false);
                    on_action();
                }, Common.durationSelected());
            };
            
            
            const menu_save = layer_menu.find(".menu_save");
            menu_save.click(function (e) {
                click_event(e, menu_save, () => that.displaySave());
            });
            
            const menu_load = layer_menu.find(".menu_load");
            menu_load.click(function (e) {
                click_event(e, menu_load, () => that.displayLoad());
            });
            
            const menu_config = $(".menu_config");
            menu_config.click(function (e) {
                click_event(e, menu_config, () => displayOption(true, undefined));
            });
            
            const menu_help = layer_menu.find(".menu_help");
            menu_help.click(function (e) {
                click_event(e, menu_help, () => that.displayHelp());
            });
            
            const menu_back_title = layer_menu.find(".menu_back_title");
            menu_back_title.click(function (e) {
                click_event(e, menu_back_title, () => that.displayBackTitle());
            });
            
            const close_menu = layer_menu.find(".close_menu");
            close_menu.click(function (e) {
                click_event(e, close_menu, () => close_event(e));
            });

            
            layer_menu.find(".menu_full_screen").click(function (e) {
                if (mist_temp.is_tutorial) return;

                that.screenFull();
                e.stopPropagation();
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            });
            

            $.preloadImgCallback(
                j_menu,
                function () {
                    layer_menu.stop(true, true).fadeIn(300);
                    $(".button_menu").hide();
                },
                that,
            );

            
            mist_temp.menuFocusManager = new FocusManager("menu", [
                menu_save,		    
                menu_load,		    
                menu_config,	    
                menu_help,	        
                menu_back_title,	
                close_menu,			
            ],
            [
                [5, 1],		
                [0, 2],		
                [1, 3],		
                [2, 4],		
                [3, 5],		
                [4, 0],		
            ],
            focus_index,
            );
        },
    );
};

tyrano.plugin.kag.menu.hideMenu = function() {
    mist_temp.menuFocusManager.unregisterFocus();
    const layer_menu = TYRANO.kag.layer.getMenuLayer();
    layer_menu.hide();
    layer_menu.empty();
    TYRANO.kag.variable.tf.is_return_menu = false;
    mist_system.FooterContainer.markBack();
    if (TYRANO.kag.stat.visible_menu_button == true) {
        $(".button_menu").show();
    }
    
    mist_system.FooterContainer.active(true);

}


tyrano.plugin.kag.menu.displayHelp = function (call_back) {
    var that = this;
    const help = masterdata.help;
    this.kag.html(
        "help",
        {
            help: help,
            novel: $.novel,
        },
        function (html_str) {
            
            if(!mist_system.FooterContainer.isMarking()){
                mist_system.FooterContainer.mark();
            }

            var j_save = $(html_str);
            const set_footer = function(){
                let layer_menu = that.kag.layer.getMenuLayer();
                
                const footer_display_data = {
                    is_visible_close_button_q_key:true,
                    close_event_q_key:function(e){
                        TYRANO.kag.variable.sf.HelpView.close();

                        const container = $(".help-container");
                        container.remove();
                        if (typeof callback == "function") {
                            callback();
                        }
                        if(TYRANO.kag.variable.tf.is_return_menu){
                            TYRANO.kag.menu.showMenu(3);
                        }else{
                            mist_temp.menuFocusManager.unregisterFocus();
                            layer_menu.empty();
                            layer_menu.hide();
                            
                            mist_system.FooterContainer.markBack();
                        }

                        if (that.kag.stat.visible_menu_button == true) {
                            $(".button_menu").show();
                        }
                        e.stopPropagation();
                    },
                    help_text:getCommonHelpDirect("help_scene")
                };
                mist_system.FooterContainer.showMenuFooter(footer_display_data);
            }
            set_footer();
            
            that.setMenu(j_save, call_back);
            TYRANO.kag.variable.sf.HelpView.create(set_footer);
        },
    );
};


tyrano.plugin.kag.menu.displayBackTitle = function (call_back) {
    var that = this;
    this.kag.html(
        "back_title",
        {},
        function (html_str) {
            let layer_menu = that.kag.layer.getMenuLayer();
            
            if(!mist_system.FooterContainer.isMarking()){
                mist_system.FooterContainer.mark();
            }
            const elem = $(html_str);
            const button_yes_elem = elem.find(".menu_buttons_grid_yes");
            const button_no_elem = elem.find(".menu_buttons_grid_no");
            initMenuCursorLineButton(button_yes_elem);
            initMenuCursorLineButton(button_no_elem);
            
            that.setMenu(elem, call_back);
            
            mist_system.FooterContainer.hide(false);
            const back_title = $(".back_title");
            const menu_cancel = $(".menu_cancel");
            menu_cancel.click(() => {
                if (mist_temp.is_tutorial) return;

				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                Common.setVisible(menu_cancel.find("cursor"), true);
                menu_cancel.off();
                back_title.off();
                setTimeout(function(){
                    const container = $("back-title-window");
                    container.remove();
                    if (typeof callback == "function") {
                        callback();
                    }
                    if(TYRANO.kag.variable.tf.is_return_menu){
                        TYRANO.kag.menu.showMenu(4);
                    }else{
                        mist_temp.menuFocusManager.unregisterFocus();
                        layer_menu.empty();
                        layer_menu.hide();
                        
                        mist_system.FooterContainer.markBack();
                    }
                }, Common.durationSelected());
            });
            back_title.click((e) => {
                if (mist_temp.is_tutorial) return;

                TYRANO.kag.variable.tf.is_return_menu = false;
                
				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                Common.setVisible(back_title.find("cursor"), true);
                back_title.off();
                menu_cancel.off();
                const container = $("back-title-window");
                Common.blackout(0);
                container.fadeOut(300, () => {
                    container.remove();
                    if (typeof callback == "function") {
                        callback();
                    }



                    
                    mist_system.FooterContainer.markBack();
                    });
                setTimeout(function(){
                    e.stopPropagation();
                    TYRANO.kag.ftag.startTag("jump", {storage: "detective/transition/return_title.ks"});
                }, 300+Common.durationSelected());
            });
        	Common.setFocus(menu_cancel);
        },
    );
}


tyrano.plugin.kag.menu.displaySaveDeleteConfirm = function (num, on_exit) {
    mist_temp.is_display_save_delete = true;
    const that = this;
    this.kag.html(
        "save_delete",
        {},
        (html_str) => {
            const elem = $(html_str);
            const button_yes_elem = elem.find(".menu_buttons_grid_yes");
            const button_no_elem = elem.find(".menu_buttons_grid_no");
            initMenuCursorLineButton(button_yes_elem);
            initMenuCursorLineButton(button_no_elem);
            const current_save_elem = elem.find("save-data");

            let layer_menu = that.kag.layer.getMenuLayer();
            layer_menu.append(elem);
            
            const save_item = elem.find(".save");
            const cancel_item = elem.find(".cancel");
            save_item.click(() => {
                if (mist_temp.is_tutorial) return;

                Common.setVisible($(save_item).find("cursor"), true);
                save_item.off();
                cancel_item.off();
                setTimeout(function(){
                    const num = current_save_elem.attr("data-num");
                    const slot = $("save-window").find(`item[data-num="${num}"]`);
                    that.deleteSaveSlot(slot, () => {
                        mist_temp.is_display_save_delete = false;
                        Common.applyCacheSaveData();
                        if (typeof on_exit == "function") {
                            on_exit(true);
                        }
                    });
                    elem.remove();
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                    mist_system.FooterContainer.show();
                }, Common.durationSelected());
            });
            cancel_item.click(() => {
                if (mist_temp.is_tutorial) return;

                Common.setVisible($(cancel_item).find("cursor"), true);
                save_item.off();
                cancel_item.off();
                setTimeout(function(){
                    mist_temp.is_display_save_delete = false;
                    elem.remove();
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                    mist_system.FooterContainer.show();
                    if (typeof on_exit == "function") {
                        on_exit(false);
                    }
                }, Common.durationSelected());
            });
            mist_system.FooterContainer.hide();

            current_save_elem.attr("data-num", num);
            that.updateSaveSlot(current_save_elem);

            
            Common.setFocus(cancel_item);
        },
    );
}


tyrano.plugin.kag.menu.displaySaveConfirm = function (num, on_exit) {
    const that = this;
    this.kag.html(
        "save_confirm",
        {},
        (html_str) => {
            const elem = $(html_str);
            const button_yes_elem = elem.find(".menu_buttons_grid_yes");
            const button_no_elem = elem.find(".menu_buttons_grid_no");
            initMenuCursorLineButton(button_yes_elem);
            initMenuCursorLineButton(button_no_elem);

            that.snapSave(this.kag.stat.current_save_str, () => {
                
                Common.setBlock(false);
                const elem = $(html_str);
                const current_save_elem = elem.find("save-data");
                const new_save_elem = elem.find("new-save-data");

                let layer_menu = that.kag.layer.getMenuLayer();
                layer_menu.append(elem);

                const save_item = elem.find(".save");
                const cancel_item = elem.find(".cancel");
    
                
                save_item.click(() => {
                    if (mist_temp.is_tutorial) return;

                    Common.setVisible($(save_item).find("cursor"), true);
                    save_item.off();
                    cancel_item.off();

                    setTimeout(function(){
                        const num = current_save_elem.attr("data-num");
                        const slot = $("save-window").find(`item[data-num="${num}"]`);
                        elem.remove();
                        that.saveSlot(slot, () => {
                            Common.applyCacheSaveData();
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys03.mp3", stop: true });
                            mist_system.FooterContainer.show(false);
                            if (typeof on_exit == "function") {
                                on_exit();
                            }
                        });
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                    }, Common.durationSelected());
                });
                
                cancel_item.click(() => {
                    if (mist_temp.is_tutorial) return;

                    Common.setVisible($(cancel_item).find("cursor"), true);
                    save_item.off();
                    cancel_item.off();

                    setTimeout(function(){
                        elem.remove();
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                        mist_system.FooterContainer.show(false);
                        if (typeof on_exit == "function") {
                            on_exit();
                        }
                    }, Common.durationSelected());
                });
                mist_system.FooterContainer.hide(false);

                current_save_elem.attr("data-num", num);
                new_save_elem.attr("data-num", num);
                that.updateSaveSlot(current_save_elem);
                that.updateSaveSlot(new_save_elem, that.snap);

                
                Common.setFocus(save_item);
            }, "false");
        },
    );
}

function initMenuCursorLineButton(elem){
    setVisibleMenuLineCursor(elem, false);                
    elem.hover(() => {
        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
        setVisibleMenuLineCursor(elem, true);  
    },
    () => {
        setVisibleMenuLineCursor(elem, false);  
    });
    Common.makeFocusable(elem);
}
function setVisibleMenuLineCursor(elem, is_visible){
    const line_elem = elem.find("line");
    const cursor_elem = elem.find("cursor");
    const text_elem = elem.find("text");
    Common.setVisible(line_elem, is_visible);
    if(is_visible){
        elem.addClass("selected");
        text_elem.addClass("selected-white-back");
    }else{
        Common.setVisible(cursor_elem, is_visible);
        elem.removeClass("selected");
        text_elem.removeClass("selected-white-back");
    }
}

tyrano.plugin.kag.menu.existSaveData = function() {
    var that = this;
    const auto_data = $.getStorage(this.kag.config.projectID + "_tyrano_auto_save", this.kag.config.configSave);
    if(auto_data) {
        return true;
    }
    let ret = false;
    Common.getSaveData().data.map((v, i) => {
        if(v !== undefined && v.save_date !== undefined && v.save_date.length > 0) {
            ret = true;
        }
    });
    return ret;
}

tyrano.plugin.kag.menu.displaySave = function (callback) {
    

    var that = this;

    that.kag.unfocus();
    this.kag.setSkip(false, {}, true);
    mist_temp.save_slot_target = undefined;

    
    const auto_data = $.getStorage(this.kag.config.projectID + "_tyrano_auto_save", this.kag.config.configSave);
    const auto_save = auto_data ? JSON.parse(auto_data) : undefined;
    const auto_image = auto_save ? auto_save.img_data : undefined;
    const auto_date = auto_save ? auto_save.save_date : undefined;
    const auto_title = auto_save ? auto_save.title : $.lang("not_saved");

    var layer_menu = that.kag.layer.getMenuLayer();

    Common.checkAndCreateSaveLock();

    
    let ary = [];
    let ary_rawdata = [];
    Common.getSaveData().data.forEach((x, i) => {
        ary_rawdata.push(x);
        ary.push({
            num: i,
            title: x.title,
            img_data: x.img_data,
            save_date: x.save_date,
            index: Common.zeroPadding(i + 1, 3),
            lock: mist_system.save_lock[i] ? "" : "unlock",
            trash: mist_system.save_lock[i] ? "off" : "on",
        });
    });

    this.kag.html(
        "save",
        {
            title: "セーブ",
            auto_image: auto_image,
            auto_title: auto_title,
            auto_date: auto_date,
            array_save: ary,
            novel: $.novel,
        },
        function (html_str) {
            
            if(!mist_system.FooterContainer.isMarking()){
                mist_system.FooterContainer.mark();
            }
            var focus_list = [];
            var focus_index_list = [];
            var j_save = $(html_str);
            const footer_display_data = {
                is_visible_close_button_q_key:true,
                close_event_q_key:function(e){
                    const container = $("save-window");
                    container.remove();
                    if (typeof callback == "function") {
                        callback();
                    }

                    mist_temp.save_slot_target = undefined;
                    mist_temp.menuFocusManager.unregisterFocus();
                    if(TYRANO.kag.variable.tf.is_return_menu){
                        TYRANO.kag.menu.showMenu(0);
                    }else{
                        
                        layer_menu.empty();
                        layer_menu.hide();
                        
                        mist_system.FooterContainer.markBack();
                    }

                    if (that.kag.stat.visible_menu_button == true) {
                        $(".button_menu").show();
                    }
                    e.stopPropagation();
                },
                help_text:getCommonHelpDirect("save")
            };
            mist_system.FooterContainer.showMenuFooter(footer_display_data);

            
            j_save.find("save-list").css("font-family", that.kag.config.userFace);
            j_save.find("icon-lock").click(function (e) {
                if (mist_temp.is_tutorial) return;

                
                e.stopPropagation();
                const item = $(this).parent().parent();
                const num = item.attr("data-num");
                const is_unlock = !mist_system.save_lock[num];
                if (is_unlock)
                {
                    
                    $(this).attr("type", "");
                    item.find("icon-trash").attr("type", "off");
                    item.find("icon-trash").off();
                    item.find("icon-trash").click(function (e) {
                        if (mist_temp.is_tutorial) return;

                        e.stopPropagation();
                    });
                    mist_system.save_lock[num] = true;
                    playSeRoundrobin("system/se_sys11.mp3", true);
                }
                else
                {
                    
                    $(this).attr("type", "unlock");
                    item.find("icon-trash").attr("type", "on");
                    item.find("icon-trash").off();
                    item.find("icon-trash").click(function (e) {
                        if (mist_temp.is_tutorial) return;
    
                        
                        e.stopPropagation();
                        if ($(this).attr("type") == "off") {
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                            return;
                        }
                        mist_temp.menuFocusManager.unregisterFocus();
                        that.displaySaveDeleteConfirm(num, () => {
                            mist_temp.menuFocusManager.registerFocus();
                            mist_temp.menuFocusManager.setLastFocus();
                        });
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                    });
                    item.find("icon-trash").hover(function (e) {
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                    },
                    (e) => {
                    });
                    mist_system.save_lock[num] = false;
                    playSeRoundrobin("system/se_sys12.mp3", true);
                }
                Common.saveSystem();
            });
            j_save.find("icon-lock").hover(function (e) {
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            },
            (e) => {
            });
            const icon_trashs = j_save.find("icon-trash");
            for(let i = 0; i < icon_trashs.length; ++i) {
                const elem = icon_trashs.eq(i);
                const item = elem.parent().parent();
                const num = item.attr("data-num");
                elem.off();
                const is_lock = mist_system.save_lock[num];
                if(is_lock) {
                    elem.click(function (e) {
                        if (mist_temp.is_tutorial) return;
                        e.stopPropagation();
                    });
                    continue;
                }
                elem.click(function (e) {
                    if (mist_temp.is_tutorial || mist_system.save_lock[num]) return;

                    
                    e.stopPropagation();
                    if ($(this).attr("type") == "off") {
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                        return;
                    }
                    mist_temp.menuFocusManager.unregisterFocus();
                    that.displaySaveDeleteConfirm(num, () => {
                        mist_temp.menuFocusManager.registerFocus();
                        mist_temp.menuFocusManager.setLastFocus();
                    });
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                });
                elem.hover(function (e) {
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                },
                (e) => {
                });
            }

            j_save.find("item").each(function () {
                const num = Number($(this).attr("data-num"));
                
                let data = undefined;
                if (num == -1) {
                    Common.setVisible($(this).find("icon-lock"), false);
                    Common.setVisible($(this).find("icon-trash"), false);
                    $(this).addClass("auto_save");
                    data = auto_save;
                    if(data === undefined) {
                        data = {
                            title: $.lang("not_saved"),
                            current_order_index: 0,
                            save_date: "",
                            img_data: "",
                            stat: {},
                        };
                    }
                }
                else {
                    data = ary_rawdata[num];
                    
                    focus_list[num] = $(this);
                }

                const chapter_name = (data.chapter) ? masterdata.chapter.find(x => x.chapter_id == data.chapter).chapter_name : "";
                const phase = (data.phase) ? `${data.phase}フェーズ` : "";
                const title = `${chapter_name} ${phase}`;
                $(this).find("save-text > title").text(title);

                const is_nodata = !data.img_data;
                $(this).removeClass("select");
                if (is_nodata) {
                    $(this).find("save-text").hide();
                    $(this).find("icon").hide();
                    $(this).find("empty").show();
                    
                    
                }
                if(data.backlog !== undefined && data.backlog.name !== undefined){
                    if(data.backlog.name.length > 0) {
                        
                        $(this).find("two_one_lines").show();
                        $(this).find("two_line").hide();
                        $(this).find("one_line_1").html(data.backlog.name);
                        $(this).find("one_line_2").html(data.backlog.texts[0]);
                    }
                    else {
                        
                        $(this).find("two_one_lines").hide();
                        $(this).find("two_line").show();
                        $(this).find("two_line_1").html(data.backlog.texts[0]);
                    }
                }
                else {
                    if(data.title == ""){
                        $(this).find("two_one_lines").hide();
                        $(this).find("two_line").hide();
                    }else{
                        
                        $(this).find("two_one_lines").hide();
                        $(this).find("two_line").show();
                        $(this).find("two_line_1").html(data.title);
                    }
                }

                if(num >= 0) {
                    $(this).hover(function(e) {
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                        const data = Common.getSaveData().data[num];
                        if (data != undefined && data["save_date"] != "") {
                            mist_temp.save_slot_target = $(this);
                        }
                        $(this).addClass("hover");
                        e.stopPropagation();
                        mist_temp.menuFocusManager.setLastIndex(num);
                    }, function(e) {
                        mist_temp.save_slot_target = undefined;
                        $(this).removeClass("hover");
                        e.stopPropagation();
                    });
                    
                    $(this).click(function() {
                        if (mist_temp.is_tutorial) return;
                        
                        const is_active = that.kag.stat.is_adding_text || that.kag.stat.is_wait;
                        
                        if (is_active) return ;

                        
                        Common.setBlock(true);

                        const element = $(this);
                        element.addClass("select");
                        element.removeClass("hover");
                        mist_temp.menuFocusManager.unregisterFocus();
                        setTimeout(() => {
                            Common.setBlock(false);
                            const num = element.attr("data-num");
                            const is_lock = mist_system.save_lock[num];
                            if (is_lock) {
                                const data = Common.getSaveData().data[num];
                                if (data == undefined || data["save_date"] == "") {
                                    
                                    mist_system.save_lock[num] = false;
                                    Common.saveSystem();
                                } else {
                                    element.removeClass("select");
                                    TYRANO.kag.variable.sf.Dialog.createTextDialogDisplayOnly(getCommonHelpDirect("save_lock"), () => {
                                        mist_temp.menuFocusManager.registerFocus();
                                        mist_temp.menuFocusManager.setLastFocus();
                                    });
                                    return;
                                }
                            }
                            that.displaySaveConfirm(num, () => {
                                mist_temp.menuFocusManager.registerFocus();
                                mist_temp.menuFocusManager.setLastFocus();
                            });
                            element.removeClass("select");
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                        }, Common.durationSelected());                        
                    }).focusable();
                }
                else {
                    $(this).css("cursor", "default");
                    $(this).addClass("unselectable");
                }
            });

            for(let i = 0; i < focus_list.length; ++i) {
                const up = (i + focus_list.length - 1) % focus_list.length;
                const down = (i + 1) % focus_list.length;
                focus_index_list[i] = [up, down];
            }
            mist_temp.menuFocusManager = new FocusManager("save", focus_list, focus_index_list);

            that.setMenuScrollEvents(j_save, { target: "area-save-list", move: 160 });

            that.setMenu(j_save, callback);
        },
    );
};


tyrano.plugin.kag.menu.saveSlot = function (elem, callback) {
    const num = elem.attr("data-num");
    this.snap = null;
    const that = this;
    Common.setBlock(true);

    
    const effects = $('video[data-video-name*="badge-movie"]');
    const hideEffects = effects.filter(function (index) {
        return effects.eq(index).css(`display`) == 'none';
    });
    this.kag.html(
        "saving",
        {},
        (html_str) => {
            const dialog = $(html_str);
            that.setMenu(dialog, function() {});
            setTimeout(
                () => {
                    that.doSave(num, (save_data) => {
                        const item = $("save-window").find(`item[data-num="${num}"]`);
                
                        
                        item.find("save-text").show();
                        item.find("icon").show();
                        item.find("empty").hide();
                
                        if (save_data["img_data"] != "") {
                            item.find("thumbnail").css("background-image", `url(${save_data["img_data"]})`);
                        }
                
                        const save_text = item.find("save-text");
                        
                        save_text.find("top > date").text(save_data.save_date);
                
                        const chapter_name = (save_data.chapter) ? masterdata.chapter.find(x => x.chapter_id == save_data.chapter).chapter_name : "";
                        const phase = (save_data.phase) ? `${save_data.phase}フェーズ` : "";
                        const title = `${chapter_name} ${phase}`;
                        
                        save_text.find("title").text(title);
                        
                        if(save_data.backlog !== undefined && save_data.backlog.name !== undefined){
                            if(save_data.backlog.name.length > 0) {
                                
                                item.find("two_one_lines").show();
                                item.find("two_line").hide();
                                item.find("one_line_1").html(save_data.backlog.name);
                                item.find("one_line_2").html(save_data.backlog.texts[0]);
                            }
                            else {
                                
                                item.find("two_one_lines").hide();
                                item.find("two_line").show();
                                item.find("two_line_1").html(save_data.backlog.texts[0]);
                            }
                        }
                        else {
                            item.find("two_one_lines").hide();
                            item.find("two_line").hide();
                        }
                
                        
                        Common.setVisible(item.find("icon-lock"), true);
                        Common.setVisible(item.find("icon-trash"), true);
                
                        if (typeof callback == "function") {
                            callback();
                        }
                        Common.clearDialogLayer();
                        Common.setBlock(false);
        
                        dialog.remove();
                        hideEffects.hide();
                    });
                },
                500
            )
        },
    );
};



tyrano.plugin.kag.menu.deleteSaveSlot = function (elem, callback) {
    const num = elem.attr("data-num");
    let array_save = Common.getSaveData();
    
    const data = {
        title: $.lang("not_saved"),
        current_order_index: 0,
        save_date: "",
        img_data: "",
        stat: {},
    };
    array_save.data[num] = data;
    
    $.setStorage(this.kag.config.projectID + "_tyrano_data", array_save, this.kag.config.configSave);

    
    const save_text = elem.find("save-text");
    save_text.hide();
    elem.find("icon").hide();
    elem.find("empty").show();

    
    elem.find("thumbnail").css("background-image", ``);
    
    save_text.find("top > date").text("");
    
    save_text.find("title").text("");
    
    save_text.find("two_one_lines").hide();
    save_text.find("two_line").hide();

    
    Common.setVisible(elem.find("icon-lock"), false);
    Common.setVisible(elem.find("icon-trash"), false);

    if (typeof callback == "function") {
        callback();
    }
};


tyrano.plugin.kag.menu.updateSaveSlot = function (elem, new_save_data = undefined) {
    const num = elem.attr("data-num");
    let save_data = new_save_data;
    if (!save_data) save_data = Common.getSaveData().data[num];

    const thumbnail_elem = elem.find(".save_list_item_thumb");
    if (thumbnail_elem.find("img").get(0)) {
        
        if (!save_data["img_data"]) {
            save_data["img_data"] = "./data/image/save_load_new/noimage.png";
        }
        thumbnail_elem.find("img").attr("src", save_data["img_data"]);
    } else {
        
        thumbnail_elem.append("<img>");
        if(save_data["img_data"]){
            
            thumbnail_elem.css("background-image", "");
            thumbnail_elem.find("img").attr("src", save_data["img_data"]);
        }
    }
    
    elem.find(".save_list_item_date").html(save_data["save_date"]);

    const chapter_name = (save_data.chapter) ? masterdata.chapter.find(x => x.chapter_id == save_data.chapter).chapter_name : "";
    const phase = (save_data["phase"]) ? `${save_data["phase"]}フェーズ` : "";
    const index = Number(num) + 1;
    const title = `${chapter_name} ${phase}`;
    
    elem.find(".save_list_item_text").text(title);


    if(!save_data["save_date"]) {
        elem.find(".save_list_item_empty").show();
        elem.find(".save_list_item_area").hide();
    }

    if(save_data.backlog !== undefined && save_data.backlog.name !== undefined){
        if(save_data.backlog.name.length > 0) {
            
            elem.find("two_one_lines").show();
            elem.find("two_line").hide();
            elem.find("one_line_1").html(save_data.backlog.name);
            elem.find("one_line_2").html(save_data.backlog.texts[0]);
        }
        else {
            
            elem.find("two_one_lines").hide();
            elem.find("two_line").show();
            elem.find("two_line_1").html(save_data.backlog.texts[0]);
        }
    }
    else {
        elem.find("two_one_lines").hide();
        elem.find("two_line").hide();
    }

    
    if(index > 0) {
        elem.find("number").text(String(index).padStart(3, '0'));
    }
    else {
        elem.find("number").text("AUTO SAVE");
    }
    
}



tyrano.plugin.kag.menu.displayGallery = function (call_back) {
    var that = this;

    
    this.kag.html("gallery", {},
        function (html_str) {
            const elem = $(html_str);
            
            that.setMenu(elem, call_back);
            const gallery = new GalleryView(call_back);
        },
    );
};


tyrano.plugin.kag.menu.displayChapter = function (call_back) {
    var that = this;

    const preload_list = [
        "data/image/chapter/new.png",
        "data/image/detective/new/badge.png",
        "data/image/detective/common/dummy.png",
        "data/image/chapter/frame.png",
        "data/image/chapter/frame_hover.png",
        "data/image/chapter/frame_select.png",
        "data/image/chapter/frame_select_hover.png",
        "data/image/chapter/frame_grayout.png",
        "data/image/chapter/scotch_tape.png",
        "data/image/chapter/nodata.png",
        "data/image/chapter/thumbnail_shadow.png",
    ];
    masterdata.chapter.forEach(x => {
        preload_list.push(x.image);
    });
    Common.preloadAll(preload_list, () => {
        const chapter = masterdata.chapter;
        const help_text = getCommonHelpDirect("chapter_scene");
        that.kag.html(
            "chapter",
            {
                chapter: chapter,
                help_text: help_text,
            },
            function (html_str) {
                const elem = $(html_str);
                
                that.setMenu(elem, call_back);
                let view = new ChapterView(chapter, elem, call_back);
            },
        );
    });
};

tyrano.plugin.kag.menu.displayCreadit = function (call_back) {
    var that = this;

    this.kag.html(
        "credit",
        {},
        function (html_str) {
            const elem = $(html_str);
            
            that.setMenu(elem, call_back);
        },
    );
};


tyrano.plugin.kag.menu.displayLog = function () {
    var that = this;
    that.kag.unfocus();
    this.kag.setSkip(false, {}, true);
    that.activeBacklog = true;
    let scrollMax = 0;

    const registerWheel = (elm_item) => {
        mist_temp.is_backlog_key_scroll = false;
        const scroll_target = $('.log_body');
        scroll_target.off();
        var timer = false;
        scroll_target.scroll(function () {
            
            
            if (!mist_temp.is_backlog_key_scroll || !that.activeBacklog) {
                return;
            }

            
            if (timer !== false){
                clearTimeout(timer);
            }
            timer = setTimeout(function(){
                mist_temp.is_backlog_key_scroll = false;
                that.focusManager.registerFocus();
                const base_rect = scroll_target[0].getBoundingClientRect();
                const center = base_rect.top + base_rect.height / 2;
                for (let i = 0; i < elm_item.length; ++i) {
                    const rect = elm_item[i].getBoundingClientRect();
                    if (center <= rect.bottom) {
                        that.focusManager.setFocusIndex(i);
                        return;
                    }
                };
            }, 50);
        });
        Common.registerWheel("BacklogView", () => {
            const scroll_target = $('.log_body');
            if (!that.activeBacklog || scroll_target.scrollTop() <= 0) {
                return true;
            }
            mist_temp.is_backlog_key_scroll = true;
            that.focusManager.unregisterFocus();
            Common.wheel(scroll_target, -100, false);
            return true;
        }, () => {
            const scroll_target = $('.log_body');
            if (!that.activeBacklog || scroll_target.scrollTop() >= scrollMax) {
                return true;
            }
            mist_temp.is_backlog_key_scroll = true;
            that.focusManager.unregisterFocus();
            Common.wheel(scroll_target, 100, false);
            return true;
        });
    }
    const unregisterWheel = () => {
        mist_temp.is_backlog_key_scroll = false;
        Common.unregisterWheel("BacklogView");
    }

    var j_save = $("<div></div>");
    this.kag.html(
        "backlog",
        {
            novel: $.novel,
        },
        function (html_str) {
            var j_menu = $(html_str);

            var layer_menu = that.kag.layer.getMenuLayer();
            layer_menu.empty();
            layer_menu.append(j_menu);

            that.setMenuScrollEvents(j_menu, { target: ".log_body", move: 120 });
            
            const footer_display_data = {
                is_visible_close_button_q_key:true,
                close_event_q_key:function(e){
                    layer_menu.fadeOut(300, () => {
                        unregisterWheel();
                        layer_menu.empty();
                        if (typeof callback == "function") {
                            callback();
                        }
                    });
                    if (that.kag.stat.visible_menu_button == true) {
                        $(".button_menu").show();
                    }
                    mist_system.FooterContainer.back();
                    e.stopPropagation();
                    that.focusManager.resetSelectFocusView();
                    that.focusManager.unregisterFocus();

                    
                    mist_system.FooterContainer.active(true);
        
                },
                help_text:getCommonHelpDirect("save")
            };
            mist_system.FooterContainer.showBackLogFooter(footer_display_data);

            
            
            j_menu.find(".log_body").on("touchmove", (e) => {
                e.stopPropagation();
            });

            const pattern = new RegExp(/\{(.+)\}/);
            let log_str = "";
            const getLogType = (x) => {
                if (x.name === "empty") {
                    return "empty";
                } else if (x.name === "") {
                    return "system";
                } 
                return "chara";
            };
            
            
            
            mist_save.backlog.forEach(x => {
                const type = getLogType(x);
                switch (type) {
                    case "empty":
                        log_str += "<empty></empty>";
                        break;
                    case "system":
                        log_str += "<log-column><name></name>";
                        break;
                    case "chara":
                        log_str += `<log-column type="${x.name}"><name>${x.name}</name><name-line></name-line>`;
                        break;
                }

                x.texts.forEach(text => {
                    
                    let new_text = "";
                    if (x.backlog_item_type != undefined) {
                        
                        new_text = text + `<icon uid="${x.backlog_item_id}" type="${x.backlog_item_type}" value="${x.backlog_item_value}" class="icon0"></icon>`;
                    } else {
                        new_text = text;
                    }
                    new_text = Common.autoBRText(new_text, 35);
                    if (x.is_monologue) {
                        log_str += `<chara-text>（${new_text}）</chara-text>`;
                    } else {
                        log_str += `<chara-text>${new_text}</chara-text>`;
                    }
                });
                if (type === "system" || type === "chara") {
                    log_str += "<select-line></select-line>";
                    log_str += "</log-column>";
                }
            });

            layer_menu.find(".log_body").html(log_str);

            layer_menu.find(".log_body").css("font-family", that.kag.config.userFace);

            const log_columns = layer_menu.find("log-column");
            for(let i = 0; i < log_columns.length; ++i) {
                const elem = log_columns.eq(i);
                Common.makeFocusable(elem);
                const icon_elem = elem.find("icon");
                const line_elem = elem.find("select-line");
                Common.setVisible(line_elem, false);
                elem.hover(
                    function (){
                        
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                        Common.setVisible(line_elem, true);
                        elem.addClass("selected");

                        if (icon_elem.length != 0) {
                            icon_elem.removeClass();
                            icon_elem.addClass("icon1");
                            
                            xClickCallback = () => {
                                xClickCallback = undefined; 
                                elem.trigger('click');
                            }
                        }
        
                    },
                    function () {
                        Common.setVisible(line_elem, false);
                        elem.removeClass("selected");
                        if (icon_elem.length != 0) {
                            icon_elem.removeClass();
                            icon_elem.addClass("icon0");
                        }

                    }
                );
                if (icon_elem.length != 0) {
                    const that_elem = elem;
                    elem.click(function() {
                        if (mist_temp.is_tutorial) return;
                        const click_event = (index) => {
                            that.focusManager.setLastIndex(index);
                            that.focusManager.setActiveFocusEvent(false);
                            that.activeBacklog = false;                            
                        }
                        const icon_close_event = () => {
                            that.focusManager.setActiveFocusEvent(true);
                            that.activeBacklog = true;                            
                        }
                        const item = icon_elem;
                        const id = item.attr("uid");
                        const type = item.attr("type");
                        const value = item.attr("value");
                        if (type == "piece") {
                            const piece = getPiece(id);
                            const color_index = getCharacter(piece.chara_id).colorIndex();
                            const lensTag = piece.detail ? "<lens></lens>" : "";
                            let tag_html = ``;
                            const tags = Object.keys(piece.tag_list);
                            tags.forEach(x => {
                                const tag_index = mist_system.NoteContainer2.getTagIndex(x);
                                tag_html += `<tag class="tag${tag_index}"></tag>`;
                            });
                            const elem = $(`
                                <div class="backlog-dialog">
                                    <backlog-piece-window>
                                        <backlog-piece-window-bg></backlog-piece-window-bg>
                                        <backlog-piece-window-content>
                                            <item-info class="color${color_index}">
                                                <title class="color${color_index}">${piece.title}</title>
                                                <text>${piece.desc}</text>
                                                <hash-tags>
                                                    ${tag_html}
                                                </hash-tags>
                                            </item-info>
                                            <item-frame class="color${color_index}">
                                                <piece style="background-image: url(./data/image/detective/icon/${piece.resource2}.png);"></piece>
                                                <hash-tags>
                                                    ${tag_html}
                                                </hash-tags>
                                                ${lensTag}
                                            </item-frame>
                                        </backlog-piece-window-content>
                                    </backlog-piece-window>
                                </div>`);
                            let layer_menu = that.kag.layer.getMenuLayer();
                            if (layer_menu.find("backlog-piece-window").length > 0) {
                                
                                return;
                            }
                            layer_menu.append(elem);
                            click_event(i);
                            const close_func = function(){
                                icon_close_event();
                                xClickCallback = undefined;
                                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                                elem.remove();
                                mist_system.FooterContainer.back();
                                
                                xClickCallback = () => {
                                    xClickCallback = undefined; 
                                    that_elem.trigger('click');
                                }
                                
                                mist_system.FooterContainer.active(true);
                            }
                            const lens_items = layer_menu.find("item-frame lens");
                            xClickCallback = () => {
                                xClickCallback = undefined;
                                lens_items.trigger('click');
                            };

                            const piece_footer_display_data = {
                                is_visible_close_button_q_key:true,
                                close_event_q_key:function(e){
                                    close_func();
                                    e.stopPropagation();
                                },
                                help_text:getCommonHelpDirect("save")
                            };
                            mist_system.FooterContainer.showBackLogFooter(piece_footer_display_data);
        
                            layer_menu.find(".backlog-dialog").click(() => {
                                if (mist_temp.is_tutorial) return;
                                if ($(".dialog").find("piece-detail-window").length <= 0) {
                                    close_func();
                                }
                            });
                            lens_items.hover(function(e) {
                                $(this).addClass("hover");
                                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                            }, function(e) {
                                $(this).removeClass("hover");
                            });
                            lens_items.click(function(e) {
                                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                                layer_menu.find(".backlog-dialog").hide();
                                mist_system.Dialog.createPieceDetailDialog(id, "", false, () => {
                                    layer_menu.find(".backlog-dialog").show();
                                    xClickCallback = () => {
                                        xClickCallback = undefined;
                                        lens_items.trigger('click');
                                    };
                                });
                            });
                                        
                        }
                        if (type == "doubt") {
                            const doubt = getDoubt(id);
                            const elem = $(`
                                <div class="dialog">
                                    <backlog-doubt-window>
                                        <backlog-doubt-window-bg></backlog-doubt-window-bg>
                                        <backlog-doubt-window-content>
                                            <content>
                                                ${ TYRANO.kag.variable.sf.NoteContainer2.getDoubtHtml(doubt)}
                                            </content>
                                        </backlog-doubt-window-content>
                                    </backlog-doubt-window>
                                </div>`);
                    
                            let layer_menu = that.kag.layer.getMenuLayer();
                            if (layer_menu.find("backlog-doubt-window").length > 0) {
                                
                                return;
                            }
                            layer_menu.append(elem);
                            layer_menu.find("backlog-doubt-window").find("item").addClass("frame-white");
                            click_event(i);
                            const close_func = function(){
                                icon_close_event();
                                xClickCallback = undefined;
                                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                                elem.remove();
                                mist_system.FooterContainer.back();

                                
                                xClickCallback = () => {
                                    xClickCallback = undefined; 
                                    that_elem.trigger('click');
                                }

                            }
                            xClickCallback = close_func;

                            const doubt_footer_display_data = {
                                is_visible_close_button_q_key:true,
                                close_event_q_key:function(e){
                                    close_func();
                                    e.stopPropagation();
                                },
                                help_text:getCommonHelpDirect("save")
                            };
                            mist_system.FooterContainer.showBackLogFooter(doubt_footer_display_data);
        
                            layer_menu.find(".dialog").click(() => {
                                if (mist_temp.is_tutorial) return;
        
                                close_func();
                            });
                        }
                        if (type == "map") {
                            const elem = $(`
                                <div class="dialog">
                                    <backlog-map-window>
                                        <backlog-map-window-bg></backlog-map-window-bg>
                                        <backlog-map-window-content>
                                            <content>
                                                ${ TYRANO.kag.variable.sf.NoteContainer2.getMapHtml(id)}
                                            </content>
                                        </backlog-map-window-content>
                                    </backlog-map-window>
                                </div>`);
                    
                            let layer_menu = that.kag.layer.getMenuLayer();
                            if (layer_menu.find("backlog-map-window").length > 0) {
                                
                                return;
                            }
                            layer_menu.append(elem);
                            click_event(i);
                            const close_func = function(){
                                icon_close_event();
                                xClickCallback = undefined;
                                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                                elem.remove();
                                mist_system.FooterContainer.back();
                                
                                xClickCallback = () => {
                                    xClickCallback = undefined; 
                                    that_elem.trigger('click');
                                }

                            }
                            xClickCallback = close_func;

                            const map_footer_display_data = {
                                is_visible_close_button_q_key:true,
                                close_event_q_key:function(e){
                                    close_func();
                                    e.stopPropagation();
                                },
                                help_text:getCommonHelpDirect("save")
                            };
                            mist_system.FooterContainer.showBackLogFooter(map_footer_display_data);
        
                            layer_menu.find(".dialog").click(() => {
                                if (mist_temp.is_tutorial) return;
        
                                close_func();
                            });
                        }
                        if (type== "person") {
                            const elem = $(`
                                <div class="dialog">
                                    <backlog-person-window>
                                        <backlog-person-window-bg></backlog-person-window-bg>
                                        <backlog-person-window-content>
                                            <content>
                                                ${ TYRANO.kag.variable.sf.NoteContainer2.personContentSingleHtml(id, value)}
                                            </content>
                                        </backlog-person-window-content>
                                    </backlog-map-window>
                                </div>`);
                    
                            let layer_menu = that.kag.layer.getMenuLayer();
                            if (layer_menu.find("backlog-person-window").length > 0) {
                                
                                return;
                            }
                            layer_menu.append(elem);
                            layer_menu.find("backlog-person-window").find("item").addClass("note");
                            click_event(i);
                            const close_func = function(){
                                icon_close_event();
                                xClickCallback = undefined;
                                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                                elem.remove();
                                mist_system.FooterContainer.back();
                                
                                xClickCallback = () => {
                                    xClickCallback = undefined; 
                                    that_elem.trigger('click');
                                }

                            }
                            xClickCallback = close_func;

                            const person_footer_display_data = {
                                is_visible_close_button_q_key:true,
                                close_event_q_key:function(e){
                                    close_func();
                                    e.stopPropagation();
                                },
                                help_text:getCommonHelpDirect("save")
                            };
                            mist_system.FooterContainer.showBackLogFooter(person_footer_display_data);
                            layer_menu.find(".dialog").click(() => {
                                if (mist_temp.is_tutorial) return;
        
                                close_func();
                            });
                        }
                        if (type== "tutorial") {
                            if (layer_menu.find("tutorial-window").length > 0) {
                                
                                return;
                            }
                            click_event(i);

                            TYRANO.kag.variable.sf.TutorialDialog.create(id, "", () => {icon_close_event();}, this, true, false, true);
                        }
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });

                    });
                }
            }
            registerWheel(log_columns);
            
            let focus_list = [];
            let focus_index_list = [];
            log_columns.each(function(index, elem){
                focus_list[index] = $(elem);
                const up = (index + log_columns.length - 1) % log_columns.length;
                const down = (index + 1) % log_columns.length;
                focus_index_list[index] = [up, down];
            });
            that.focusManager = new FocusManager("backlog", focus_list, focus_index_list, log_columns.length - 1);

            $.preloadImgCallback(
                layer_menu,
                function () {
                    layer_menu.stop(true, true).fadeIn(300);
                    
                    const log_body = layer_menu.find(".log_body");
                    log_body.scrollTop(9999999999);
                    scrollMax = log_body.scrollTop();
                },
                that,
            );

            $(".button_menu").hide();
        },
    );
};


tyrano.plugin.kag.menu.displayLoad = function (callback, showFooterSystem=true) {
    var that = this;

    this.kag.unfocus();
    this.kag.setSkip(false, {}, true);
    mist_temp.save_slot_target = undefined;

    
    const auto_data = $.getStorage(this.kag.config.projectID + "_tyrano_auto_save", this.kag.config.configSave);
    const auto_save = auto_data ? JSON.parse(auto_data) : undefined;
    const auto_image = auto_save ? auto_save.img_data : undefined;
    const auto_date = auto_save ? auto_save.save_date : undefined;
    const auto_title = auto_save ? auto_save.title : $.lang("not_saved");;

    var layer_menu = that.kag.layer.getMenuLayer();

    Common.checkAndCreateSaveLock();

    let ary = [];
    let ary_rawdata = [];
    Common.getSaveData().data.forEach((x, i) => {
        ary_rawdata.push(x);
        ary.push({
            num: i,
            title: x.title,
            img_data: x.img_data,
            save_date: x.save_date,
            index: Common.zeroPadding(i + 1, 3),
            lock: mist_system.save_lock[i] ? "" : "unlock",
            trash: mist_system.save_lock[i] ? "off" : "on",
        });
    });

    this.kag.html(
        "save",
        {
            title: "ロード",
            auto_image: auto_image,
            auto_title: auto_title,
            auto_date: auto_date,
            array_save: ary,
            novel: $.novel,
        },
        function (html_str) {
            
            if(!mist_system.FooterContainer.isMarking()){
                mist_system.FooterContainer.mark();
            }
            var j_save = $(html_str);
            const footer_display_data = {
                is_visible_close_button_q_key:true,
                close_event_q_key:function(e){
                    const container = $("save-window");
                    container.remove();
                    mist_temp.save_slot_target = undefined;
                    mist_temp.menuFocusManager.unregisterFocus();
                    
                    if (typeof callback == "function") {
                        callback();
                    }
                    if(TYRANO.kag.variable.tf.is_return_menu){
                        TYRANO.kag.menu.showMenu(1);
                    }else{
                        layer_menu.empty();
                        layer_menu.hide();
                        
                        mist_system.FooterContainer.markBack();
                    }
                    if (that.kag.stat.visible_menu_button == true) {
                        $(".button_menu").show();
                    }
                    e.stopPropagation();

                    
                    if (mist_temp.is_continue_load === true) {
                        delete mist_temp.is_continue_load;
                        mist_system.ContinueContainer.backLoad();
                    }
                },
                help_text:getCommonHelpDirect("load"),
                is_visible_system: showFooterSystem,
            };
            mist_system.FooterContainer.showMenuFooter(footer_display_data);

            j_save.find("icon-lock").click(function (e) {
                if (mist_temp.is_tutorial) return;

                
                e.stopPropagation();
                const item = $(this).parent().parent();
                const num = item.attr("data-num");
                const is_unlock = !mist_system.save_lock[num];
                if (is_unlock)
                {
                    
                    $(this).attr("type", "");
                    item.find("icon-trash").attr("type", "off");
                    item.find("icon-trash").off();
                    item.find("icon-trash").click(function (e) {
                        if (mist_temp.is_tutorial) return;

                        e.stopPropagation();
                    });
                    mist_system.save_lock[num] = true;
                    playSeRoundrobin("system/se_sys11.mp3", true);
                }
                else
                {
                    
                    $(this).attr("type", "unlock");
                    item.find("icon-trash").attr("type", "on");
                    item.find("icon-trash").off();
                    item.find("icon-trash").click(function (e) {
                        if (mist_temp.is_tutorial) return;
    
                        
                        e.stopPropagation();
                        if ($(this).attr("type") == "off") {
                            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys04.mp3", stop: true });
                            return;
                        }
                        mist_temp.menuFocusManager.unregisterFocus();
                        that.displaySaveDeleteConfirm(num, (is_delete) => {
                            if (is_delete)
                            {
                                
                                loadFocusRecreate(j_save, auto_save, mist_temp.load_num_to_index_list[num]);
                            }
                            else
                            {
                                mist_temp.menuFocusManager.registerFocus();
                                mist_temp.menuFocusManager.setLastFocus();
                            }
                        });
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                    });
                    item.find("icon-trash").hover(function (e) {
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                    },
                    (e) => {
                    });
                    mist_system.save_lock[num] = false;
                    playSeRoundrobin("system/se_sys12.mp3", true);
                }
                Common.saveSystem();
            });
            j_save.find("icon-lock").hover(function (e) {
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
            },
            (e) => {
            });
            const icon_trashs = j_save.find("icon-trash");
            for(let i = 0; i < icon_trashs.length; ++i) {
                const elem = icon_trashs.eq(i);
                const item = elem.parent().parent();
                const num = item.attr("data-num");
                elem.off();
                const is_lock = mist_system.save_lock[num];
                if(is_lock) {
                    elem.click(function (e) {
                        if (mist_temp.is_tutorial) return;
                        e.stopPropagation();
                    });
                    continue;
                }
                elem.click(function (e) {
                    if (mist_temp.is_tutorial) return;

                    
                    e.stopPropagation();
                    const item = $(this).parent().parent();
                    const num = item.attr("data-num");
                    mist_temp.menuFocusManager.unregisterFocus();
                    that.displaySaveDeleteConfirm(num, (is_delete) => {
                        if (is_delete)
                        {
                            
                            loadFocusRecreate(j_save, auto_save, mist_temp.load_num_to_index_list[num]);
                        }
                        else
                        {
                            mist_temp.menuFocusManager.registerFocus();
                            mist_temp.menuFocusManager.setLastFocus();
                        }
                    });
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                });
                elem.hover(function (e) {
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                },
                (e) => {
                });
            }
            let count = 0;
            let focus_list = [];
            mist_temp.load_num_to_index_list = [];
            j_save.find("item").each(function () {
                const num = Number($(this).attr("data-num"));
                let data = undefined;
                if (num == -1) {
                    Common.setVisible($(this).find("icon-lock"), false);
                    Common.setVisible($(this).find("icon-trash"), false);
                    data = auto_save;
                    if(data === undefined) {
                        data = {
                            title: $.lang("not_saved"),
                            current_order_index: 0,
                            save_date: "",
                            img_data: "",
                            stat: {},
                        };
                    }
                }
                else {
                    data = ary_rawdata[num];
                }

                if (data != undefined && data["save_date"] != "") {
                    mist_temp.load_num_to_index_list[num] = count;
                    focus_list[count] = $(this);
                    ++count;
                }

                const chapter_name = (data.chapter) ? masterdata.chapter.find(x => x.chapter_id == data.chapter).chapter_name : "";
                const phase = data.phase ? `${data.phase}フェーズ` : "";
                const title = `${chapter_name} ${phase}`;
                $(this).find("save-text > title").text(title);

                const is_nodata = !data.img_data;
                if (is_nodata) {
                    $(this).find("save-text").hide();
                    $(this).find("icon").hide();
                    $(this).find("empty").show();
                    $(this).css("cursor", "default");
                    $(this).addClass("unselectable");
                    return;
                }
                if(data.backlog !== undefined && data.backlog.name !== undefined){
                    if(data.backlog.name.length > 0) {
                        
                        $(this).find("two_one_lines").show();
                        $(this).find("two_line").hide();
                        $(this).find("one_line_1").html(data.backlog.name);
                        $(this).find("one_line_2").html(data.backlog.texts[0]);
                    }
                    else {
                        
                        $(this).find("two_one_lines").hide();
                        $(this).find("two_line").show();
                        $(this).find("two_line_1").html(data.backlog.texts[0]);
                    }
                }
                else {
                    if(data.title == ""){
                        $(this).find("two_one_lines").hide();
                        $(this).find("two_line").hide();
                    }else{
                        
                        $(this).find("two_one_lines").hide();
                        $(this).find("two_line").show();
                        $(this).find("two_line_1").html(data.title);
                    }
                }

                $(this).hover(function(e) {
                    $(this).addClass("hover");
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
                    const data = Common.getSaveData().data[num];
                    if (data != undefined && data["save_date"] != "") {
                        mist_temp.save_slot_target = $(this);
                    }
                    if (num in mist_temp.load_num_to_index_list) {
                        mist_temp.menuFocusManager.setLastIndex(mist_temp.load_num_to_index_list[num]);
                    }
                    e.stopPropagation();
                }, function(e) {
                    $(this).removeClass("hover");
                    mist_temp.save_slot_target = undefined;
                    e.stopPropagation();
                });

                $(this).click(function (e) {
                    if (mist_temp.is_tutorial) return;

                    const element = $(this);
                    element.addClass("select");
                    element.removeClass("hover");
                    mist_temp.menuFocusManager.unregisterFocus();

                    
                    Common.setBlock(true);
                    e.stopPropagation();                    
                    setTimeout(function(){
                        Common.setBlock(false);
                        const num = Number(element.attr("data-num"));
                        const data = Common.getSaveData().data[num];

                        element.removeClass("select");
                        
                        if (num == -1)
                        {
                            const auto_save = $.getStorage(that.kag.config.projectID + "_tyrano_auto_save", that.kag.config.configSave);
                            if (!auto_save) return;
                        
                        } else if (data["save_date"] == "") {
                            return;
                        }

                        mist_temp.menuFocusManager.unregisterFocus();
                        that.displayLoadConfirm(num, () => {
                            mist_temp.menuFocusManager.registerFocus();
                            mist_temp.menuFocusManager.setLastFocus();
                        });
                        TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
                        
                        Common.setBlock(false);
                    }, Common.durationSelected());
                }).focusable();
            });
            var focus_index_list  = [];
            for(let i = 0; i < focus_list.length; ++i) {
                const up = (i + focus_list.length - 1) % focus_list.length;
                const down = (i + 1) % focus_list.length;
                focus_index_list[i] = [up, down];
            }
            mist_temp.menuFocusManager = new FocusManager("load", focus_list, focus_index_list);

            that.setMenuScrollEvents(j_save, { target: ".area-save-list", move: 160 });
            that.setMenu(j_save, callback);
        },
    );
};

function loadFocusRecreate(j_save, auto_save, last_index) {
    let count = 0;
    focus_list = [];
    mist_temp.load_num_to_index_list = [];
    j_save.find("item").each(function () {
        const num = Number($(this).attr("data-num"));
        let data = num == -1 ? auto_save : Common.getSaveData().data[num];
        if (data != undefined && data["save_date"] != "") {
            mist_temp.load_num_to_index_list[num] = count;
            focus_list[count] = $(this);
            ++count;
        } else {
            $(this).off();
        }
    });
    var focus_index_list  = [];
    for(let i = 0; i < focus_list.length; ++i) {
        const up = (i + focus_list.length - 1) % focus_list.length;
        const down = (i + 1) % focus_list.length;
        focus_index_list[i] = [up, down];
    }
    last_index = last_index == 0 ? 0 : last_index - 1;
    mist_temp.menuFocusManager = new FocusManager("load", focus_list, focus_index_list, last_index);
}



tyrano.plugin.kag.menu.displayLoadConfirm = function (num, on_exit) {
    const that = this;
    this.kag.html(
        "load_confirm",
        {},
        (html_str) => {
            const elem = $(html_str);
            const button_yes_elem = elem.find(".menu_buttons_grid_yes");
            const button_no_elem = elem.find(".menu_buttons_grid_no");
            initMenuCursorLineButton(button_yes_elem);
            initMenuCursorLineButton(button_no_elem);
            const current_save_elem = elem.find("save-data");

            let layer_menu = that.kag.layer.getMenuLayer();
            layer_menu.append(elem);
            current_save_elem.attr("data-num", num);

            const save_data = (() => {
                if (num == "-1") {
                    const json = $.getStorage(that.kag.config.projectID + "_tyrano_auto_save", that.kag.config.configSave);
                    return JSON.parse(json);
                } 
                return Common.getSaveData().data[num];
            })();
            that.updateSaveSlot(current_save_elem, save_data);

            
            const save_item = elem.find(".save");
            const cancel_item = elem.find(".cancel");

            const appendFadeContainer = (() => {
                const layer = $(".tyrano_base");
                const exist_container = layer.find("load-fade-container").length > 0;
                if(!exist_container) {
                    layer.append(`<load-fade-container></load-fade-container>`);
                }
                layer.show();
                return layer.find("load-fade-container").eq(0);
            });
            const fadeOut = ((callback, time) => {
                const fade = appendFadeContainer();
                const fade_time = time ? time : parseInt(Common.getDefineLabel("@program_fade_time"));
                fade.hide().fadeIn(fade_time, "linear", function() {
                    if(callback) {
                        callback();
                    }
                });
            });

            save_item.click(() => {
                if (mist_temp.is_tutorial) return;

                Common.setVisible($(save_item).find("cursor"), true);
                save_item.off();
                cancel_item.off();
                TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });

                setTimeout(function(){
                    
                    fadeOut(() => {
                        that.snap = null;
                        
                        if (num == "-1")
                        {
                            that.kag.menu.loadAutoSave();
                        
                        } else {
                            that.loadGame(num);
                        }

                        
                        var layer_menu = that.kag.layer.getMenuLayer();
                        layer_menu.hide();
                        layer_menu.empty();
                        TYRANO.kag.variable.tf.is_return_menu = false;
                        if (that.kag.stat.visible_menu_button == true) {
                            $(".button_menu").show();
                        }
                        elem.remove();
                        mist_system.FooterContainer.show(false);
                    }, 500);
                }, Common.durationSelected());
            });
            cancel_item.click(() => {
                if (mist_temp.is_tutorial) return;
                
                Common.setVisible($(cancel_item).find("cursor"), true);
                save_item.off();
                cancel_item.off();

                setTimeout(function(){
                    elem.remove();
                    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
                    mist_system.FooterContainer.show(false);
                    if (typeof on_exit == "function") {
                        on_exit();
                    }
                }, Common.durationSelected());
            });
            mist_system.FooterContainer.hide(false);

            
            Common.setFocus(save_item);
        },
    );
};


tyrano.plugin.kag.menu.snapSave = function (title, call_back, flag_thumb) {
    
	Common.saveSystem();
    
    this.kag.trigger("snapsave-start");

    var that = this;

    
    var _current_order_index = that.kag.ftag.current_order_index - 1;
    var _stat = $.extend(true, {}, $.cloneObject(that.kag.stat));

    

    var three = this.kag.tmp.three;
    var models = three.models;

    var three_save = {};

    three_save.stat = three.stat;
    three_save.evt = three.evt;

    var save_models = {};

    for (var key in models) {
        var model = models[key];
        save_models[key] = model.toSaveObj();
    }

    three_save.models = save_models;

    

    if (typeof flag_thumb == "undefined") {
        flag_thumb = this.kag.config.configThumbnail;
    }

    if (flag_thumb == "false") {
        
        
        
        var img_code = "";
        
        var layer_obj = that.kag.layer.getLayeyHtml();
        let chapter = this.kag.stat.f.chapter;
        const backlogs = this.kag.stat.f.backlog;
        let last_log = undefined;
        if(backlogs) {
            
            for(let i = backlogs.length - 1; i >= 0; --i) {
                last_log = backlogs[i];
                if(last_log.name != "empty") {
                    break;
                }
            }
        }
        if(last_log) {
            last_log = $.extend(true, {}, $.cloneObject(last_log));
            const count = last_log.texts.length;
            for(let i = 0; i < count; ++i) {
                last_log.texts[i] = last_log.texts[i].replace(/(<([^>]+)>)/gi, '');
            }
        }
        let phase = "";
        if(this.kag.stat.f.detective_mode) {
            if(isModeInvestigation()) {
                phase = "調査";
            }
            if(isModeDebate()) {
                phase = "全体議論";
            }
            if(isModeVote()) {
                phase = "投票";
            }
        }

        var data = {
            title: title,
            chapter: chapter,
            phase: phase,
            backlog: last_log,
            stat: _stat,
            three: three_save,
            current_order_index: _current_order_index,
            save_date: that.getDateStr(),
            img_data: img_code,
            layer: layer_obj,
        };

        that.snap = $.extend(true, {}, $.cloneObject(data));

        if (call_back) {
            call_back();

            
            that.kag.trigger("snapsave-complete");
        }
    } else {
        var thumb_scale = this.kag.config.configThumbnailScale || 1;
        if (thumb_scale < 0.01) thumb_scale = 0.01;
        if (thumb_scale > 1) thumb_scale = 1;

        $("#tyrano_base").find(".layer_blend_mode").css("display", "none");

        setTimeout(function () {
            
            
            
            var completeImage = function (img_code) {
                var layer_obj = that.kag.layer.getLayeyHtml();
                let chapter = that.kag.stat.f.chapter;
                let phase = "";
                const backlogs = that.kag.stat.f.backlog;
                let last_log = undefined;
                if(backlogs) {
                    
                    for(let i = backlogs.length - 1; i >= 0; --i) {
                        last_log = backlogs[i];
                        if(last_log.name != "empty") {
                            break;
                        }
                    }
                }
                if(last_log) {
                    last_log = $.extend(true, {}, $.cloneObject(last_log));
                    const count = last_log.texts.length;
                    for(let i = 0; i < count; ++i) {
                        last_log.texts[i] = last_log.texts[i].replace(/(<([^>]+)>)/gi, '');
                    }
                }
                if(that.kag.stat.f.detective_mode) {
                    if(isModeInvestigation()) {
                        phase = "調査";
                    }
                    if(isModeDebate()) {
                        phase = "全体議論";
                    }
                    if(isModeVote()) {
                        phase = "投票";
                    }
                }
                
                var data = {
                    title: title,
                    chapter: chapter,
                    phase: phase,
                    backlog: last_log,
                    stat: _stat,
                    three: three_save,
                    current_order_index: _current_order_index,
                    save_date: that.getDateStr(),
                    img_data: img_code,
                    layer: layer_obj,
                };

                that.snap = $.extend(true, {}, $.cloneObject(data));

                if (call_back) {
                    call_back();

                    
                    that.kag.trigger("snapsave-complete");
                }

                that.kag.hideLoadingLog();
            };

            if (that.kag.stat.save_img != "") {
                
                
                

                var img = new Image();
                img.src = _stat.save_img;
                img.onload = function () {
                    var canvas = document.createElement("canvas");
                    canvas.width = that.kag.config.scWidth * thumb_scale;
                    canvas.height = that.kag.config.scHeight * thumb_scale;
                    
                    var ctx = canvas.getContext("2d");
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    
                    var img_code = that.createImgCode(canvas);

                    completeImage(img_code);
                };
            } else {
                
                
                

                that.kag.showLoadingLog("save");

                
                let canvas = document.createElement("canvas"); 
                let ctx = canvas.getContext("2d");
                let videos = document.querySelectorAll("video");
                let w, h;
                for (let i = 0, len = videos.length; i < len; i++) {
                    const v = videos[i];
                    
                    try {
                        w = v.videoWidth;
                        h = v.videoHeight;

                        canvas.style.left = v.style.left;
                        canvas.style.top = v.style.top;

                        canvas.style.width = v.style.width;
                        canvas.style.height = v.style.height;

                        canvas.width = w;
                        canvas.height = h;

                        ctx.fillRect(0, 0, w, h);
                        ctx.drawImage(v, 0, 0, w, h);
                        v.style.backgroundImage = `url(${canvas.toDataURL()})`; 
                        v.style.backgroundSize = "cover";
                        v.classList.add("tmp_video_canvas");

                        ctx.clearRect(0, 0, w, h); 
                    } catch (e) {
                        continue;
                    }
                }

                
                var flag_canvas = false;
                var array_canvas = [];
                $("#tyrano_base")
                    .find("canvas")
                    .each(function (index, element) {
                        array_canvas.push(element);
                    });
                if (array_canvas.length > 0) {
                    flag_canvas = true;
                }

                var tmp_base;

                
                if (flag_canvas) {
                    tmp_base = $("#tyrano_base");
                } else {
                    tmp_base = $("#tyrano_base").clone();
                    tmp_base.addClass("snap_tmp_base");
                    $("body").append(tmp_base);
                }

                var tmp_left = tmp_base.css("left");
                var tmp_top = tmp_base.css("top");
                var tmp_trans = tmp_base.css("transform");

                tmp_base.css("left", 0);
                tmp_base.css("top", 0);
                tmp_base.css("transform", "");
                tmp_base.find(".layer_menu").hide();

                var opt = {
                    scale: thumb_scale,
                    height: that.kag.config.scHeight,
                    width: that.kag.config.scWidth,
                    logging: that.kag.config["debugMenu.visible"] === "true",
                };

                html2canvas(tmp_base.get(0), opt).then(function (canvas) {
                    $("#tyrano_base").find(".layer_blend_mode").css("display", "");
                    $("#tyrano_base").find(".tmp_video_canvas").css("backgroundImage", "");

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    var img_code = that.createImgCode(canvas);

                    completeImage(img_code);
                });

                tmp_base.hide();

                tmp_base.css("left", tmp_left);
                tmp_base.css("top", tmp_top);
                tmp_base.css("transform", tmp_trans);
                tmp_base.find(".layer_menu").show();
                $("body").find(".snap_tmp_base").remove();

                tmp_base.show();
            }
        }, 20);
    }
};


tyrano.plugin.kag.menu.displayOption = function (call_back, showFooterSystem=true) {
    displayOption(false, call_back, showFooterSystem);
};


tyrano.plugin.kag.menu.doSetAutoSave = function () {
    var data = this.snap;
    data.save_date = this.getDateStr();
    data.img_data = "./data/image/save_load_new/autosave.png";
    $.setStorage(this.kag.config.projectID + "_tyrano_auto_save", data, this.kag.config.configSave);

    
    this.kag.trigger("storage-autosave");

    var layer_menu = this.kag.layer.getMenuLayer();
    layer_menu.hide();
}
