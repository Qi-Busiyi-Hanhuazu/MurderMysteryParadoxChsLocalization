Conversation = class{
}


function setupConversationMaster(data){
	var tmp = JSON.parse(data)
	conversation_dict = {};
	tmp.forEach(function(item, index, array) {
		let conversation = Object.assign(new Conversation(), item);
		conversation.text = Common.replaceDefineLabelStringAll(conversation.text);
		let topic_id = conversation.topic_id;
		if(!conversation_dict[topic_id]){ conversation_dict[topic_id] = []; }
		conversation_dict[conversation.topic_id].push(conversation);
	});
}

function getConversationMaster(){
	return conversation_dict;
}

function getConversation(topic_id){
	return conversation_dict[topic_id];
}
