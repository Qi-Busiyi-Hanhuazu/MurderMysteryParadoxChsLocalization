NpcVote = class{
  constructor(npc_id, credit_level, target_id){
	this.npc_id = npc_id;
	this.credit_level = parseInt(credit_level);
	this.target_id = target_id;
  }
}



function setupNpcVoteMaster(data){
	var tmp = JSON.parse(data)
	npc_vote_dict = {};
	tmp.forEach(function(item, index, array) {
		let npc_vote = Object.assign(new NpcVote(), item);
		if(!npc_vote_dict[npc_vote.npc_id]){
			npc_vote_dict[npc_vote.npc_id] = {};
		}
		npc_vote_dict[npc_vote.npc_id][npc_vote.credit_level] = npc_vote;
	});
}

function getNpcVotingDestination(chara){
	const data = getCommonCondition('specified_vote_char');
	if(data){
		const specified_vote = data.value;
		if(specified_vote && specified_vote[chara.id]){
			return specified_vote[chara.id];
		}
	}

	if(!npc_vote_dict[chara.id] || !npc_vote_dict[chara.id][chara.credit_level]){
		return ;
	}
	return npc_vote_dict[chara.id][chara.credit_level].target_id;


}

