CommonHelp = class{
}

function setupCommonHelpMaster(data){
	var tmp = JSON.parse(data)
	common_help_dict = {};
	tmp.forEach(function(item, index, array) {
		let help = Object.assign(new CommonHelp(), item);
		help.text = Common.replaceDefineColorString(help.text);
		if(!common_help_dict[help.phase]){ common_help_dict[help.phase] = []; }
		common_help_dict[help.phase].push(help);
	});
}

function getCommonHelpMaster(){
	return common_help_dict;
}

function getCommonHelp(phase){
	return common_help_dict[phase];
}


function getCommonHelpDirect(phase){
	const data = getCommonHelp(phase);
	if(!data){ return "" }
	return data[0].text;
}

function getCommonHelpDirectOrDefault(phase){
	const data = getCommonHelp(phase);
	if(!data){ return phase; }
	return data[0].text;
}


function getCommonHelpWithCondition(name){
    let result = null;
    let data =getCommonHelp(name);
    if(data){
        result = data.find(cond => checkConditionsStr(cond.condition));
    }
    if(!result){
        return "";
    }
    return result.text;
}
