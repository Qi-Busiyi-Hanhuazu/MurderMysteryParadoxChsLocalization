Inference = class{
  constructor(id, name, desc, pieces){
    this.id = id;
    this.name = name;
	this.desc = desc;
	this.pieces = pieces;
	this.convince_level = 2;
  }

  convince_str() {
     const levels = { 'C-': '低', 'C': '低', 'C+': '低', 'B-': '中', 'B': '中', 'B+': '中', 'A-': '高', 'A': '高', 'A+': '高' }
     let result = levels[this.convince_level]; "";
     return result;
  }
}

function getFixedInference(doubt_id, piece_ids){
	const id = doubt_id + "@" + piece_ids.join('_');
	if(!inference_dict[id]){ return null; }
	return inference_dict[id]; 
}


function getInferenceImpl(piece_ids){
	const id = piece_ids.join('_');
    let name = piece_ids.map(id=>"{0}".format(getPiece(id).title)).join('と');
    return  new Inference(id, name, "『自動生成文章』", piece_ids);

}

function getInferenceFromDoubt(doubt, disableConvince = false, inferenceMode = false){
	if(!doubt.isAnswerFull(inferenceMode)){
		return null;
	}
	let inference = getInferenceImpl(doubt.getAnswerPieces(inferenceMode));
	inference.name = generateInferenceTitle(doubt, inferenceMode);
	inference.convince_level = calcConvinceLevel(doubt, inferenceMode);
    inference.convince_level_index = 0;
    if(inference.convince_level.startsWith("A")){
        inference.convince_level_index = 2;
    }else if(inference.convince_level.startsWith("B")){
        inference.convince_level_index = 1;
    }else if(inference.convince_level.startsWith("C")){
        inference.convince_level_index = 0;
    }


	
	inference.desc = generateInferenceText(doubt, inferenceMode)

	if(disableConvince){ return inference; }

	
	const fixedInference = getgetPieceConvincingTitleDesc(doubt.id, doubt.getAnswerPieces(inferenceMode));
	if(fixedInference){
		inference.name = fixedInference.title;
		inference.desc = fixedInference.desc;
	}

	return inference;
}
