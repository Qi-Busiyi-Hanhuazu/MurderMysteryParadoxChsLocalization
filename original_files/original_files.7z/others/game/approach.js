ApproachCondition = class{

}

function setupApproachConditionMaster(data){
	var tmp = JSON.parse(data)
	approach_condition_dict = {};
	approach_condition_timing_dict = {};
	tmp.forEach(function(item, index, array) {
		let condition = Object.assign(new ApproachCondition(), item);
		approach_condition_dict[condition.id] = condition;
		if(!approach_condition_timing_dict[condition.timing]){ approach_condition_timing_dict[condition.timing] = []; }
		approach_condition_timing_dict[condition.timing].push(condition);
	});
}

function getApproachConditionMaster(){
	return approach_condition_dict;
}
