
function newCharacter(chara_id, show_name, credit_level, mode, position, type, disp=true){
	const chara = getCharacter(chara_id);
	credit_level = Number(credit_level);
console.error("game_graphic : newCharacter");
	const faces = [
			"normal","close","earnest","surprise",
			"smile","what","happy","badsurprise","doubt","panic",
			"confused","stunned","trouble","sad","think",
			];
	const positionDef = [
		{"stand": {"left": -200, "top": 0 }, "tag": {"x": 92, "y": 900}, "credit": {"x": 468, "y": 845}},
		{"stand": {"left": 800, "top": 0 }, "tag": {"x": 1050, "y": 900}, "credit": {"x": 1268, "y": 845}},
		{"stand": {"left": 1250, "top": 0 }, "tag": {"x": 1500, "y": 900}, "credit": {"x": 1718, "y": 845}},
	];
	const posDef = positionDef[position];
	const chapter = TYRANO.kag.stat.f.chapter;
	const face = chara.defaultFace();

	if(mode == "secret"){
		if(type == "player"){
			TYRANO.kag.ftag.startTag("chara_new", {name: show_name, storage: `chara/${chara.resource}/${face}.png`, jname: show_name, width: 960, height: 1080});
			TYRANO.kag.ftag.startTag("image", {layer: 0, storage: "detective/common/UI_SysWnd_000.png", folder: "image", x: 0, y: 845, visible: "true", zindex: 110, width:217, height:44});
			TYRANO.kag.ftag.startTag("ptext", {name: "costInfoStr", layer: 0, x: 89, y: 843, width: 70, height: 26, size: 26, text: "{0}".format(getCost()), color: "white", align: "right", zindex: 111});
			TYRANO.kag.ftag.startTag("ptext", {layer: 0, x: 159, y: 851, width: 40, height: 22, size: 19, text: "/{0}".format(getInitCost()), color: "white", align: "left", zindex: 111});
		}else if(type == "NPC"){
			TYRANO.kag.ftag.startTag("chara_new", {name: show_name, storage: `chara/${chara.resource}/${face}.png`, jname: show_name, width: 960, height: 1080});
		}
		
		faces.forEach((face) => {
			TYRANO.kag.ftag.startTag("chara_face", {name: show_name, face: face, storage: `chara/${chara.resource}/${face}.png`});
			TYRANO.kag.ftag.startTag("chara_layer", {name: show_name, left: "0", top: "0", width: "960", height: "1080", id: face, part: "eye", storage: `chara/${chara.resource}/${face}_eyes.png`});
			
		});

		if(disp){
			
			TYRANO.kag.ftag.startTag("chara_show", {name: show_name, left: posDef["stand"]["left"], top: posDef["stand"]["top"], time: 0, zindex: 0});
			TYRANO.kag.ftag.startTag("image", {layer: 0, x: posDef["tag"]["x"], y: posDef["tag"]["y"], storage:"chara/{0}/select_talk_name.png".format(chara.resource), folder: "fgimage", width:323, height:66 });
			TYRANO.kag.ftag.startTag("chara_mod", {name: show_name, face: chara.defaultFace()});
		}
	}else if(mode == "gather"){
		if(type == "player"){
			TYRANO.kag.ftag.startTag("chara_new", {name: show_name, storage: "chara/chapters/{0}/{1}/select_talk.png".format(chapter, chara_id), jname: show_name, width: 495, height: 1080});

		}else if(type == "NPC"){
			TYRANO.kag.ftag.startTag("chara_new", {name: show_name, storage: "chara/chapters/{0}/{1}/select_talk_{2}.png".format(chapter, chara_id, credit_level + 1), jname: show_name, width: 340, height: 1080});

		}

		
		faces.forEach((face) => {
			TYRANO.kag.ftag.startTag("chara_face", {name: show_name, face: face, storage: "chara/chapters/{0}/{1}/{2}.png".format(chapter, chara_id, face)});

		});
	}
}


function deleteCharacter(name){
	TYRANO.kag.ftag.startTag("chara_delete", {name: name});
}


function switchSelectIdFunc(selection, selectIndex) {
	selection.forEach((select, index) => {
		
		const idx = index + 1;
        $(select).off()
        $(select).css("id", "")
		if(idx != selectIndex){
			$(select).css("color", "rgb(11,12,12)")
			const badge = "{0} badge".format(select);
			if((badge).length == 0){ 
				$(select).children().contents().unwrap()
			}
		}
	});
}

function removeHtmlElement(name){
	$(name).remove();
}

function blurToBackground(enable){
    const img = TYRANO.kag.layer.getLayer("base", "fore");
    if(img.length == 0){ return; }
    let bg_url = img.css("background-image");
    
    let bg_info = undefined;
	if( isModeInvestigation()) {  bg_info = getCommonCondition(`bg_detective`).value; }
	if( isModeDebate()) {  bg_info = getCommonCondition(`bg_debate`).value; }
	if( isModeVote()) {  bg_info = getCommonCondition(`bg_vote`).value; }

    if(bg_info == void 0 || bg_info["blur"] == void 0){ return ; }

    if(enable && bg_url.lastIndexOf(bg_info["value"]) != -1){
		const url = bg_url.replace(bg_info["value"], bg_info["blur"]);
		const preload_list = [
			url.substring(url.indexOf("/data/") + 1).replace('")', ''),
		];
		Common.preloadAll(preload_list, () => {
			img.css("background-image", url);
			let bg_name = bg_info["blur"];
			setBackgroundAnimation(bg_name.split(".")[0], img);
			
			TYRANO.kag.ftag.startTag("free_layermode", {"name":"background-effect", "stop":"true"});
		});
    }else if(!enable && bg_url.lastIndexOf(bg_info["blur"]) != -1){
		const url = bg_url.replace(bg_info["blur"], bg_info["value"]);
		const preload_list = [
			url.substring(url.indexOf("/data/") + 1).replace('")', ''),
		];
		Common.preloadAll(preload_list, () => {
			img.css("background-image", url);
			let bg_name = bg_info["value"];
			setBackgroundAnimation(bg_name.split(".")[0], img);
		});
    }

    if(!enable){
        playBackgroundAnimation();
    }


}


function playBackgroundAnimation(){
    const img = TYRANO.kag.layer.getLayer("base", "fore");
    let bg_url = img.css("background-image");
    if(!bg_url){ return ; }
    const tmp = bg_url.split('/');
    if(!tmp || tmp.length == 0){ return ; }
    const bg_file = tmp[tmp.length-1].split('.')[0];
    setBackgroundAnimation(bg_file, img);
}
