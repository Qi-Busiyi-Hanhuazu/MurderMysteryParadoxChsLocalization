
BackgroundAnimation = class {
    constructor() 
    {
        this.ANIMATION_CLASS = "bg_animation_pattern";
        this.animation_ids_array = [];
        this.timer_id = undefined;
    }

    
    set() {
        for(let id of this.animation_ids.split(",")) {
            this.animation_ids_array.push(parseInt(id, 0));
        }
    }

    
    toHtml() {
        return `<div class="bg_animation ${this.bg_animation_name}" style="left: ${this.left}px; top: ${this.top}px; width: ${this.width}px; height: ${this.height}px; position: absolute; background-image: url(./data/bgimage/${this.bg_animation_name}.png); opacity: 0;"/>`;
    }

    
    setAnimationEvent(elem)
    {
        if (elem.length == 0) return;

        
        if(this.hasAniamtionClass(elem)) {
            return;
        }

        if(this.timer_id !== undefined) {
            clearTimeout(this.timer_id);
        }

        this.removeAnimationClass(elem);
        
        const first_time = Common.randomRange(0, 2000);
        this.timer_id = setTimeout(() => {
            
            this.timer_id = undefined;
            this.addRandomAnimationClass(elem);
        }, first_time);

        
        elem.off('animationiteration');
        
        
        elem.on('animationiteration', () => {
            
            this.removeAnimationClass(elem);
            
            const time = Common.randomRange(1000, 5000);
            this.timer_id = setTimeout(() => {
                
                this.timer_id = undefined;
                this.addRandomAnimationClass(elem);
            }, time);
        });
    }

    
    removeAnimationClass(elem)
    {
        if (elem.length == 0) return;

        const class_list = Common.getClassList(elem);
        for (let i = 0; i < class_list.length; ++i)
        {
            if (class_list[i].indexOf(this.ANIMATION_CLASS) >= 0)
            {
                elem.removeClass(class_list[i]);
            }
        }
    }

    
    addRandomAnimationClass(elem)
    {
        if (elem.length == 0) return;

        const index = Common.randomRange(0, this.animation_ids_array.length);
        elem.addClass(`${this.ANIMATION_CLASS}_${this.bg_animation_name}_${this.animation_ids_array[index]}`);
    }

    
    hasAniamtionClass(elem) {
        if (elem.length == 0) return false;

        const class_list = Common.getClassList(elem);
        for (let i = 0; i < class_list.length; ++i)
        {
            if (class_list[i].indexOf(this.ANIMATION_CLASS) >= 0)
            {
                return true;
            }
        }

        return false;
    }

    
    createCssStyle(animation_patterns)
    {
        let keyframes_css = "";
        let animations_css = "";
        const width = parseInt(this.width);
        const animation_names = []
        for(let id of this.animation_ids_array) {
            const animation_name = `${this.ANIMATION_CLASS}_${this.bg_animation_name}_${id}`;
            if(animation_names.findIndex(x => x == animation_name) >= 0) {
                continue;
            }
            animation_names.push(animation_name);
            let keyframe = "";
            const anime = animation_patterns[id];
            console.log(animation_patterns[id]);
            anime.keyframes.forEach((blink) =>
            {
                const percent = blink[0];
                const disp = parseInt(blink[1]);
                if(disp >= 1) {
                    keyframe += ` ${percent} { opacity: 1; }`;
                }
                else {
                    keyframe += ` ${percent} { opacity: 0; }`;
                }
            });
            console.log(keyframe);
            keyframes_css += `@keyframes key_${animation_name} { ${keyframe} }\n`;
            animations_css += `.${animation_name} { animation: key_${animation_name} ${anime.duration}s steps(1) infinite; }\n`;
        }


        const style =
`/* 背景アニメーション ${this.bg_animation_name} */
${keyframes_css}${animations_css}`;
        return style;
    }
}


function setupBackgroundAnimationMaster(data){
	var tmp = JSON.parse(data);
	background_animation_dict = {};
	tmp.forEach(function(item, index, array) {
		let backgroundAnimation = Object.assign(new BackgroundAnimation(), item);
        backgroundAnimation.set();
		if(!background_animation_dict[backgroundAnimation.bg_name]){ background_animation_dict[backgroundAnimation.bg_name] = []; }
		background_animation_dict[backgroundAnimation.bg_name].push(backgroundAnimation);
	});
}


function setBackgroundAnimation(bg_name, layer) {
    if(layer.length <= 0) {
        return;
    }

    const animations = background_animation_dict[bg_name];
    if(animations === undefined) {
        
        layer.find(".bg_animation").remove();
        return;
    }

    for(let animation of animations) {
        let elem = layer.find(`.${animation.bg_animation_name}`);
        if(elem.length <= 0) {
            layer.append(animation.toHtml());
            elem = layer.find(`.${animation.bg_animation_name}`);
        }
        animation.setAnimationEvent(elem);
    }
}

function removeBackgroundAnimation(bg_name, layer) {
    if(layer.length <= 0) {
        return;
    }
    const animations = background_animation_dict[bg_name];
    if(animations === undefined) {
        return;
    }

    for(let animation of animations) {
        let elem = layer.find(`.${animation.bg_animation_name}`);
        if(elem.length <= 0) {
            layer.append(animation.toHtml());
            elem = layer.find(`.${animation.bg_animation_name}`);
        }
        animation.removeAnimationClass(elem);
    }
}


function loadBackgtoundAnimation() {
    const backgroundLayer = TYRANO.kag.layer.getLayer("base", "fore");
    const bg_url = backgroundLayer.css("background-image");
    const bg_name = bg_url.split("/").reverse()[0].split('.')[0];
    removeBackgroundAnimation(bg_name, backgroundLayer);
    setBackgroundAnimation(bg_name, backgroundLayer);
}
