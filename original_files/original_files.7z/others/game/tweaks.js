(function(){
    if (!String.prototype.format) {
        String.prototype.format = function () {
            var args = arguments;
            return this.replace(/{(\d+)}/g, function (match, number) {
                return typeof args[number] != 'undefined'? args[number]: match;
            });
        };
    }
})();


function watchValue(obj, propName, func) {
    let value = obj[propName];
    if(value === undefined) {
        console.error(`watchValue error: ${propName} undefined`);
    }
    Object.defineProperty(obj, propName, {
        get: () => value,
        set: newValue => {
            const oldValue = value;
            value = newValue;
            func(oldValue, newValue);
        },
        configurable: true
    });
}

function setPlaySeOnClick(){
	TYRANO.kag.on("click-next", () => {
		playSeRoundrobin("system/se_sys06.mp3", true);
	});
}

function mistSnapSave(){
	TYRANO.kag.on("snapsave-start", () => {
		if(TYRANO.kag.stat.f.detective_mode || TYRANO.kag.stat.f.save_detective){
			doDetectiveSave();
		}
	});
}



function stopGameProgress(){
    TYRANO.kag.variable.tf.saved_strong_stop = TYRANO.kag.stat.is_strong_stop;
    TYRANO.kag.ftag.kag.setSkip(false);
    TYRANO.kag.ftag.kag.setAuto(false);
    TYRANO.kag.ftag.kag.stat.is_auto_wait = false;
    TYRANO.kag.ftag.kag.weaklyStop();
    TYRANO.kag.ftag.kag.stronglyStop();
    setFlagStopGameProgress(true);
}



function restartGameProgress(callNextOrder){
    setFlagStopGameProgress(false);
    TYRANO.kag.ftag.kag.cancelWeakStop();
    if(!TYRANO.kag.variable.tf.saved_strong_stop){ 
        TYRANO.kag.ftag.kag.cancelStrongStop();
    }
    if(callNextOrder){
        TYRANO.kag.ftag.nextOrder();
    }
}

function setFlagStopGameProgress(flag){
    TYRANO.kag.variable.tf.stop_game_progress = flag;
}

function isStopGameProgress(){
    return TYRANO.kag.variable.tf.stop_game_progress;
}

function shapeMacroLabel(label){
    return label.replace(".ks", "").replace(/\u002f/g, "").replace(/:/g, "").replace(/\./g, "");
}

function setDynamicLabel(offset=0, prefix=''){
    
    
    prefix = prefix.replace(".ks", "").replace(/\u002f/g, "").replace(/:/g, "").replace(/\./g, "");
 
    const macro = TYRANO.kag.stat.stack.macro;
    if(macro.length <= 0){ return ; }
    prefix = `_dynamic_${TYRANO.kag.stat.f.chapter}_${prefix}`;
    const data = macro[macro.length - 1];
    TYRANO.kag.ftag.startTag("label", {
        scneario: data.storage,
        label_name: `${prefix}_${data.index + offset}`,
        nextorder: "false"
    });    
}
function setDynamicLabelBefore(prefix=''){
    setDynamicLabel(-1, prefix);
}
function setDynamicLabelAfter(prefix=''){
    setDynamicLabel(1, prefix);
}

function isInMacroFile(){
    const macros = [
        "LB_adv_staging_macro.ks",
        "common_macro.ks",
        "LB_adv_character_display_macro.ks",
        "detective/macro.ks",
        "detective/nop_macro.ks",
        "detective/module/call_macro.ks",
        "detective/debug/debug_macro.ks",
        "LB_adv_text_display_macro.ks",
    ];
    return macros.includes(TYRANO.kag.stat.current_scenario);
}



function tweakFunctions(){
	setPlaySeOnClick();
    mistSnapSave();
}
