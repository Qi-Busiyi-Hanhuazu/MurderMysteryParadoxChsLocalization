


function happened(id){
	return (Boolean)(alreadyHappenedApproach(id));
}
function notHappened(id){
	return !happened(id);
}

function onPhase(timing){
	
	return TYRANO.kag.stat.f.phaseTiming == timing;
}

function lastSecretTalk(chara_id){
	if(!TYRANO.kag.stat.f.lastTalkedCharaId){ return false; }
	return TYRANO.kag.stat.f.lastTalkedCharaId == chara_id; 
}

function lastSecretTalkNot(chara_id){
	if(!TYRANO.kag.stat.f.lastTalkedCharaId){ return false; }
	return TYRANO.kag.stat.f.lastTalkedCharaId != chara_id; 
}

function notSecretTalk(chara_id){
	if(!TYRANO.kag.stat.f.talkedList){ TYRANO.kag.stat.f.talkedList = {};}
	return !TYRANO.kag.stat.f.talkedList[chara_id];
}

function resolvedDoubt(doubt_id){
	return alreadySolvedDoubt(doubt_id);
}
function notConfirmDoubt(doubt_id){
	const havingDoubts = getDoubtIds();
	return !havingDoubts.includes(doubt_id) && checkConditionsStr(getDoubt(doubt_id).conditions); 
}

function endQuestion(talk_id){
	return TYRANO.kag.stat.f.lastTalkId == talk_id;
}

function notEndQuestion(talk_id){
	return !alreadyTalked(talk_id);
}

function notHave(piece_id){
	return notExistsInventory(piece_id);
}
function alreadyQuestion(talk_id){
	return alreadyTalked(talk_id);
}

function moreCredit(creditStr){
	const result = creditStr.split('.');
	return getCharacter(result[0]).credit_level > Number(result[1]);
}
function lessCredit(creditStr){
	const result = creditStr.split('.');
	return getCharacter(result[0]).credit_level < Number(result[1]);
}

function lessCost(cost){
	return TYRANO.kag.stat.f.player_cost < cost;
}

function moreCost(cost){
	return TYRANO.kag.stat.f.player_cost > cost;
}

function buildInference(id){
	return getDoubt(id).hasInference();
}

function notBuildInference(id){
	return !buildInference(id);
}

function canReceiveDoubt(id){
	
	for(const chara of getCharacterList()){
		const ret = getNextFreeDoubt(chara.id);
		if(ret != null && ret.id == id){ return true; }
	}

	return false;
}

function notIsLastAction(dummy){
	return !isLastAction(dummy);
}

function moreDoubtCount(cnt){
	return notCompleteDoubtCount(TYRANO.kag.stat.f.npc_key) > Number(cnt);
}
function lessDoubtCount(cnt){
	return notCompleteDoubtCount(TYRANO.kag.stat.f.npc_key) < Number(cnt);
}

function meetDoubtCond(id){
	const doubt = getDoubt(id);
	return checkDoubtCondtions(doubt.conditions);
}

function notMeetDoubtCond(id){
	return !meetDoubtCond(id);
}

function questionCond(arg){
	const keys = arg.split('.'); 
	const id = keys[0];
	const cond_key = `cond${keys[1]}`;

	return checkConditionsStr(getQuestion(id)[cond_key]);
}

function notQuestionCond(id){
	return !questionCond(id);
}

function haveDoubt(id){
	return getDoubtIds().includes(id);
}

function notHaveDoubt(id){
	return !haveDoubt(id);
}



function moreThanPiece(n){
	return pieceCount() >= n;
}


function lessThanPiece(n){
	return pieceCount() >= n;
}


function moreThanDoubt(n){
	return getDoubtAll().length >= n;
}


function lessThanDoubt(n){
	return getDoubtAll().length <= n;
}


function moreThanDoubtB(n){
	return getDoubtAll().filter(d => d.hasInference()).length >= n;
}


function lessThanDoubtB(n){
	return getDoubtAll().filter(d => d.hasInference()).length <= n;
}

function elapsedCostDoubt(arg){
	const keys = arg.split('.'); 
	return getDoubt(keys[0]).consumed_cost >= keys[1];
}

function notHappenedApproach(){
	return TYRANO.kag.stat.f.block_happend_approach == null;
}

function lastApproach(id){
	return TYRANO.kag.stat.f.last_happend_approach == id;
}

function notLastApproach(id){
	return !lastApproach(id)
}

function availableTutorial(id){
    if (!mist_system.tutorial_group) {
        return true;
    }
    return !mist_system.tutorial_group[id];
}

function unavailableTutorial(id){
    return !availableTutorial(id);
}



function getCondFunction(str){
	if(str == "H"){ return existsInventory; }
	if(str == "nH"){ return notExistsInventory; }
	if(str == "S"){ return alreadySolvedDoubt; }
	if(str == "nS"){ return notAlreadySolvedDoubt; }
	if(str == "C"){ return completeDoubt; }
	if(str == "nC"){ return notCompleteDoubt; }
	if(str == "B"){ return buildInference; }
	if(str == "nB"){ return notBuildInference; }

	if(str == "A"){ return alreadyDoneApproach; }
	if(str == "nA"){ return notAlreadyDoneApproach; }

	if(str == "L"){ return isCreditLevel; }
	if(str == "uL"){ return underCreditLevel; }
	if(str == "F"){ return isFlag; }
	if(str == "nF"){ return isNotFlag; }

	if(str == "happened"){ return happened; }
	if(str == "notHappened"){ return notHappened; }
	if(str == "onPhase"){ return onPhase; }
	if(str == "lastSecretTalk"){ return lastSecretTalk; }
	if(str == "lastSecretTalkNot"){ return lastSecretTalkNot; }
	if(str == "notSecretTalk"){ return notSecretTalk; }
	if(str == "lessCredit"){ return lessCredit; }
	if(str == "resolvedDoubt"){ return resolvedDoubt; }
	if(str == "notConfirmDoubt"){ return notConfirmDoubt; }
	if(str == "endQuestion"){ return endQuestion; }
	if(str == "notHave"){ return notHave; }
	if(str == "alreadyQuestion"){ return alreadyQuestion; }
	if(str == "notEndQuestion"){ return notEndQuestion; }
	if(str == "moreCredit"){ return moreCredit; }
	if(str == "lessCost"){ return lessCost; }
	if(str == "moreCost"){ return moreCost; }
	if(str == "canReceiveDoubt") { return canReceiveDoubt; }
	if(str == "isLastAction") { return isLastAction; }
	if(str == "notIsLastAction") { return notIsLastAction; }
	if(str == "moreDoubtCount") { return moreDoubtCount; }
	if(str == "lessDoubtCount") { return lessDoubtCount; }
	if(str == "meetDoubtCond") { return meetDoubtCond; }
	if(str == "notMeetDoubtCond") { return notMeetDoubtCond; }
	if(str == "QC") { return questionCond; }
	if(str == "nQC") { return notQuestionCond; }
	if(str == "haveDoubt") { return haveDoubt; }
	if(str == "notHaveDoubt") { return notHaveDoubt; }

	if(str == "moreThanPiece") { return moreThanPiece; }
	if(str == "lessThanPiece") { return lessThanPiece; }
	if(str == "moreThanDoubt") { return moreThanDoubt; }
	if(str == "lessThanDoubt") { return lessThanDoubt; }
	if(str == "moreThanDoubtB") { return moreThanDoubtB; }
	if(str == "lessThanDoubtB") { return lessThanDoubtB; }
	if(str == "elapsedCostDoubt") { return elapsedCostDoubt; }
	if(str == "notHappenedApproach") { return notHappenedApproach; }
	if(str == "lastApproach") { return lastApproach; }
	if(str == "notLastApproach") { return notLastApproach; }
	if(str == "unavailableTutorial") { return unavailableTutorial; }
	if(str == "availableTutorial") { return availableTutorial; }

	return null;
}

