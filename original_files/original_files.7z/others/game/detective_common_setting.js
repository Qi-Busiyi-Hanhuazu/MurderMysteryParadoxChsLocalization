DetectiveCommonSetting = class{
}

function setupDetectiveCommonSettingMaster(data){
	var tmp = JSON.parse(data)
	detective_common_setting = {};
	tmp.forEach(function(item, index, array) {
		let data = Object.assign(new DetectiveCommonSetting(), item);
		if(data && data.value){ data.value = Common.convertDict(data.value); }
		detective_common_setting[data.name] = data;
	});
}

function getDetectiveCommonSettingMaster(){
	return detective_common_setting;
}

function getDetectiveCommonSetting(name){
	if(!detective_common_setting[name]){ return null; }
	return detective_common_setting[name];
}
