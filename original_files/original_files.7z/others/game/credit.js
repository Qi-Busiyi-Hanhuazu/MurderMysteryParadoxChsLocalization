

var character_credit_table = {
    'normal' : {
        '0': 100,
        '1': 100,
        '2': 100,
    },
}

function getCreditTable(){
	return character_credit_table;
}

credit_level_dict = {
	0:"★☆☆",1:"★★☆",2:"★★★",
}

