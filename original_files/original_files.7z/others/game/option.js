optionVariable = class {
	isAnimation = true;
	showTestTextTimeId = -1;
}

function displayOption(is_menu = false, cb = undefined, showFooterSystem=true) {
	var that = TYRANO.kag.menu;
	const default_auto_speed_with_text = 50;

	optionVariable.isAnimation = true;
	optionVariable.showTestTextTimeId = true;
	mist_temp.is_hover_on = false;
	var layer_menu = that.kag.layer.getMenuLayer();
	var test_text = "テキストの表示速度を変更します";
	var test_text_color = "white";

	that.kag.html("option",
		{}, 
		function (html_str) {
			var j_option = $(html_str);
			
			const text_speed = j_option.find("text-speed-grid");
			const text_speed_select_line = j_option.find("text-speed-select-line-grid").find("select-line");
			const text_skip = j_option.find("text-skip-grid");
			const text_skip_select_line = j_option.find("text-skip-select-line-grid").find("select-line");
			const auto_wait = j_option.find("auto-wait-grid");
			const auto_wait_select_line = j_option.find("auto-wait-select-line-grid").find("select-line");
			const bgm_volume = j_option.find("bgm-volume-grid");
			const bgm_volume_select_line = j_option.find("bgm-volume-select-line-grid").find("select-line");
			const se_volume = j_option.find("se-volume-grid");
			const se_volume_select_line = j_option.find("se-volume-select-line-grid").find("select-line");
			const cursor_position = j_option.find("cursor-position-grid");
			const cursor_position_select_line = j_option.find("cursor-position-select-line-grid").find("select-line");
			const screen_mode = j_option.find("screen-mode-grid");
			const screen_mode_select_line = j_option.find("screen-mode-select-line-grid").find("select-line");
			const reset = j_option.find("reset-grid");
			const close = j_option.find("close-grid");
			const chancel = j_option.find("chancel-grid");

			const text_speed_slider = text_speed.find(".slider-content");
			const skip_all = text_skip.find("option-button-grid").eq(0);
			const skip_readed = text_skip.find("option-button-grid").eq(1);
			const auto_wait_slider = auto_wait.find(".slider-content");
			const bgm_volume_slider = bgm_volume.find(".slider-content");
			const se_volume_slider = se_volume.find(".slider-content");
			const cursor_position_none = cursor_position.find("option-button-grid").eq(0);
			const cursor_position_memory = cursor_position.find("option-button-grid").eq(1);
			const screen_full = screen_mode.find("option-button-grid").eq(0);
			const screen_window = screen_mode.find("option-button-grid").eq(1);

			mist_temp.option_hover_targets = [
				text_speed,
				text_skip,
				auto_wait,
				bgm_volume,
				se_volume,
				cursor_position,
				screen_mode,
				reset,
				close,
				chancel,
			];

			mist_temp.option_focus_mode = false;

			if (mist_system.auto_speed_with_text == undefined) {
				mist_system.auto_speed_with_text = default_auto_speed_with_text;
			}
			if (mist_temp.config_is_full_screen == undefined) {
				mist_temp.config_is_full_screen = false;
			}

			const tempTextSpeed = TYRANO.kag.config.chSpeed;
			const tempTextSkip = TYRANO.kag.config.unReadTextSkip;
			const tempAutoSpeed = mist_system.auto_speed_with_text;
			const tempBgmVolume = getSystemBgmVolume();
			const tempSeVolume = getSystemSeVolume();
			const tempIsSaveCursor = mist_system.config_is_save_cursor;
			const tempIsFullScreen = mist_temp.config_is_full_screen;

			resetSelectFocusView();

			
			setSlider(text_speed, sliderFromTextSpeed(that.kag.config.chSpeed), 1,
				(value) => {
					setConfigDelay(textSpeedFromSlider(value));
					showTestText($(".option_display_speed_text"), test_text, test_text_color);
				},
				function() {
					text_speed_select_line.addClass("select");
					mist_temp.optionFocusManager.setLastIndex(0);
				},
				function() {
					text_speed_select_line.removeClass("select");
				}
			);
			
			showTestTextTimeId = setTimeout(function () {
				showTestText($(".option_display_speed_text"), test_text, test_text_color);
			}, 100);

			
			setSelectButton(text_skip, text_skip_select_line,
				 TYRANO.kag.config.unReadTextSkip == "true",
				 TYRANO.kag.config.unReadTextSkip == "false",
				 setUnReadSkip,
				 1,
				 2);
			
			
			setSlider(auto_wait, mist_system.auto_speed_with_text, 10,
				(value) => {
					setAutoSpeedWithText(value);
				},
				() => {
					auto_wait_select_line.addClass("select");
					mist_temp.optionFocusManager.setLastIndex(3);
				},
				() => {
					auto_wait_select_line.removeClass("select");
				}
			);
			
			
			setSlider(bgm_volume, getSystemBgmVolume(), 10,
				(value) => {
					setBgmVolume(value, true);
				},
				() => {
					bgm_volume_select_line.addClass("select");
					mist_temp.optionFocusManager.setLastIndex(4);
				},
				() => {
					bgm_volume_select_line.removeClass("select");
				}
			);

			
			setSlider(se_volume, mist_system.se_volume, 10,
				(value) => {
					setSeVolume(value, true)
				},
				() => {
					se_volume_select_line.addClass("select");
					mist_temp.optionFocusManager.setLastIndex(5);
				},
				() => {
					se_volume_select_line.removeClass("select");
				},
			);

			
			setSelectButton(cursor_position, cursor_position_select_line,
				!mist_system.config_is_save_cursor,
				mist_system.config_is_save_cursor,
				(b) => mist_system.config_is_save_cursor = !b,
				6,
				7);

			
			setSelectButton(screen_mode, screen_mode_select_line,
				mist_temp.config_is_full_screen,
				!mist_temp.config_is_full_screen,
				(b) => {
					if (b & !mist_temp.config_is_full_screen) {
						
						mist_temp.config_is_full_screen = true;
						that.screenFull();
					}
					if (!b && mist_temp.config_is_full_screen) {
						
						mist_temp.config_is_full_screen = false;
						that.screenFull();
					}
				},
				8,
				9);

			
			const reset_focus = reset.find("item-name")
			reset_focus.click(() => {
				

				
				
				
				const default_text_speed = 2;
				setConfigDelay(textSpeedFromSlider(default_text_speed));
				UpdateSlider(text_speed, default_text_speed);

				setUnReadSkip(true);
				setOptionButtonSelect(skip_all, true);
				setOptionButtonSelect(skip_readed, false);

				setAutoSpeedWithText(default_auto_speed_with_text);
				UpdateSlider(auto_wait, default_auto_speed_with_text);

				setBgmVolume(getDefaultBgmVolume(), true);
				UpdateSlider(bgm_volume, getDefaultBgmVolume());

				setSeVolume(getDefaultSeVolume(), true);
				UpdateSlider(se_volume, getDefaultSeVolume());

				mist_system.config_is_save_cursor = true;
				setOptionButtonSelect(cursor_position_none, !mist_system.config_is_save_cursor);
				setOptionButtonSelect(cursor_position_memory, mist_system.config_is_save_cursor);

				setOptionButtonSelect(screen_full, false);
				setOptionButtonSelect(screen_window, true);
				if (mist_temp.config_is_full_screen) {
					mist_temp.config_is_full_screen = false;
					that.screenFull();
				}

				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
				mist_temp.is_hover_on = true;
			});
			
			reset_focus.hover(() => {
				setSelectFocus(reset, true);
				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
				mist_temp.optionFocusManager.setLastIndex(10);
			}, () => {
				if (mist_temp.is_hover_on) {
					reset_focus.trigger("mouseover");
					mist_temp.is_hover_on = false;
					return;
				}
				setSelectFocus(reset, false);
			});

			
			const cancel_focus = chancel.find("item-name")
			cancel_focus.click(() => {
				
				TYRANO.kag.config.chSpeed = tempTextSpeed;
				TYRANO.kag.config.unReadTextSkip = tempTextSkip;
				setAutoSpeedWithText(tempAutoSpeed);
				setBgmVolume(tempBgmVolume, true);
				setSeVolume(tempSeVolume, true);
				mist_system.config_is_save_cursor = tempIsSaveCursor;

				if (mist_temp.config_is_full_screen != tempIsFullScreen) {
					mist_temp.config_is_full_screen = tempIsFullScreen;
					that.screenFull();
				}

				console.log("cancel");
				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys01.mp3", stop: true });
				closeOption(layer_menu, is_menu, cb);
			});
			
			cancel_focus.hover(() => {
				setSelectFocus(chancel, true);
				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
				mist_temp.optionFocusManager.setLastIndex(11);
			}, () => {
				setSelectFocus(chancel, false);
			});

			
			const clsoe_focus = close.find("item-name")
			clsoe_focus.click(() => {
				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
				closeOption(layer_menu, is_menu, cb);
			});
			
			clsoe_focus.hover(() => {
				setSelectFocus(close, true);
				TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
				mist_temp.optionFocusManager.setLastIndex(12);
			}, () => {
				setSelectFocus(close, false);
			});
			
            
            if(!mist_system.FooterContainer.isMarking()){
                mist_system.FooterContainer.mark();
            }
			
            const footer_display_data = {
                help_text:getCommonHelpDirect("option"),
				is_visible_close_button_q_key:true,
                close_event_q_key:function(e){
					e.stopPropagation();
					cancel_focus.click();
                },
				is_visible_system: showFooterSystem,
            };
            mist_system.FooterContainer.showMenuFooter(footer_display_data);

			that.setMenu(j_option, cb);

			pauseSe();

			setFlagStopGameProgress(true);
			mist_temp.optionNowStopping = TYRANO.kag.stat.is_strong_stop;
			
			if(!mist_temp.optionNowStopping) {
				
				
				mist_temp.optionCallNextOrder = TYRANO.kag.stat.is_adding_text;
				stopGameProgress();
			}

			
			
			
			const focus_list = [
				text_speed_slider,			
				skip_all,					
				skip_readed,				
				auto_wait_slider,			
				bgm_volume_slider,			
				se_volume_slider,			
				cursor_position_none,		
				cursor_position_memory,		
				screen_full,				
				screen_window,				
				reset_focus,				
				cancel_focus,				
				clsoe_focus,				
			];
			const focus_index_list = [
				[10, 1, -1, -1],	
				[0, 3, 2, 2],		
				[0, 3, 1, 1],		
				[1, 4, -1, -1],		
				[3, 5, -1, -1],		
				[4, 6, -1, -1],		
				[5, 8, 7, 7],		
				[5, 8, 6, 6],		
				[6, 10, 9, 9],		
				[6, 10, 8, 8],		
				[8, 0, 12, 11],		
				[8, 0, 10, 12],		
				[8, 0, 11, 10],		
			];
			mist_temp.optionFocusManager = new FocusManager("option", focus_list, focus_index_list);
		}
	);
}

function setSlider(item_grid, value, add_value, SetValue, hover_on_callback = null, hover_off_callback = null)
{
	const slider = item_grid.find(".slider-content");
	const back_slider = item_grid.find("back-slider");
	const active_slider = item_grid.find("active-slider");

	const min = slider.attr("min");
	const max = slider.attr("max");

	UpdateSlider(item_grid, value);

	slider.on("mousedown", (event) => {
		mist_temp.is_hover_on = true;
		mist_temp.is_slider_mouse_down = true;
	});
	slider.on("mouseup", (event) => {
		mist_temp.is_slider_mouse_down = false;
	});
	slider.on("input", (event) => {
		UpdateSlider(item_grid, slider.val());
		SetValue(parseInt(slider.val()));
		TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys16.mp3", stop: true });
		if (!mist_temp.is_slider_mouse_down) {
			mist_temp.is_hover_on = true;
		}
	});
	slider.hover(() => {
		leftClickCallback = () => {
			const temp = parseInt(slider.val());
			if (temp > min)
				UpdateSlider(item_grid, temp - add_value);
			SetValue(parseInt(slider.val()));
			TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys16.mp3", stop: true });
		}
		rightClickCallback = () => {
			const temp = parseInt(slider.val());
			if (temp < max)
				UpdateSlider(item_grid, temp + add_value);
			SetValue(parseInt(slider.val()));
			TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys16.mp3", stop: true });
		}
	}, () => {
		leftClickCallback = undefined;
		rightClickCallback = undefined;
	});

	item_grid.hover(function() {
		if (hover_on_callback != null) {
			hover_on_callback();
		}
		TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
		back_slider.css("height", "16px");
		active_slider.css("height", "14px");
		slider.css('--slider-thumb-size', '70px');
	}, function() {
		if (mist_temp.is_hover_on) {
			item_grid.trigger("mouseover");
			mist_temp.is_hover_on = false;
			return;
		}
		if (hover_off_callback != null) {
			hover_off_callback();
		}
		back_slider.css("height", "12px");
		active_slider.css("height", "10px");
		slider.css('--slider-thumb-size', "54px");
	});

	item_grid.click(function(e) {
		
		if(tyrano.plugin.kag.key_mouse.vmouse.is_visible ||
			$("html").hasClass("mouse_disable")) {
			mist_temp.is_hover_on = true;
			return;
		}
		
		const option_window = $("option-window")[0];
		const window_base_width = option_window.clientWidth;
		const window_width = option_window.getBoundingClientRect().width;
		const rate = window_width / window_base_width;

		const cr = this.getBoundingClientRect();
		const click_x = e.pageX - cr.left;
		const left_pos = 616 * rate;
		const right_pos = 1240  * rate;
		if (click_x <= left_pos) {
			const temp = parseInt(slider.val());
			if (temp > min) {
				UpdateSlider(item_grid, min);
				SetValue(min);
			}
		}
		if (click_x >= right_pos) {
			const temp = parseInt(slider.val());
			if (temp < max) {
				UpdateSlider(item_grid, max);
				SetValue(max);
			}
		}
	});
}

function UpdateSlider(item_grid, value) {
	const slider = item_grid.find(".slider-content");
	const active_slider = item_grid.find("active-slider");
	const value_text = item_grid.find("value-text");

	const min = slider.attr("min");
	const max = slider.attr("max");
	value = Math.max(Math.min(value, max), min)

	const width =  600 * (value - min) / (max - min);
	active_slider.css({width: width + "px"});
	slider.val(value);
	if (value_text != null) {
		value_text.text(value);
	}
}
function setSelectFocus(elem, is_focus)
{
	if (elem.length == 0) return;

	const select_line = elem.find("select-line");
	const select_cursor = elem.find("select-cursor");
	const select_text = elem.find("item-name");

	Common.setVisible(select_line, is_focus);
	Common.setVisible(select_cursor, is_focus);
	if (is_focus) {
		select_text.addClass("selected-white-back");
	}
	else {
		select_text.removeClass("selected-white-back");
	}
}
function resetSelectFocusView() {
	mist_temp.option_hover_targets.forEach((elem) => setSelectFocus(elem, false));
	var none_object = $("select-line");
	none_object.removeClass("select");
}


function setOptionButtonEvent(elem, is_active, click_callback, hover_on_callback = null, hover_off_callback = null)
{
	if (elem.length == 0) return;
	const select_object = elem.find("option-button-select");
	const none_object = elem.find("option-button-none");

	Common.setVisible(select_object, is_active);
	elem.click((e) => {
		e.stopPropagation();
		Common.setVisible(select_object, true);
		if (click_callback != null) {
			click_callback();
		}
		TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys16.mp3", stop: true });
		mist_temp.is_hover_on = true;
	});
	
	elem.hover(function() {
		none_object.addClass("hover");
		if (hover_on_callback != null) {
			hover_on_callback();
		}
		TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
	}, function() {
		if (mist_temp.is_hover_on) {
			elem.trigger("mouseover");
			return;
		}
		none_object.removeClass("hover");
		if (hover_off_callback != null) {
			hover_off_callback();
		}
	});
}

function setOptionButtonSelect(elem, is_active)
{
	if (elem.length == 0) return;
	const select_object = elem.find("option-button-select");

	Common.setVisible(select_object, is_active);
}

function setConfigDelay(speed)
{
	TYRANO.kag.stat.ch_speed = "";
	TYRANO.kag.config.chSpeed = speed;
	TYRANO.kag.variable.sf._config_ch_speed = speed;
}

function setAutoSpeed(speed)
{
	TYRANO.kag.config.autoSpeed = speed;
	TYRANO.kag.variable.sf._system_config_auto_speed = speed;
}

function setUnReadSkip(skip)
{
    if(skip){
        TYRANO.kag.config.unReadTextSkip = "true";
    }else{
        TYRANO.kag.config.unReadTextSkip = "false";
    }
    TYRANO.kag.variable.sf._system_config_unread_text_skip = TYRANO.kag.config.unReadTextSkip;
}

function pauseBgm()
{
	var map_bgm = TYRANO.kag.tmp.map_bgm;
	for (key in map_bgm) {
		if (map_bgm[key]) {
			map_bgm[key].pause();
		}
	}
}
function resumeBgm()
{
	var map_bgm = TYRANO.kag.tmp.map_bgm;
	for (key in map_bgm) {
		if (map_bgm[key]) {
			map_bgm[key].play();
		}
	}
}
function pauseSe()
{
	var map_se = TYRANO.kag.tmp.map_se;
	for (key in map_se) {
		if (map_se[key]) {
			map_se[key].pause();
		}
	}
}

function resumeSe() {
	var map_se = TYRANO.kag.tmp.map_se;
	test_exist = false;
	for (key in map_se) {
		if (key == "option_test") {
			map_se[key].pause();
			map_se[key].unload();
			test_exist = true;
		}
		else if (map_se[key] && map_se[key]._loop) { 
			map_se[key].play();
		}
	}
	if (test_exist) {
		delete TYRANO.kag.tmp.map_se["option_test"];
	}
}

function showTestText(jtext, message_str, color) {
	if (!optionVariable.isAnimation) {
		return;
	}

	
	if (optionVariable.showTestTextTimeId >= 0) {
		clearTimeout(optionVariable.showTestTextTimeId);
		optionVariable.showTestTextTimeId = -1;
	}

	var that = TYRANO;
	if (jtext.html() == "") {
		
		jtext.append("<p class=''></p>");
	}

	var current_str = "";

	if (jtext.find("p").find(".test_span").length != 0) {
		
		jtext.find("p").find(".test_span").find("span").css({
			"opacity": 1,
			"visibility": "visible",
			"animation": ""
		});
	}

	if (jtext.find(".test_span").length == 0) {
		jtext.find("p").append($("<span class='test_span'></span>"));
	}

	
	var j_span = {};
	j_span = jtext.find("p").find(".test_span");
	j_span.css({
		"color": color,
		"font-weight": that.kag.stat.font.bold,
		"font-size": that.kag.stat.font.size + "px",
		"font-family": that.kag.stat.font.face,
		"font-style": that.kag.stat.font.italic
	});

	if (that.kag.stat.font.edge != "") {
		var edge_color = that.kag.stat.font.edge;
		j_span.css("text-shadow", "1px 1px 0 " + edge_color + ", -1px 1px 0 " + edge_color + ",1px -1px 0 " + edge_color + ",-1px -1px 0 " + edge_color + "");

	} else if (that.kag.stat.font.shadow != "") {
		j_span.css("text-shadow", "2px 2px 2px " + that.kag.stat.font.shadow);
	}


	
	if (that.kag.config.autoRecordLabel == "true") {

		if (that.kag.stat.already_read == true) {
			
			if (that.kag.config.alreadyReadTextColor != "default") {
				j_span.css("color", $.convertColor(that.kag.config.alreadyReadTextColor));
			}

		} else {
			
			if (that.kag.config.unReadTextSkip == "false") {
				that.kag.stat.is_skip = false;
			}
		}

	}

	var ch_speed = 30;

	if (that.kag.stat.ch_speed != "") {
		ch_speed = parseInt(that.kag.stat.ch_speed);
	} else if (that.kag.config.chSpeed) {
		ch_speed = parseInt(that.kag.config.chSpeed);
	}

	
	if (typeof that.kag.stat.font.effect == "undefined" || that.kag.stat.font.effect == "none") {
		that.kag.stat.font.effect = "";
	}

	
	var flag_in_block = true;
	if (that.kag.stat.font.effect == "" || that.kag.stat.font.effect == "fadeIn") {
		flag_in_block = false;
	}

	var append_str = "";
	for (var i = 0; i < message_str.length; i++) {
		var c = message_str.charAt(i);
		
		if (that.kag.stat.ruby_str != "") {
			c = "<ruby><rb>" + c + "</rb><rt>" + that.kag.stat.ruby_str + "</rt></ruby>";
			that.kag.stat.ruby_str = "";
		}


		if (c == " ") {
			append_str += "<span style='opacity:0'>" + c + "</span>";
		} else {

			if (that.kag.stat.mark == 1) {

				var mark_style = that.kag.stat.style_mark;
				c = "<mark style='" + mark_style + "'>" + c + "</mark>";

			} else if (that.kag.stat.mark == 2) {
				that.kag.stat.mark = 0;
			}

			if (flag_in_block) {
				append_str += "<span style='display:inline-block;opacity:0'>" + c + "</span>";
			} else {
				append_str += "<span style='opacity:0'>" + c + "</span>";
			}

		}
	}

	current_str += "<span>" + append_str + "</span>";

	
	jtext.find("p").find(".test_span").html(current_str);

	var append_span = j_span.children('span:last-child');
	var makeVisible = function (index) {

		if (that.kag.stat.font.effect != "") {

			append_span.children("span:eq(" + index + ")").on("animationend", function (e) {

				$(e.target).css({
					"opacity": 1,
					"visibility": "visible",
					"animation": ""
				});

			});

			append_span.children("span:eq(" + index + ")").css('animation', "t" + that.kag.stat.font.effect + ' ' + that.kag.stat.font.effect_speed + ' ease 0s 1 normal forwards');

		} else {
			append_span.children("span:eq(" + index + ")").css({ 'visibility': 'visible', 'opacity': '1' });
		}

	};
	var makeVisibleAll = function () {
		append_span.children("span").css({ 'visibility': 'visible', 'opacity': '1' });
	};

	var pchar = function (index) {
		if (!optionVariable.isAnimation) {
			return;
		}

		makeVisible(index);

		if (index <= message_str.length) {
			
			optionVariable.showTestTextTimeId = setTimeout(function () {
				pchar(++index);
			}, ch_speed);
		} else {
			
			optionVariable.showTestTextTimeId = setTimeout(function () {
				showTestText(jtext, message_str, color);
			}, 1000);
		}
	};

	pchar(0);
}

function sliderFromTextSpeed(speed) {
	return 4 - speed / 20;
}

function textSpeedFromSlider(slider_value) {
	const value = (4 - slider_value) * 20;
	return value <= 1 ? 1 : value;
}

function closeOption(layer_menu, is_menu, cb)
{
	
	mist_temp.optionFocusManager.unregisterFocus();
	
	
	if(!mist_temp.optionNowStopping) {
		restartGameProgress(mist_temp.optionCallNextOrder);
		mist_temp.optionCallNextOrder = false;
	}
	mist_temp.optionNowStopping = false;

	
	Common.saveSystem();

	setFlagStopGameProgress(false);

	
	if (is_menu){
		const container = $("option-root");
		container.empty();
		if (typeof cb == "function") {
			cb();
		}
		TYRANO.kag.menu.showMenu(2);
	} else {
		layer_menu.empty();
		layer_menu.hide();
		if (typeof cb == "function") {
			cb();
		}
		
		mist_system.FooterContainer.markBack();
	}
	
	if (TYRANO.kag.stat.visible_menu_button == true) {
		$(".button_menu").show();
	}

	
	if (optionVariable.showTestTextTimeId >= 0) {
		clearTimeout(optionVariable.showTestTextTimeId);
	}
	optionVariable.isAnimation = false;
	resumeSe();

    leftClickCallback = undefined;
    rightClickCallback = undefined;
}

function setSelectButton(elem,
	select_line_elem,
	is_active1, 
	is_active2,
	on_update,
	focus_index1,
	focus_index2) {
	const item1 = elem.find("option-button-grid").eq(0);
	const item2 = elem.find("option-button-grid").eq(1);

	elem.hover(() => {
		select_line_elem.addClass("select");
		TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys05.mp3", stop: true });
	}, () => {
		
		let isKey = false;
		if (mist_temp.optionFocusManager != undefined) {
			const index = mist_temp.optionFocusManager.getLastIndex();
			isKey = mist_temp.optionFocusManager.isKeyDownLeftRight() && 
				(index == focus_index1 || index == focus_index2);
		}
		if (mist_temp.is_hover_on || isKey) {
			elem.trigger("mouseover");
			mist_temp.is_hover_on = false;
			return;
		}

		select_line_elem.removeClass("select");
	});

	setOptionButtonEvent(item1,
		is_active1,
		() => {
			on_update(true);
			setOptionButtonSelect(item2, false);
		},
		() => {
			mist_temp.optionFocusManager.setLastIndex(focus_index1);
		}
	);
	setOptionButtonEvent(item2,
		is_active2,
		() => {
			on_update(false);
			setOptionButtonSelect(item1, false);
		},
		() => {
			mist_temp.optionFocusManager.setLastIndex(focus_index2);
		}
	);

	elem.click(function(e) {
		if(tyrano.plugin.kag.key_mouse.vmouse.is_visible ||
			$("html").hasClass("mouse_disable")) {
			return;
		}

		const option_window = $("option-window")[0];
		const window_base_width = option_window.clientWidth;
		const window_width = option_window.getBoundingClientRect().width;
		const rate = window_width / window_base_width;

		const cr = this.getBoundingClientRect();
		const click_x = e.pageX - cr.left;
		const left_pos = 650 * rate;
		const right_pos = 1206  * rate;
		if (click_x <= left_pos) {
			on_update(true);
			setOptionButtonSelect(item1, true);
			setOptionButtonSelect(item2, false);
			TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys16.mp3", stop: true });
		}
		if (click_x >= right_pos) {
			on_update(false);
			setOptionButtonSelect(item1, false);
			setOptionButtonSelect(item2, true);
			TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys16.mp3", stop: true });
		}
	});
}

function applyAutoSpeedWithText() {
	const default_auto_speed_with_text = 50;
	if (mist_system.auto_speed_with_text == undefined) {
		mist_system.auto_speed_with_text = default_auto_speed_with_text;
	}
	setAutoSpeedWithText(mist_system.auto_speed_with_text);
}

function setAutoSpeedWithText(value) {
	mist_system.auto_speed_with_text = value;
	TYRANO.kag.config.autoSpeedWithText = value;
}

function applyBgmVolume() {
    setBgmVolume(getSystemBgmVolume(), true);
}

function setTempBgmVolume(volume) {
	mist_save.temp_bgm_volume = Common.clamp(volume, 0, 100);
	setBgmVolume(getSystemBgmVolume(), true);
}

function setBgmVolume(volume, effect)
{
	
	var map_bgm = TYRANO.kag.tmp.map_bgm;
	const play_volume = volume * getSystemBgmTempVolume() / 100;

	TYRANO.kag.stat.map_bgm_volume = {};
	TYRANO.kag.config.defaultBgmVolume = play_volume;
	mist_system.bgm_volume = volume;

	
	if (effect && !TYRANO.kag.define.FLAG_APRI) {
		var new_volume = play_volume / 100.0;
		for (key in map_bgm) {
			if (map_bgm[key]) {
				map_bgm[key].volume(new_volume);
			}
		}
	}
	TYRANO.kag.variable.sf._system_config_bgm_volume = play_volume;
}

function applySeVolume() {
	setSeVolume(getSystemSeVolume(), true);
}

function setTempSeVolume(volume) {
	mist_save.temp_se_volume = Common.clamp(volume, 0, 100);
	setSeVolume(getSystemSeVolume(), true);
}

function setTempSeBufVolume(volume, buf) {
	if (mist_save.temp_se_buf_volume == undefined) {
		mist_save.temp_se_buf_volume = {};
	}
	mist_save.temp_se_buf_volume[buf] = Common.clamp(volume, 0, 100);
	setSeVolume(getSystemSeVolume(), true);
}

function resetTempSeBufVolume() {
	mist_save.temp_se_buf_volume = {};
	setSeVolume(getSystemSeVolume(), true);
}

function setSeVolume(volume, effect)
{
	if (mist_save.temp_se_volume == undefined) {
		mist_save.temp_se_volume = 100;
	}
	if (mist_save.temp_se_buf_volume == undefined) {
		mist_save.temp_se_buf_volume = {};
	}

	var map_se = TYRANO.kag.tmp.map_se;
	const play_volume = volume * mist_save.temp_se_volume / 100;

	TYRANO.kag.config.defaultSeVolume = play_volume;
	mist_system.se_volume = volume;

	TYRANO.kag.stat.map_se_volume = {};
	for (const key in mist_save.temp_se_buf_volume) {
		const buf_volume = volume * mist_save.temp_se_buf_volume[key] / 100;
		TYRANO.kag.stat.map_se_volume[key] = buf_volume;
	}

	
	if (effect && !TYRANO.kag.define.FLAG_APRI) {
		var new_volume = play_volume / 100.0;
		for (key in map_se) {
			if (map_se[key]) {
				map_se[key].volume(new_volume);
			}
		}

		
		for (const key in mist_save.temp_se_buf_volume) {
			const buf_volume = (volume * mist_save.temp_se_buf_volume[key] / 10000);
			map_se[key].volume(buf_volume);
		}
	}

	TYRANO.kag.variable.sf._system_config_se_volume = play_volume;
}

function getDefaultBgmVolume() {
	return 50;
}

function getDefaultSeVolume() {
	return 50;
}

function getSystemBgmVolume() {
	if (mist_system.bgm_volume == undefined) {
		mist_system.bgm_volume = getDefaultBgmVolume();
	}
	return mist_system.bgm_volume;
}

function getSystemSeVolume() {
	if (mist_system.se_volume == undefined) {
		mist_system.se_volume = getDefaultSeVolume();
	}
	return mist_system.se_volume;
}

function getSystemBgmTempVolume() {
	if (mist_save.temp_bgm_volume == undefined) {
		mist_save.temp_bgm_volume = 100;
	}
	return mist_save.temp_bgm_volume;
}
