DetectiveCommonCondition = class{
}

function setupDetectiveCommonConditionMaster(data){
	var tmp = JSON.parse(data)
	detective_common_condition = {};
	tmp.forEach(function(item, index, array) {
		let data = Object.assign(new DetectiveCommonCondition(), item);
		if(data && data.value){ data.value = Common.convertDict(data.value); }

		if(!detective_common_condition[data.name]){ detective_common_condition[data.name] = []; }
		detective_common_condition[data.name].push(data);
	});
}

function getDetectiveCommonConditionMaster(){
	return detective_common_condition;
}

function getDetectiveCommonCondition(name){
	if(!detective_common_condition[name]){ return null; }
	return detective_common_condition[name];
}
