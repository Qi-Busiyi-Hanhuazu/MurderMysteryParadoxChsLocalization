CommonCondition = class{
}

function setupCommonConditionMaster(data){
	var tmp = JSON.parse(data)
	common_condition_dict = {};
	tmp.forEach(function(item, index, array) {
		let data = Object.assign(new CommonCondition(), item);
		if(data && data.value){ data.value = Common.convertDict(data.value); }
		if(!common_condition_dict[data.name]){ common_condition_dict[data.name] = []; }
		common_condition_dict[data.name].push(data);

	});
}

function getCommonConditionMaster(){
	return common_condition_dict;
}

function getCommonConditionChapter(name){
	if(typeof common_condition_dict == 'undefined'){ return null; }
	if(!common_condition_dict[name]){ return null; }
	return common_condition_dict[name];
}
