
PieceConvincing = class{
}

function generatePieceConvincingKey(doubt_id, slot_index, piece_id){
	return "{0}_{1}_{2}".format(doubt_id, slot_index, piece_id); 
}

function setupPieceConvincing(data){
	var tmp = JSON.parse(data)
	
	
	
	
	
	piece_convincing_dict = {};
	tmp.forEach(function(item, index, array) {
		let data = Object.assign(new PieceConvincing(), item);
		if(!piece_convincing_dict[data.doubt_id]){ piece_convincing_dict[data.doubt_id] = []; }
		data.desc = Common.replaceDefineColorString(data.desc);
		piece_convincing_dict[data.doubt_id].push(data);
	});
}

function getPieceConvincing(doubt_id, slot_index, piece_id, answer_pieces){
	data_list = piece_convincing_dict[doubt_id];
	if(!data_list){
		
		return getDetectiveConvinceNoMathValue();
	}
	const slot_key = `slot_index_${slot_index}`;
	let convincing_list = data_list.filter((d) => {
		if(!d[slot_key]){ return ; }
		keys = d[slot_key].replace(/\s+/g, "").split('or')
		return keys.includes(piece_id);
	});
	
	const slot_any = data_list[0]['slot_any_sole'];
	if(slot_any){
		const keys = slot_any.replace(/\s+/g, "").split('or');
		if(keys.includes(piece_id)){
			
			convincing_list = [piece_id];

			const used_slot_any_pieces = answer_pieces.filter(ap => keys.includes(ap));
			if(used_slot_any_pieces && used_slot_any_pieces.length > 0){
				
				convincing_list = [];
			}
		}
	}

	if(!convincing_list || !convincing_list.length){
		
		return getDetectiveConvinceNoMathValue();
	}
	
	return getDetectiveConvinceMathValue();
}

function getgetPieceConvincingTitleDesc(doubt_id, piece_ids){
	data_list = piece_convincing_dict[doubt_id];
	if(!data_list){
		return null;
	}

	let convincing_list = data_list;
	piece_ids.forEach(function(piece_id, index){
		const slot_key = `slot_index_${index}`;
		const answer_pieces = piece_ids.slice(0, index); 
		convincing_list = convincing_list.filter((d) => {
			
			if(!d[slot_key]) { return ; }
			keys = d[slot_key].replace(/\s+/g, "").split('or')

			
			const slot_any = d['slot_any_sole'];
			if(slot_any){
				const keys = slot_any.replace(/\s+/g, "").split('or');
				if(keys.includes(piece_id)){
					
					convincing_list = [piece_id];
					const used_slot_any_pieces = answer_pieces.filter(ap => keys.includes(ap));
					if(used_slot_any_pieces && used_slot_any_pieces.length > 0){
						
					}else{
						return true; 
					}
				}
			}

			return keys.includes(piece_id);
		});
	})
	if(!convincing_list || !convincing_list.length){
		return null;
	}
	return convincing_list[0];
}
