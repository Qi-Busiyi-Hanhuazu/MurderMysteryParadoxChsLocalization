Cost = class{
  constructor(type, values){
    this.type = type;
	this.values = values;
  }
}

function setupCostMaster(data){
	var tmp = JSON.parse(data)
	cost_dict = {};
	tmp.forEach(function(item, index, array) {
		let cost = Object.assign(new Cost(), item);
		cost_dict[cost.type] = cost;
	});
}
