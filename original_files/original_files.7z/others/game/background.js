Background = class{

}

function setupBackgroundMaster(){
	
	TYRANO.kag.stat.f.debate_bg = getDebateBg();
	TYRANO.kag.stat.f.debate_blured_bg = getDebateBlurBg();
	TYRANO.kag.stat.f.vote_bg = getVoteBg();
	TYRANO.kag.stat.f.vote_blured_bg = getVoteBlurBg();
	TYRANO.kag.stat.f.detective_continue_bg = "";
}

function getDetectiveBg(){
	
	const bg = getCommonCondition(`bg_detective`);
	if(bg) { return bg.value.value; }
	return "black.png";
}

function getDebateBg(){
	return getCommonCondition(`bg_debate`).value.value;
}
function getDebateBlurBg(){
	return getCommonCondition(`bg_debate`).value.blur;
}

function getVoteBg(){
	return getCommonCondition(`bg_vote`).value.value;
}

function getVoteBlurBg(){
	return getCommonCondition(`bg_vote`).value.blur;
}

function getDetectiveContinueBg(){
	
	if (TYRANO.kag.stat.f.detective_continue_bg != "") {
		return TYRANO.kag.stat.f.detective_continue_bg;
	}
	return getCommonCondition(`bg_detective_continue`).value.value;
}

function getAdvContinueBg(){
	
	if (TYRANO.kag.stat.f.detective_continue_bg != "") {
		return TYRANO.kag.stat.f.detective_continue_bg;
	}
	const data = getCommonCondition(`bg_adv_continue`);
	if(data){
		return data.value.value;
	}
	return "";
}

