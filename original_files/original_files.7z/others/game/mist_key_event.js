
const mist_key_event = {
    
    keydown(e)
    {
        switch(e.keyCode)
        {
            case 90: 
                this.detectiveDebug();
                break;

            case 112: 
                this.switchDebugInfo();
                break;
        }
    },

    
    input_orders: [
        {
            
            
            getElem: () => {
                let elem = $(".remodal-wrapper:visible");
                if (elem.length == 0) return [];
                if (!Common.isFocusble(elem)) return [];
                return elem;
            },
        },

        {
            
            getElem: () => {
                let elem = $(".dialog:visible,chapter-confirm-window:visible,.dialog-piece-detail-close-button:visible,.backlog-dialog:visible");
                if (elem.length == 0) return [];
                if (!Common.isFocusble(elem)) return [];
                return elem;
            },
        },

        {
            
            
            
            
            
            
            getElem: () => {
                let elem = $(".help-container:visible,save-window:visible,option-root:visible");
                if (elem.length == 0) return [];
                if (!Common.isFocusble(elem)) return [];
                return elem;
            },
        },

        {
            
            getElem: () => {
                let elem = $(".layer_menu:visible");
                if (elem.length == 0) return [];
                if (!Common.isFocusble(elem)) return [];
                return elem;
            },
        },

        {
            
            getElem: () => {
                let elem = $("continue-container:visible");
                if (elem.length == 0) return [];
                if (!Common.isFocusble(elem)) return [];
                return elem;
            },
        },

        {
            
            getElem: () => {
                let elem = $("note-container2:visible");
                if (elem.length == 0) return [];
                if (!Common.isFocusble(elem)) return [];
                return elem;
            },
        },

        {
            
            getElem: () => {
                let elem = $("#tyrano_base:visible");
                if (elem.length == 0) return [];
                if (!Common.isFocusble(elem)) return [];
                return elem;
            },
        }
    ],

    
    event_debug_on: function() {},
    event_debug_off: function() {},
    setDebugEvent(on, off)
    {
        this.event_debug_on = on;
        this.event_debug_off = off;
    },
    detectiveDebug()
    {
        if (!mist_save.enable_debug) return;

        if ($(".debug_on").length == 0 && this.event_debug_on){
            this.event_debug_on();
        }else if($(".debug_off").length == 0 && this.event_debug_off){
            this.event_debug_off();
        }

        if ($(".debug_off").length)
        {
            $(".debug_off").switchClass("debug_off", "debug_on");
        }
        else
        {
            $(".debug_on").switchClass("debug_on", "debug_off");
        }
    },

    
    switchDebugInfo()
    {
        const elem = $("debug-info");
        if (elem.length == 0) return;
        if (!mist_save.enable_debug) {
            Common.setVisible(elem, false);
            return;
        }

        const isShow = Common.isVisible(elem);
        Common.setVisible(elem, !isShow);
    },
};


Common.on("keydown", (e) => {
    mist_key_event.keydown(e);
});



(function() {
    
    tyrano.plugin.kag.key_mouse.util.focused_selector = ":focus";

    
    const _esc_cancel = tyrano.plugin.kag.key_mouse.cancel;
    tyrano.plugin.kag.key_mouse.cancel = function () {
        const result = _esc_cancel.apply(TYRANO.kag.key_mouse);
        
        if (!result)
        {
            const button = $("close-button");
            if (button.length == 0 || !Common.isVisible(button)) return false;
            
            button.click();
            return true;
        }

        return result;
    };

    tyrano.plugin.kag.key_mouse.util.enableFocusTab = function(tabIndex) {
        if(tabIndex) {
            this.enableFocusTabIndecies = [];

            if(Array.isArray(tabIndex)) {
                this.enableFocusTabIndecies.concat(tabIndex);
            }
            else {
                this.enableFocusTabIndecies.push(tabIndex);
            }
        }
        else {
            this.enableFocusTabIndecies = undefined;
        }

    };
    
    tyrano.plugin.kag.key_mouse.util.findFocusable = function() {
        let j_buttons = [];

        
        for (let i = 0; i < mist_key_event.input_orders.length; ++i) {
            const elem = mist_key_event.input_orders[i].getElem();
            if (elem.length == 0) continue;
            
            j_buttons = elem.find("[tabindex].tyrano-focusable").filter(function() { return Common.isFocusble($(this)); });
            break;
        }
        

        if (j_buttons.length == 0) {
            return j_buttons;
        }
        const arr = [];
        j_buttons.each((i, elm) => {
            elm.__i = i;
            elm.__tabindex = parseInt($(elm).attr("tabindex")) || 0;
            if(!this.enableFocusTabIndecies || this.enableFocusTabIndecies.includes(elm.__tabindex)) {
                arr.push(elm);
            }
        });
        if (arr.length == 0) {
            return j_buttons;
        }
        arr.sort((a, b) => {
            if (a.__tabindex < b.__tabindex) return -1;
            else if (a.__tabindex > b.__tabindex) return 1;
            else {
                return a.__i < b.__i ? -1 : 1;
            }
        });
        const j_buttons_sorted = $(arr);
        return j_buttons_sorted;
    };

    
    tyrano.plugin.kag.key_mouse.util.focus = function(j_elm) {
        j_elm.get(0).focus(); 
        if (this.shouldDisplayFocusCursor()) {
            const rect = j_elm[0].getBoundingClientRect();
            
            let x = rect.left + rect.width / 2;
            let y = rect.top + rect.height / 2;
            
            this.parent.vmouse.place(x, y, 0);
            this.parent.vmouse.j_html.addClass("vmouse-displayed");
        } else {
            this.parent.vmouse.hide();
        }
    };

    
    tyrano.plugin.kag.key_mouse.hidemessage = function() {
        if (this.util.canShowMenu()) {
            if(mist_save.disable_hidemessage) {
                
                return false;
                
            }
            
            else if ($(".menu_close").length > 0 && $(".layer_menu").css("display") != "none") {
                
                return false;
                
            }
            else if (!this.kag.stat.is_strong_stop) {
                if (this.kag.stat.is_hide_message) {
                    this.kag.layer.showMessageLayers();
                } else {
                    this.kag.ftag.startTag("hidemessage");
                }
            }
            else {
                
                
                const is_hide = this.kag.stat.f.detective_mode
                    && $(".dialog:visible,chapter-confirm-window:visible,.dialog-piece-detail-close-button:visible").length === 0
                    && $("note-container2:visible").length === 0;
                if (is_hide) {
                    if (this.kag.stat.is_hide_message) {
                        this.kag.layer.showMessageLayers();
                    } else {
                        this.kag.ftag.startTag("hidemessage");
                    }
                }
                
            }
            TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys02.mp3", stop: true });
            return true;
        }
        return false;
    };
})();
