
function callSetEvent(funcStr, elem, pm){
	const SETEVENT_FUNC_MAP = {
		"setEventUpdateDialogCloseBtn": setEventUpdateDialogCloseBtn,
		"setSecretTalkSelectOption": setSecretTalkSelectOption
	}
	SETEVENT_FUNC_MAP[funcStr](elem, pm);
}

function setEventUpdateDialogCloseBtn(btn, callback = undefined, clickSe="system/se_sys05.mp3"){
	btn.on({
	    "click": function (e) {
			btn.off();
			
            e.stopPropagation();
            if(Boolean(TYRANO.kag.stat.f.close_click_target)){
                TYRANO.kag.ftag.startTag("jump",{target: TYRANO.kag.stat.f.close_click_target });
            }

			if(clickSe) {
				TYRANO.kag.ftag.startTag("PLAY_SE",{storage: clickSe, stop:true });
			}
	
	        $(".dialog-close-button").off("click");
	        $(".dialog-close-button").off("mouseenter");
	        $(".dialog-close-button").off("mouseleave");
			Common.clearDialogLayer();

			
			if(callback !== undefined) {
				callback();
			}
	    },
	    "mouseenter": function () {
			
			if($(".dialog-close-button").length > 0) {
				TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys05.mp3", stop:true });
			}
			
		},
	    "mouseleave": function () {}
	});
	Common.makeFocusable(btn);
	Common.setFocus(btn);
}

function setSecretTalkSelectOption(select, pm){
	let selection = [];
	if (mist_temp.secret_talk_select_list == undefined) {
		mist_temp.secret_talk_select_list = [
			undefined,
			undefined,
			undefined,
			undefined,
			undefined,
			undefined,
			undefined,
		];
	}
	mist_temp.secret_talk_select_list[pm.idx] = select;
	for(let id = 1; id < 6; id ++){ 
		const element_id = "#select{0}".format(id);
		if($(element_id).length){
			selection.push($(element_id));
		}
	}
    select.click(function (e) {
		if (mist_temp.is_tutorial) return;
		if (Common.isPreventSimultaneosKey()) return ;
		Common.addPreventScene("select");
        Common.unregisterWheel("SecretTalk");

        TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys02.mp3", stop:true });

        e.stopPropagation();
        Common.setVisible(select.find("cursor"), true);
        select.off();
        select.siblings().off();
        setTimeout(function(){
			switchSelectIdFunc(selection, pm.idx);
			
			if (pm.text) {
				mist_save.is_monologue = false;
				TYRANO.kag.pushBackLog("", `選択肢「${pm.text}」を選択した。`, "add", true);
				const full_name = Common.getDisplayNameToFullName("樹");
				TYRANO.kag.pushBackLog(full_name, pm.text, "add");
			}
	        if(TYRANO.kag.stat.f.enalbe_playlog && TYRANO.kag.stat.f.debate_topic){
	            if(!TYRANO.kag.stat.f.playlog_debate){TYRANO.kag.stat.f.playlog_debate = {};}
	            TYRANO.kag.stat.f.playlog_debate[TYRANO.kag.stat.f.debate_topic.id] = `${pm.idx},${pm.text}`;
	        }
			TYRANO.kag.ftag.startTag("eval",{exp: pm.exp });
			TYRANO.kag.ftag.startTag("jump",{target: pm.target });

			Common.removePreventScene();
		}, Common.durationSelected());
    });
    
    select.hover(function() {
		
		if($("note-container2").length > 0) {
			return;
		}
        $(this).addClass("select");
        $(this).find("icon").addClass("select");
        Common.setVisible($(this).find("line"), true);
        TYRANO.kag.ftag.startTag("PLAY_SE",{storage: "system/se_sys05.mp3", stop:true });
		mist_temp.secret_talk_container_last_select_index = pm.idx - 1;
    }, function() {
		
		if($("note-container2").length > 0) {
			return;
		}
        $(this).removeClass("select");
        $(this).find("icon").removeClass("select");
        Common.setVisible($(this).find("line"), false);
        Common.setVisible($(this).find("cursor"), false);
    });

	if (pm.idx - 1 == mist_temp.secret_talk_container_last_select_index) {
		Common.setFocus(select);
	}

	
	
	const scroll_target = $(".secret-talk-container");
	Common.registerWheel("SecretTalk", () => {
		Common.wheel(scroll_target, -100);
		return true;
	}, () => {
		Common.wheel(scroll_target, 100);
		return true;
	});

}
