
Character = class{
  constructor(id, name_id, criminal, player, disp_order, resource, face_lv0, face_lv1, face_lv2){
	this.id = id;
	this.name_id = name_id;
	this.credit_level = 0;
	this.criminal = criminal || false;
	this.player = player || false;
	this.disp_order = parseInt(disp_order);
	this.debate_credit_level = 0;
	this.resource = resource;
	this.face_lv0 = face_lv0;
	this.face_lv1 = face_lv1;
	this.face_lv2 = face_lv2;
  }

  toJSON = () => {
	return {
		id: this.id,
		credit_level: this.credit_level,
		credit_point: this.credit_point,
		debate_credit_level: this.debate_credit_level,
	}
  }
  deserialize(data){
	this.credit_level = data.credit_level;
	this.credit_point = data.credit_point;
	this.debate_credit_level = data.debate_credit_level;
  }

  setCredit(credit_info, credit_table){
	this.credit_table = credit_table;
	this.credit_info = credit_info;
	this.credit_level = Number(credit_info['init_level']);
	this.credit_point = Number(credit_info['init_point']);
	this.credit_level_str = credit_level_dict[this.credit_level];
  }
  getInitCreditLevel(){
	return this.credit_info['init_level'];
  }

  getCreditProgress() {
	return this.credit_point / this.credit_table[this.credit_info['type']][this.credit_level];
  }

  addCredit(point){
	if(parseInt(point) < 0){ console.error(`addCreditにマイナス値が渡されました。${this.name} ${point} addCreditは実行されませんでした`); return;}
	this.credit_point += parseInt(point);
	if(this.credit_point >= this.credit_table[this.credit_info['type']][this.credit_level] && this.credit_table[this.credit_info['type']][this.credit_level+1]){
		this.credit_level += 1;
		this.credit_point = 0;
		this.credit_level_str = credit_level_dict[this.credit_level];
		return true;
	}
	return false;
  }
  subCredit(point){
	if(parseInt(point) < 0){ console.error(`subCreditにマイナス値が渡されました。${this.name} ${point} subCreditは実行されませんでした`); return;}
	this.credit_point -= parseInt(point);
	if(this.credit_point < 0){ this.credit_point = 0; }
  }
  changeCreditLevel(level){
	level = parseInt(level);
	if(this.credit_table[this.credit_info['type']][level]){
		this.credit_level = level;
		this.credit_point = 0;
		this.credit_level_str = credit_level_dict[this.credit_level];
	}
  }

  beginDebate(){
    this.debate_credit_level = this.credit_level;
  }

  defaultFace(){
	const key = `face_lv${this.credit_level}`;
    return this[key];

  }

  setupName(player_id){
	this.nickname = masterdata.names[player_id][this.id];
	this.sysname = masterdata.names[this.name_id].sysname;
	this.name = masterdata.names[this.name_id].sysname;
  }

  doubtCount(){
    return getNextFreeDoubtCount(this.id);
  }

  
  creditInfo(){
	return this.name + "(信用Lv." + this.credit_level_str + ")";
  }

  getSecretBgm(){
	const cnt = notCompleteDoubtCount(this.id);
	let bgm = "";
	Object.keys(this.bgm).forEach((key) => {
		const [op, val] = key.split('_');
		if(op == "gt" && cnt >= val){ bgm = this.bgm[key];}
		if(op == "lt" && cnt <= val){ bgm = this.bgm[key];}
	});
	return bgm;
  }

  colorIndex(){
      return Number(this.disp_order);
  }
  doubtIconPath(){
      return `image/detective/icon/${this.doubt_icon_name}`;
  }

  isCriminal(){
      return this.criminal == "1";
  }

  getCreditDispLevel() {
      
      
      
      
      
      
      
      
    let credit_disp_level = this.credit_level * 2;
    if(this.getCreditProgress() >= 0.5) {
      credit_disp_level = credit_disp_level + 1;
    }
    credit_disp_level = Common.clamp(credit_disp_level, 0, 4);
    return credit_disp_level;
  }
}

CharacterTemporary = class extends Character {

  toJSON = () => {
	return {
		id: this.id,
		name_id: this.name_id,
		j_name: this.j_name,
	}
  }
  deserialize(data){
	this.id = data.id;
	this.name_id = data.name_id;
	this.j_name = data.j_name;
  }
}

function setupCharacterMaster(data){
	masterdata.characters = {};
	masterdata.characters_temp = {};
	var tmp = JSON.parse(data)
	tmp.forEach(function(item, index, array) {
		let char = Object.assign(new Character(), item);
		if(typeof char.name_id  === 'undefined'){ char.name_id = char.id; console.error(`キャラクタマスターのname_idの指定が必要 ${char.name}`);} 
		if(char.bgm != ""){
			char.bgm = Common.convertDict(char.bgm);
		}
		if(char.player == 1){
			TYRANO.kag.stat.f.player = char;
		}else{
			masterdata.characters[char.id] = char;
		}
	});

	
	const player_name_id = TYRANO.kag.stat.f.player.name_id; 
	Object.values(masterdata.characters).forEach(chara => chara.setupName(player_name_id));
	TYRANO.kag.stat.f.player.setupName(player_name_id);
}

function getPlayer(){
	return TYRANO.kag.stat.f.player;
}

function getCharacter(id){
	if(id == "NPC" || id == "npc"){
		id = TYRANO.kag.stat.f.npc_key;
	}
	return getAllCharacters().find(chr => chr.id === id);
}

function getCharacterByOwner(owner){
	return Object.values(masterdata.characters).find(chr => chr.name === owner);
}

function getCharacterByOwnerIncludePlayer(owner){
	if(owner == "自分" || owner == "樹") { return getPlayer(); } 
	return Object.values(masterdata.characters).find(chr => chr.name === owner);
}

function getCharacterList(){
	return Object.values(masterdata.characters)
}

function getAllCharacters(){
	let result = Object.values(masterdata.characters);
	result.unshift(TYRANO.kag.stat.f.player);
	if(Object.keys(masterdata.characters_temp).length !== 0){
		result = result.concat(Object.values(masterdata.characters_temp));
	}
	return result;
}


function getCharacterListForDebateStatement(){
	return Object.values(masterdata.characters).sort((a,b) => a.debate_credit_level - b.debate_credit_level);
}


function getCharacterListForDebate(){
	return Object.values(masterdata.characters).sort((a,b) => a.credit_level - b.credit_level);
}

function getCharacterListForVerdict(){
	
	let result = Object.values(masterdata.characters).sort((a,b) => b.credit_level - a.credit_level);
	result.unshift(TYRANO.kag.stat.f.player);
	return result
}

function setCreditLevel(chara_id, level){
	getCharacter(chara_id).changeCreditLevel(level);
}

function addCreditPoint(chara_id, point){
	getCharacter(chara_id).addCreditPoint(point);
}

function getNpcList(){
	let tmp = {};
	Object.values(masterdata.characters).forEach((obj) => {
		tmp[obj.id] = obj.name;
	});
	return tmp;
}

function getNpcListOrderedDisp(){
	return Object.values(masterdata.characters).sort((a,b) => a.disp_order - b.disp_order);
}

function getNpcListOrderedDispIndex(chara_id) {

	let dispOrder = Object.values(masterdata.characters).sort((a, b) => a.disp_order - b.disp_order);
	return dispOrder.findIndex((x) => x.id == chara_id) + 1;
}

function getOwner(npc_key){
	return getNpcList()[npc_key];
}

function setupCharacterCredit(){
	Object.values(masterdata.characters).forEach((obj) => {
		const credit = Common.convertDict(obj.credit);
		const credit_table = {'normal': {0: credit.lv0, 1:credit.lv1, 2:credit.lv2}};
   		let credit_data = {init_level:0,init_point:credit.point,type:'normal'};
		obj.setCredit(credit_data, credit_table);
	});
}

function saveCharacters(phase){
	TYRANO.kag.stat.f.saved_characters = TYRANO.kag.stat.f.saved_characters || {};
	TYRANO.kag.stat.f.saved_characters[phase] =  JSON.stringify(masterdata.characters);
	TYRANO.kag.stat.f.saved_characters_temporary = TYRANO.kag.stat.f.saved_characters_temporary || {};
	TYRANO.kag.stat.f.saved_characters_temporary[phase] =  JSON.stringify(masterdata.characters_temp);
}

function loadCharacters(phase){
	if(TYRANO.kag.stat.f.saved_characters == null || TYRANO.kag.stat.f.saved_characters[phase] == null){
		return ;
	}

	let tmp = JSON.parse(TYRANO.kag.stat.f.saved_characters[phase])
	Object.keys(tmp).forEach(function(key, index, array) {
		masterdata.characters[key].deserialize(tmp[key]);
	});

	if(TYRANO.kag.stat.f.saved_characters_temporary == null || TYRANO.kag.stat.f.saved_characters_temporary[phase] == null){
		return ;
	}
	tmp = JSON.parse(TYRANO.kag.stat.f.saved_characters_temporary[phase])
	Object.keys(tmp).forEach(function(key, index, array) {
		masterdata.characters_temp[key] = Object.assign(new CharacterTemporary(), tmp[key]);
	});
}

function beginDebateCharacters(){
	Object.values(masterdata.characters).forEach((obj) => {
		obj.beginDebate();
	});
}

function addTemporaryCharacter(id, name_id, j_name){
	const item = {id: id, name_id: name_id}
	let char = Object.assign(new CharacterTemporary(), item);
	char.setupName(TYRANO.kag.stat.f.player.name_id);
	char.j_name = j_name;

	masterdata.characters_temp[id] = char;
}

function getCreditDispLevelText(credit_disp_level) {
	const texts = [
		"警戒",
		"疑心",
		"中立",
		"信用",
		"信頼"
	];
	return texts[credit_disp_level];
}

