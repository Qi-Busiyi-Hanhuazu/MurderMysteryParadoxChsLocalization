

function initInventory(){
	TYRANO.kag.stat.f.player_pieces = {};
	TYRANO.kag.stat.f.player_pieces_orderd = [];
	TYRANO.kag.stat.f.player_talk_flags = {};
	TYRANO.kag.stat.f.player_active_doubts = {};
	TYRANO.kag.stat.f.player_resolved_doubts = {};
	TYRANO.kag.stat.f.player_doubts = [];
	TYRANO.kag.stat.f.player_doubts_new = {};
	TYRANO.kag.stat.f.player_show_inference_history = {};
	TYRANO.kag.stat.f.player_inferences = {};
	TYRANO.kag.stat.f.player_creating_inference = {};
	TYRANO.kag.stat.f.player_inference_count = {};
	TYRANO.kag.stat.f.player_inference_complete = {};
	TYRANO.kag.stat.f.player_pieces_npc_new = {};
	TYRANO.kag.stat.f.player_pieces_new = {};
	TYRANO.kag.stat.f.player_init_cost = 0;
	TYRANO.kag.stat.f.player_cost = 0;
	TYRANO.kag.stat.f.player_cost_history = 0;
    TYRANO.kag.stat.f.temp_player_cost = 0;
	TYRANO.kag.stat.f.player_happened_approach = {};

	TYRANO.kag.stat.f.detective_mode_normal = true;
	TYRANO.kag.stat.f.TimeWarning = "";
	TYRANO.kag.stat.f.player_persons = {};
    delete TYRANO.kag.stat.f.ending_file;
    TYRANO.kag.stat.f.disable_update_badge = 0;

    initVote();
    initPlaylog();
    updatePersonInfomations();

    initializeGameData();
}

function initPlaylog(){
    delete TYRANO.kag.stat.f.playlog_inference;
    delete TYRANO.kag.stat.f.playlog_debate;
    delete TYRANO.kag.stat.f.playlog_debate_doubt;
}




function temporaryClearPieces(){
    TYRANO.kag.stat.f.player_pieces_orderd = [];
}

function addInventory(id, chara_id){
	chara_id = chara_id || "";
	if(!getPiece(id)){
		console.error("Pieceマスタに定義されていないID=" + id + "がaddInventoryされています");
		return ;
	}
	TYRANO.kag.stat.f.player_pieces[id] = 1;
	if(!TYRANO.kag.stat.f.player_pieces_orderd.includes(id)){
		TYRANO.kag.stat.f.player_pieces_orderd.push(id);
	}


	TYRANO.kag.stat.f.player_pieces_new[id] = 1;
	Object.keys(getNpcList()).forEach((value) => {
		if(value != chara_id){
			if(!TYRANO.kag.stat.f.player_pieces_npc_new[value]){
				TYRANO.kag.stat.f.player_pieces_npc_new[value] = [];
			}
			if(TYRANO.kag.stat.f.player_pieces_npc_new[value].includes(id)){
				return ;
			}
			TYRANO.kag.stat.f.player_pieces_npc_new[value].push(id);
		}
	});
}

function getInventories(){
	
	return TYRANO.kag.stat.f.player_pieces_orderd;
	
	let array = Object.keys(TYRANO.kag.stat.f.player_pieces).map((k)=>(getPiece(k)));
	array.sort((a, b) => a.unixtime - b.unixtime);
	return array.map((k)=>(k.id));
}

function clearPiecesNew(id) {
	if (id in mist_save.player_pieces_new) {
		delete mist_save.player_pieces_new[id];
	}
}

function clearNpcPiecesNew(npc_key){
	TYRANO.kag.stat.f.player_pieces_npc_new[npc_key] = [];
}

function existsInventory(id){
	if(id == ""){	
		return true;
	}

	return TYRANO.kag.stat.f.player_pieces[id];
}

function notExistsInventory(id){
	return !existsInventory(id);
}

function pieceCount(){
	return Object.keys(TYRANO.kag.stat.f.player_pieces).length;
}

function doneTalk(id){
	TYRANO.kag.stat.f.player_talk_flags[id] = 1;
}
	
function alreadyTalked(id){
	return TYRANO.kag.stat.f.player_talk_flags[id];
}

function isAlreadyTalked(chara_id, piece_id){
    return alreadyTalked(`${chara_id}_${piece_id}`);
}

function alreadyExistDoubt(id){
	if(Object.values(TYRANO.kag.stat.f.player_active_doubts).findIndex(data => data.includes(id)) != -1){ return true; }
	if(Object.values(TYRANO.kag.stat.f.player_resolved_doubts).findIndex(data => data.includes(id)) != -1){ return true; }
	return false;
}

function addDoubt(id){
	if(alreadyExistDoubt(id)){
		console.error("既に入手済みの疑問が再入手されました" + id);
		return false;
	}
    TYRANO.kag.stat.f.player_doubts.push(id);
	chara_id = getDoubt(id).chara_id;
	if(!TYRANO.kag.stat.f.player_active_doubts[chara_id]){
		TYRANO.kag.stat.f.player_active_doubts[chara_id] = new Array();
	}
	if(TYRANO.kag.stat.f.player_active_doubts[chara_id].includes(id)){
		return false;
	}
	TYRANO.kag.stat.f.player_active_doubts[chara_id].push(id);
	
	mist_system.DetectiveContainer.updateBadge(chara_id);

	if (!TYRANO.kag.stat.f.player_doubts_new) { TYRANO.kag.stat.f.player_doubts_new = {}; }
	TYRANO.kag.stat.f.player_doubts_new[id] = 1;
    doneTalk(id);
    return true;
}



function hasDoubtNew(id) {
	if (!TYRANO.kag.stat.f.player_doubts_new) { TYRANO.kag.stat.f.player_doubts_new = {}; }
	return id in TYRANO.kag.stat.f.player_doubts_new;
}

function clearDoubtsNew(id) {
	if (!TYRANO.kag.stat.f.player_doubts_new) { TYRANO.kag.stat.f.player_doubts_new = {}; }
	if (id in mist_save.player_doubts_new) {
		delete mist_save.player_doubts_new[id];
	}
}

function existsActiveDoubt(chara_id){
	if(TYRANO.kag.stat.f.player_active_doubts[chara_id] && TYRANO.kag.stat.f.player_active_doubts[chara_id].length > 0){
		return TYRANO.kag.stat.f.player_active_doubts[chara_id][0];
	}
	return null;
}

function resolveDoubt(doubt){
	const id = doubt.id;
	const chara_id = doubt.chara_id;
	if(!TYRANO.kag.stat.f.player_resolved_doubts[chara_id]){
		TYRANO.kag.stat.f.player_resolved_doubts[chara_id] = new Array();
	}
	const index = TYRANO.kag.stat.f.player_active_doubts[chara_id].indexOf(id);
	if(index !== -1){
		TYRANO.kag.stat.f.player_resolved_doubts[chara_id].push(id);
		TYRANO.kag.stat.f.player_active_doubts[chara_id].splice(index, 1);
	}

	
	const key = '{0}_{1}'.format(doubt.id, doubt.getAnswerPieces().join('_'));
	TYRANO.kag.stat.f.player_show_inference_history[key] = 1;
}

function alreadyShowedInference(doubt){
	const key = '{0}_{1}'.format(doubt.id, doubt.getAnswerPieces().join('_'));
	return TYRANO.kag.stat.f.player_show_inference_history[key];
}

function getOwnerAvialableDoubtCount(chara_id){
	let result = 0;
	if(TYRANO.kag.stat.f.player_resolved_doubts[chara_id]){
		result += TYRANO.kag.stat.f.player_resolved_doubts[chara_id].length;
	}
	if(TYRANO.kag.stat.f.player_active_doubts[chara_id]){
		result += TYRANO.kag.stat.f.player_active_doubts[chara_id].length;
	}
	return result;
}

function latestResovledDoubt(chara_id){
	if(TYRANO.kag.stat.f.player_resolved_doubts[chara_id]){
		return TYRANO.kag.stat.f.player_resolved_doubts[chara_id].slice(-1)[0]
	}
	return "";
}

function getNextFreeDoubt(chara_id){
	const doubts = getOwnerDoubts(chara_id);
	const haveDoubts = getDoubtIds();
	const result = doubts.filter(doubt => !haveDoubts.includes(doubt.id) && checkDoubtCondtions(doubt.conditions));
	if(result.length > 0){
		return result[0];
	}
	return null;
}

function getNextFreeDoubtCount(chara_id) {
	const doubts = getOwnerDoubts(chara_id);
	const haveDoubts = getDoubtIds();
	const result = doubts.filter(doubt => !haveDoubts.includes(doubt.id) && checkDoubtCondtions(doubt.conditions));
	return result.length;
}

function getNotCompleteResolvedDoubtCount(chara_id) {
	if(chara_id in TYRANO.kag.stat.f.player_resolved_doubts == false){
		return 0;
	}
	return TYRANO.kag.stat.f.player_resolved_doubts[chara_id].filter(id => getDoubt(id).result == false).length;
}

function alreadySolvedDoubt(id){
	return getDoubt(id).solved;
}

function notAlreadySolvedDoubt(id){
	return !alreadySolvedDoubt(id);
}

function completeDoubt(id){
	return getDoubt(id).dispelled;
}

function notCompleteDoubt(id){
	return !completeDoubt(id);
}

function addInference(inference){
	TYRANO.kag.stat.f.player_inferences[inference.id] = inference;
}

function getInferenceKeys(){
	return Object.keys(TYRANO.kag.stat.f.player_inferences);
}

function startCreationInference(){
	TYRANO.kag.stat.f.player_creating_inference = {};
}

function addCreationInference(piece_id){
	TYRANO.kag.stat.f.player_creating_inference[piece_id] = 1;
}

function clearCreationInference(){
	TYRANO.kag.stat.f.player_creating_inference = {};
}

function getAvailableDoubtCount(npc_key){
	const dict_keys = Object.keys(TYRANO.kag.stat.f.player_pieces);
	let doubt_count = 0;
	
	dict_keys.forEach((value, index, thisArray) => {
	    let piece = getPiece(value);
		if(piece.chara_id != npc_key){
			let talkId = npc_key + "_" + piece.id;
			doubt_count += alreadyTalked(talkId) ? 0 : 1;
		}
	});
	return doubt_count;
}

function getDoubtIds(){
	let result = new Array();
	Object.keys(TYRANO.kag.stat.f.player_active_doubts).forEach((value, index, thisArray) => {
		TYRANO.kag.stat.f.player_active_doubts[value].forEach((doubt_id) => {
			if(!doubt_id){
				return ;
			}
			result.push(doubt_id);
		});
	});
	Object.keys(TYRANO.kag.stat.f.player_resolved_doubts).forEach((value) => {
	    const doubt_ids = TYRANO.kag.stat.f.player_resolved_doubts[value];
	    if(!doubt_ids){
	        return ;
	    }
		doubt_ids.forEach((value) => { result.push(value); });
	});
	return result;
}

function getDoubtAll(){
	let result = new Array();
	TYRANO.kag.stat.f.player_doubts.forEach(doubt_id => {
		result.push(getDoubt(doubt_id));
	});
	return result;
}


function getNotBuiltDoubtCount() {
	let count = 0;
	Object.values(TYRANO.kag.stat.f.player_active_doubts).forEach((doubts) => {
		if (!doubts) { return; }
		doubts.forEach((doubt_id) => {
			let doubt = getDoubt(doubt_id);
			if (!doubt.hasInference()) {
				count += 1;
			}
		});
	});
	return count;
}

function getDoubtCount(){
	let count = 0;
	Object.values(TYRANO.kag.stat.f.player_active_doubts).forEach((doubts) => {
		if(!doubts){ return ; }
		count += doubts.length
	});
	count += Object.values(TYRANO.kag.stat.f.player_resolved_doubts).length
	return count;
}

function getResolvedCount(){
	return Object.values(TYRANO.kag.stat.f.player_resolved_doubts).length;
}

function getResolvedDoubtIds(){
	let result = new Array();
	Object.keys(TYRANO.kag.stat.f.player_resolved_doubts).forEach((value) => {
	    const doubt_ids = TYRANO.kag.stat.f.player_resolved_doubts[value];
	    if(!doubt_ids){
	        return ;
	    }
		doubt_ids.forEach((value) => { result.push(value); });
	});
	return result;
}


function enableReportDoubtList(){
	let result = new Array();
	TYRANO.kag.stat.f.player_doubts.forEach(doubt_id => {
		if(!doubt_id){
			return ;
		}
		const d = getDoubt(doubt_id);
		if(d.hasInference()){
			result.push(d);
		}
	});
	return result;
}

function haveCost(){
	return TYRANO.kag.stat.f.player_cost > 0;
}


function initCost(cost){
	TYRANO.kag.stat.f.player_init_cost = cost;
	TYRANO.kag.stat.f.player_cost = cost;
	TYRANO.kag.stat.f.player_cost_history = 0;
}

function canConsumeCost(cost){
	cost = Number(cost);
	return TYRANO.kag.stat.f.player_cost >= cost;
}

function canActConsumeAfter(cost){
	cost = Number(cost);
	return (TYRANO.kag.stat.f.player_cost - cost) > 0;
}
function consumeCostTemp(cost){
	if (mist_save.temp_player_cost == 0) {
		mist_save.temp_player_cost = TYRANO.kag.stat.f.player_cost;
	}
	TYRANO.kag.stat.f.player_cost -= cost;
	if(TYRANO.kag.stat.f.player_cost < 0){  
		TYRANO.kag.stat.f.player_cost = 0;
	}
}
function consumeCost(cost){
	cost = Number(cost);
	const before_cost = TYRANO.kag.stat.f.player_cost;
	TYRANO.kag.stat.f.player_cost -= cost;
	if(TYRANO.kag.stat.f.player_cost < 0){  
		TYRANO.kag.stat.f.player_cost = 0;
	}
	TYRANO.kag.stat.f.player_cost_history = cost;

	recordConsumedCost(cost);

	getTimeWarning(before_cost, cost);

	if (mist_system.DetectiveContainer != undefined) {
		mist_system.DetectiveContainer.applyTime();
	}
}

function getCost(){
	return TYRANO.kag.stat.f.player_cost;
}

function getInitCost(){
	return TYRANO.kag.stat.f.player_init_cost;
}

function saveData(phase){
	saveDoubts(phase);
	saveCharacters(phase);
}

function loadData(phase){
	loadDoubts(phase);
	loadCharacters(phase);
}

function saveBeginDebate(){
	saveData("begin_debate");
}

function loadBeginDebate(){
	loadData("begin_debate");
}

function doDetectiveSave(){
	saveData("snapSave");
}

function doDetectiveLoad(){
	loadData("snapSave");
	setNpcName(getCharacter(mist_save.npc_key));
	
	if(mist_save.suspect_chara){
		mist_save.suspect_chara = getCharacter(mist_save.suspect_chara.id);
	}

	if(mist_save.secret_talk_now){
		mist_system.SecretTalkContainer.setEvent();
	}
}

function happendApproach(approach){

	TYRANO.kag.stat.f.block_happend_approach = approach.id;
	TYRANO.kag.stat.f.last_happend_approach = approach.id; 
	if(!TYRANO.kag.stat.f.player_happened_approach[approach.id]) { TYRANO.kag.stat.f.player_happened_approach[approach.id] = 0; }
	TYRANO.kag.stat.f.player_happened_approach[approach.id] += 1;
}

function enableHappenApproach(){
	TYRANO.kag.stat.f.block_happend_approach = null;
}

function alreadyHappenedApproach(approach_id){
	return TYRANO.kag.stat.f.player_happened_approach[approach_id];
}

function isNormalMode(){
	return TYRANO.kag.stat.f.detective_mode_normal == true;
}

function changeModeShortOfTime(){
	TYRANO.kag.stat.f.detective_mode_normal = false;
}

function recordConsumedCost(cost){
	Object.values(TYRANO.kag.stat.f.player_active_doubts).map(ids => ids.forEach(id => getDoubt(id).consumed_cost += cost));
}

function addPersonInfo(group, year){
    const player_persons = TYRANO.kag.stat.f.player_persons;
	if(!player_persons[group]){
        player_persons[group] = {is_new: true};
    }

    player_persons[group][year] = {is_new: true};
}

function existPersonInfo(group, year = ""){
    return Boolean(getPersonInfo(group, year));
}

function getPersonInfo(group, year = ""){
    const player_persons = TYRANO.kag.stat.f.player_persons;
    if(!player_persons[group]) { return null; }
    if(year){
        return player_persons[group][year];
    }else{
        return player_persons[group];
    }
}

function updatePersonInfomations(){
    for(const [chara_id, p]  of Object.entries(masterdata.note_person)){
        p.filter(i => i.disable_auto == "").forEach(i => addPersonInfo(i.group, i.year));
    }
}

function getPersonInfoMaster(group, year){
    return masterdata.note_person[group].filter(p => p.year ==year)[0];
}

function getInferenceCreateCount(doubt_id){
    if(!TYRANO.kag.stat.f.player_inference_complete) { TYRANO.kag.stat.f.player_inference_complete = {}; }
    if(!TYRANO.kag.stat.f.player_inference_count) { TYRANO.kag.stat.f.player_inference_count = {}; }
    if(!TYRANO.kag.stat.f.player_inference_count[doubt_id]) { TYRANO.kag.stat.f.player_inference_count[doubt_id] = 0; }
    if(TYRANO.kag.stat.f.player_inference_complete[doubt_id]) { return -1; }
    return TYRANO.kag.stat.f.player_inference_count[doubt_id];
}



function disableUpdateBadge(disable_badge=mist_system.DetectiveContainer.INVALIDATE_BADGE.ALL){
    mist_save.disable_update_badge |= disable_badge;
}

function disableUpdateInferenceBadge(){
    disableUpdateBadge(mist_system.DetectiveContainer.INVALIDATE_BADGE.INFERENCE);
}



function enableUpdateBadge(){
    mist_save.disable_update_badge = 0;
}



function updateAllInventryUI(){
	enableUpdateBadge();
	if (mist_system.DetectiveContainer != undefined) {
		mist_system.DetectiveContainer.applyTime();
		mist_system.DetectiveContainer.updateUI();
	}
}

function initializeGameData(){
    initApproachData();
	TYRANO.kag.stat.f.block_happend_approach = null;
    clearNpcName();
    initDebateData();

    TYRANO.kag.stat.f.npc_key = "";
    TYRANO.kag.stat.f.afterTalkFile = "";
    TYRANO.kag.stat.f.doubt_filter = null;
    TYRANO.kag.stat.f.conversations_flag
    TYRANO.kag.stat.f.continue_recomend
    TYRANO.kag.stat.f.doubt_id = "";
    TYRANO.kag.stat.f.lastTalkedCharaId
    TYRANO.kag.stat.f.talkedList = {};
    TYRANO.kag.stat.f.adv_file = "";
    TYRANO.kag.stat.f.newDoubt = false
    TYRANO.kag.stat.f.disable_update_badge = 0;

    Object.keys(TYRANO.kag.stat.f).filter(v => v.indexOf("_secret_count") > -1).forEach(key => delete TYRANO.kag.stat.f[key]);
}

