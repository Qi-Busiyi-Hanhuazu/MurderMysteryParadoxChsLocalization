Question = class{
}

function setupQuestionMaster(data){
	var tmp = JSON.parse(data)
	question_dict = {};
	tmp.forEach(function(item, index, array) {
		let o = Object.assign(new Question(), item);
		const id = `${o.target}_${o.item}`;
		question_dict[id] = o;
	});
}

function getQuestionMaster(){
	return question_dict;
}

function getQuestion(id){
	return question_dict[id];
}
