Guidance = class{
}

function setupGuidanceMaster(data){
	var tmp = JSON.parse(data)
	guidance_dict = {};
	tmp.forEach(function(item, index, array) {
		let guidance = Object.assign(new Guidance(), item);
		guidance.text = Common.replaceDefineColorString(guidance.text);
		if(!guidance_dict[guidance.phase]){ guidance_dict[guidance.phase] = []; }
		guidance_dict[guidance.phase].push(guidance);
	});
}

function getGuidanceMaster(){
	return guidance_dict;
}

function getGuidance(phase){
	return guidance_dict[phase];
}
