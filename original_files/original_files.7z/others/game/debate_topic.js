DebateTopic = class{
  constructor(id, chara_id, credit_level){
	this.id = id;
	this.chara_id = chara_id;
	this.credit_level = credit_level;
	this.require_convince_level = 1;
  }
}


function setupDebateTopicMaster(data){
	
	debate_topic_dict = {};
	var tmp_debate = JSON.parse(data);
	tmp_debate.forEach(function(item, index, array) {
	    let debate = Object.assign(new DebateTopic(), item);
	    debate_topic_dict[debate.id] = debate;
	});
}
