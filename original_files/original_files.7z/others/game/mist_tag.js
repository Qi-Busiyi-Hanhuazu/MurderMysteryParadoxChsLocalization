
TYRANO.kag.stat.select = {
    is_select: false, 
    readed_index: -1, 
    readed_id: "", 
};

TYRANO.kag.stat.is_reset_font_color = true;

TYRANO.kag.stat.message_id = 0;

function preparePlaySe(){
	if(TYRANO.kag.stat.f.preparedPlaySe){
		return ;
	}
	TYRANO.kag.stat.f.preparedPlaySe = true;
	TYRANO.kag.stat.f.current_playse_index = 0;
}

function playSeRoundrobin(file, stop, important){
	preparePlaySe();
	let count = 0;
    const is_important = important == "true";

    
    if(TYRANO.kag.tmp.important_se && TYRANO.kag.tmp.important_se.length > 0) {
        TYRANO.kag.tmp.important_se = TYRANO.kag.tmp.important_se.filter(x => x.playing());
    }

    
	while(TYRANO.kag.stat.current_se[TYRANO.kag.stat.f.current_playse_index] || (TYRANO.kag.tmp.important_se && TYRANO.kag.tmp.important_se.findIndex(x => x === TYRANO.kag.tmp.map_se[TYRANO.kag.stat.f.current_playse_index]) >= 0)) {
        TYRANO.kag.stat.f.current_playse_index = (TYRANO.kag.stat.f.current_playse_index + 1) % TYRANO.kag.config.defaultSoundSlotNum;
        count += 1;

        
        if(is_important) {
            if((TYRANO.kag.tmp.important_se && TYRANO.kag.tmp.important_se.findIndex(x => x === TYRANO.kag.tmp.map_se[TYRANO.kag.stat.f.current_playse_index]) >= 0)) {
                break;
            }
        }
        if(count >= TYRANO.kag.config.defaultSoundSlotNum) {
            
            
            if(stop == "false" && !TYRANO.kag.tmp.is_se_play_wait && !TYRANO.kag.tmp.important_se_wait) {
                TYRANO.kag.ftag.nextOrder();
            }
            return;
        }
    }

	TYRANO.kag.ftag.startTag("playse", {"storage":file, buf:TYRANO.kag.stat.f.current_playse_index,stop:stop});
    if(is_important) {
        
        if(!TYRANO.kag.tmp.important_se) {
            TYRANO.kag.tmp.important_se = []
        }
        const audio_obj = TYRANO.kag.tmp.map_se[TYRANO.kag.stat.f.current_playse_index];
        audio_obj.once("end", () => {
            TYRANO.kag.tmp.important_se = TYRANO.kag.tmp.important_se.filter(x => x !== audio_obj);
            if(TYRANO.kag.tmp.important_se_wait) {
                if(TYRANO.kag.tmp.important_se.length <= 0) {
                    TYRANO.kag.ftag.nextOrder();
                    TYRANO.kag.tmp.important_se_wait = false;
                }
            }
        })
        TYRANO.kag.tmp.important_se.push(audio_obj);
    }
    TYRANO.kag.stat.f.current_playse_index = (TYRANO.kag.stat.f.current_playse_index + 1) % TYRANO.kag.config.defaultSoundSlotNum;    
}




tyrano.plugin.kag.tag.PLAY_SE ={
    vital : ["storage"],
    pm: {
		stop: "false",
        important: "false",
	},
    start : function(pm) {
	  storage = Common.replaceDefineLabelString(pm.storage);
	  playSeRoundrobin(storage, pm.stop, pm.important);
    }
  };
TYRANO.kag.ftag.master_tag.PLAY_SE = object(tyrano.plugin.kag.tag.PLAY_SE);
TYRANO.kag.ftag.master_tag.PLAY_SE.kag = TYRANO.kag;

tyrano.plugin.kag.tag.WAIT_IMPORTANT_SE ={
    pm: {},
    start : function(pm) {
        if(TYRANO.kag.tmp.important_se && TYRANO.kag.tmp.important_se.length > 0) {
            TYRANO.kag.tmp.important_se_wait = true;
        }
        else {
            TYRANO.kag.ftag.nextOrder();
        }
    }
  };
TYRANO.kag.ftag.master_tag.WAIT_IMPORTANT_SE = object(tyrano.plugin.kag.tag.WAIT_IMPORTANT_SE);
TYRANO.kag.ftag.master_tag.WAIT_IMPORTANT_SE.kag = TYRANO.kag;


tyrano.plugin.kag.tag.SELECT =
{
    vital: ["readed_id"],
    pm: {
        readed_id: "",
        blur: "4",
    },
    start: function (pm) {
        this.kag.stat.select = {
            is_select: true,
            readed_index: -1,
            readed_id: pm.readed_id,
        };

        
        if (!("readed" in mist_system))
        {
            
            mist_system.readed = {}
        }

        
        if (!("readed" in mist_save))
        {
            mist_save.readed = {};
        }

        
        if(pm.readed_id in mist_system.readed) {
            if(!(pm.readed_id in mist_save.readed)) {
                mist_save.readed[pm.readed_id] = []
            }
            const count = mist_system.readed[pm.readed_id].length;
            for(let i = 0; i < count; ++i) {
                if(mist_save.readed[pm.readed_id].length > i) {
                    mist_save.readed[pm.readed_id][i] = mist_system.readed[pm.readed_id][i];
                }
                else {
                    mist_save.readed[pm.readed_id].push(mist_system.readed[pm.readed_id][i]);
                }
            }
            
        }

        mist_system.SelectContainer.create(pm.readed_id);
        mist_system.SelectContainer.setBlur(Number(pm.blur));
        this.kag.ftag.nextOrder();
    }
}
TYRANO.kag.ftag.master_tag.SELECT = object(tyrano.plugin.kag.tag.SELECT);
TYRANO.kag.ftag.master_tag.SELECT.kag = TYRANO.kag;


tyrano.plugin.kag.tag.END_SELECT =
{
    pm: { },
    start: function (pm) {
        this.kag.stat.select = {
            is_select: false,
            readed_index: -1,
            readed_id: "",
        };
        this.kag.ftag.nextOrder();
    }
}
TYRANO.kag.ftag.master_tag.END_SELECT = object(tyrano.plugin.kag.tag.END_SELECT);
TYRANO.kag.ftag.master_tag.END_SELECT.kag = TYRANO.kag;




const _nextOrder = tyrano.plugin.kag.ftag.nextOrder
tyrano.plugin.kag.ftag.nextOrder = () => {
	if(global.__disable_nextorder_count){ 
		global.__disable_nextorder_count -= 1;
		return ;
	}
	let that = TYRANO
	_nextOrder.apply(that.kag.ftag)
}
TYRANO.kag.ftag.nextOrder = tyrano.plugin.kag.ftag.nextOrder


const _startTag = tyrano.plugin.kag.ftag.startTag
global.__skip_nextOrder_tags = ["chara_show", "chara_new", "chara_face", "chara_layer", "ptext", "image", "playse", "chara_mod" ];
tyrano.plugin.kag.ftag.startTag = (name, pm) => {
	if(global.__disable_startTag_nextorder && global.__skip_nextOrder_tags && global.__skip_nextOrder_tags.includes(name)){ 
		global.__disable_nextorder_count += 1;
	}
	let that = TYRANO
	_startTag.apply(that.kag.ftag, [name, pm])
}
TYRANO.kag.ftag.startTag = tyrano.plugin.kag.ftag.startTag

const faces_in_adv = [

];







const faces_in_detective = [
"normal","close","sincere","earnest","earnestclose","determined","nervous","surprise","laugh","smile","what","boast","shy","happy","trance","badsurprise","doubt","panic","confused","stunned","trouble","sad","serious","frantic","scream","dark","anger","despair","cry","worry","void","starved","think","ruthless","mysterious","sadclose","frightened","faint","groan","mad","excited","crazy","grin","blood"
];


const chara_mod_origin = {
    vital: ["name"],

    pm: {
        name: "",
        face: "",
        reflect: "",
        storage: "",
        time: "",
        cross: "false",
        wait: "true",
        next: "true",
        eye: "",
    },

    start: function (pm) {
        
        if (TYRANO.kag.stat.f.detective_mode) {
            if (!faces_in_detective.includes(pm.face)) {
                console.error(`${pm.name}の${pm.face}はマダミスでは利用できません`);
                TYRANO.kag.ftag.nextOrder();
                return;
            }
        }
        pm.time = Common.toInt(Common.replaceDefineLabelString(pm.time));
        pm.eye = pm.face;
        if(TYRANO.kag.stat.is_skip){
            
            pm.wait = "true";
            if(pm.time > 0){ pm.time = 10; }
        }
        

        var that = this;
        that.kag.weaklyStop();

        var storage_url = "";
        var folder = "./data/fgimage/";
        const is_wait = pm.wait !== "false";
        const is_cross = pm.cross !== "false";

        if (pm.face != "") {
            if (!this.kag.stat.charas[pm.name]) {
                this.kag.error("undefined_character", pm);
                return;
            }
            if (!this.kag.stat.charas[pm.name]["map_face"][pm.face]) {
                this.kag.error("undefined_face", pm);
                return;
            }
            storage_url = this.kag.stat.charas[pm.name]["map_face"][pm.face];
            
            if ($.isHTTP(storage_url)) {
                folder = "";
            }
        } else {
            if ($.isHTTP(pm.storage)) {
                folder = "";
                storage_url = pm.storage;
            } else {
                storage_url = pm.storage;
            }
        }

        if(pm.name == "NPC"){
            if (this.kag.stat.jcharas[pm.name]) {
                pm.name = this.kag.stat.jcharas[pm.name];
            }else{
                console.error(`chara_mod_origin NPC 指定が見つかりません`);
            }
        }

        var j_chara = this.kag.chara.getCharaContainer(pm.name);
        var j_img = j_chara.find(".chara_img");
        if (j_chara.length == 0) {
            this.kag.stat.charas[pm.name]["storage"] = storage_url;
            this.kag.stat.charas[pm.name]["reflect"] = pm.reflect;
            this.kag.cancelWeakStop();
            if (pm.next !== "false") {
                this.kag.ftag.nextOrder();
            }
            return;
        }

        const chara_time = (j_img.attr("src") == folder + storage_url) ? 0 : pm.time;

        if (pm.reflect != "") {
            if (pm.reflect == "true") {
                j_chara.addClass("reflect");
            } else {
                j_chara.removeClass("reflect");
            }
            this.kag.stat.charas[pm.name]["reflect"] = pm.reflect;
        }

        
        if (storage_url == "") {
            that.kag.cancelWeakStop();
            if (pm.next !== "false") {
                this.kag.ftag.nextOrder();
            }
            return;
        }

        
        const eye_storage = mist_system.BlinkAnimation.animation(pm, false);
        const storage_array = [folder + storage_url, eye_storage].filter(x => x != "");
        this.kag.preloadAll(storage_array, () => {
        
        
            if ($(".chara-mod-animation").get(0)) {
                $(".chara-mod-animation_" + pm.name).remove();
            }

            
            const selector = $(`.${pm.name} .eye`);
            if (selector.length > 0) {
                const classlist = Common.getClassList(selector);
                for (var i = 0; i < classlist.length; i++) {
                    if (classlist[i] === "eye" || classlist[i] === "part") continue;
                    selector.removeClass(classlist[i]);
                }
                
                selector.addClass(pm.eye);
                const part = this.kag.stat.charas[pm.name]["_layer"]["eye"];
                const part_data = part[part.current_part_id];
                const src = `./data/fgimage/${part_data.storage}`;
                selector.attr("src", mist_save.blank_image);
                selector.css({
                    "background": `url(${src}) 0 0 no-repeat`,
                    "left": `${part_data.left}px`,
                    "top": `${part_data.top}px`,
                    "width": `${part_data.width}px`,
                    "height": `${part_data.height}px`,
                });
                mist_system.BlinkAnimation.setAnimationEvent(selector);
            }
            

            if (chara_time != 0) {
                
                j_img.stop(true, true);

                var j_new_img = j_img.clone();

                j_new_img.attr("src", folder + storage_url);
                j_new_img.css("opacity", 0);

                j_img.addClass("chara-mod-animation_" + pm.name);
                j_img.after(j_new_img);

                if (is_cross) {
                    j_img.stop(true, true).fadeTo(parseInt(that.kag.cutTimeWithSkip(chara_time)), 0, function () {
                        
                    });
                }

                j_new_img.stop(true, true).fadeTo(parseInt(that.kag.cutTimeWithSkip(chara_time)), 1, function () {
                    if (!is_cross) {
                        j_img.stop(true, true).fadeTo(parseInt(that.kag.cutTimeWithSkip(chara_time)), 0, function () {
                            j_img.remove();

                            if (is_wait) {
                                that.kag.cancelWeakStop();
                                if (pm.next !== "false") {
                                    that.kag.ftag.nextOrder();
                                }
                            }
                        });
                    } else {
                        j_img.remove();

                        if (is_wait) {
                            that.kag.cancelWeakStop();
                            if (pm.next !== "false") {
                                that.kag.ftag.nextOrder();
                            }
                        }
                    }
                });
            } else {
                
                j_img.stop(true, true);

                j_img.attr("src", folder + storage_url);

                if (is_wait) {
                    that.kag.cancelWeakStop();
                    if (pm.next !== "false") {
                        that.kag.ftag.nextOrder();
                    }
                }
            }

            
            that.kag.stat.charas[pm.name]["storage"] = storage_url;

            if (!is_wait) {
                that.kag.cancelWeakStop();
                if (pm.next !== "false") {
                    that.kag.ftag.nextOrder();
                }
            }
        });
    },
};

delete TYRANO.kag.ftag.master_tag.chara_mod;
TYRANO.kag.ftag.master_tag.chara_mod_origin = object(chara_mod_origin);
TYRANO.kag.ftag.master_tag.chara_mod_origin.kag = TYRANO.kag;




tyrano.plugin.kag.tag.MIST_SERIALIZABLE ={
    vital : ["storage"],
    pm: {
	},
    start : function(pm) {
    },
	setEvent: function (j_button, pm) {
		if(!pm["deserialize_func"]){
			return ;
		}
		callSetEvent(pm.deserialize_func, j_button, pm);
	}
  };
TYRANO.kag.ftag.master_tag.MIST_SERIALIZABLE = object(tyrano.plugin.kag.tag.MIST_SERIALIZABLE);
TYRANO.kag.ftag.master_tag.MIST_SERIALIZABLE.kag = TYRANO.kag;


const _loadGameData = tyrano.plugin.kag.menu.loadGameData;
tyrano.plugin.kag.menu.loadGameData = function (data, options) {
    
    mist_save = data.stat.f;
    mist_temp = TYRANO.kag.variable.tf;
    let that = TYRANO;

    const current_bgmovie_loop_status = data.stat.current_bgmovie["loop"];
	_loadGameData.apply(that.kag.menu, [data, options]);

    if(current_bgmovie_loop_status && !Common.toBool(current_bgmovie_loop_status)){
        const video = document.getElementById("bgmovie");
        if(video){
            video.loop = false;
        }
    }
    delete TYRANO.kag.stat.current_bgmovie["loop"];

    
    delete mist_temp.is_continue_load;

    
    if (mist_system.temp_readed) {
        mist_save.readed = mist_system.temp_readed;
        delete mist_system.temp_readed;
    }

    
    loadDetectiveMasterFile(mist_save.chapter);
    loadDetectiveMasterData();
    TYRANO.kag.variable.tf.names = masterdata.names;
    
    delete TYRANO.kag.cache_scenario["./data/scenario/detective/module/conversation.ks"];
    loadBackgtoundAnimation();

    
    if(mist_save.detective_mode || mist_save.save_detective){
        
        doDetectiveLoad();
    }

    
    mist_system.SelectContainer.load();
    
    mist_system.TutorialDialog.load();
    
    mist_system.ContinueContainer.load();
    
    mist_system.DetectiveResult.load();
    
    mist_system.Dialog.load();
    
    mist_system.BlinkAnimation.load();
	
    mist_system.EffectContainer.load();
    
    mist_system.FooterContainer.load();

    TYRANO.kag.ftag.startTag("PLAY_SE", { storage: "system/se_sys03.mp3", stop: true });

    
    applyBgmVolume();
    applySeVolume();
};


tyrano.plugin.kag.tag.SYNC_READED_DATA =
{
    pm: { },
    start: function (pm) {
        
        if (!("readed" in mist_system))
        {
            
            mist_system.readed = {}
        }

        if("readed" in mist_save) {
            
            for(let key in mist_save.readed) {
                if(!(key in mist_system.readed)) {
                    mist_system.readed[key] = [];
                }
                const count = mist_save.readed[key].length;
                for(let i = 0; i < count; ++i) {
                    if(mist_system.readed[key].length > i) {
                        
                        mist_system.readed[key][i] = mist_system.readed[key][i] || mist_save.readed[key][i];
                    }
                    else {
                        mist_system.readed[key].push(mist_save.readed[key][i]);
                    }
                }
            }
            
            delete mist_save.readed; 
        }
        this.kag.ftag.nextOrder();
    }
}
TYRANO.kag.ftag.master_tag.SYNC_READED_DATA = object(tyrano.plugin.kag.tag.SYNC_READED_DATA);
TYRANO.kag.ftag.master_tag.SYNC_READED_DATA.kag = TYRANO.kag;


tyrano.plugin.kag.tag.RESET_READED_DATA =
{
    vital: ["readed_id"],
    pm: { 
        readed_id: "",
    },
    start: function (pm) {
        
        if ("readed" in mist_system)
        {
            if(pm.readed_id in mist_system.readed) {
                delete mist_system.readed[pm.readed_id]; 
            }
        }

        if("readed" in mist_save) {
            if(pm.readed_id in mist_save.readed) {
                delete mist_save.readed[pm.readed_id]; 
            }
        }
        this.kag.ftag.nextOrder();
    }
}
TYRANO.kag.ftag.master_tag.RESET_READED_DATA = object(tyrano.plugin.kag.tag.RESET_READED_DATA);
TYRANO.kag.ftag.master_tag.RESET_READED_DATA.kag = TYRANO.kag;



tyrano.plugin.kag.tag.SELECT_GLINK = {
    pm: {

        is_bad_end: false,

        storage: null,
        target: null,
        text: "",
        cm: "true",
        clickse: "",
        enterse: "",
        leavese: "",
        
        readed_index: -1,
        readed_id: "",
    },

    
    
    start: function (pm) {
        
        let is_readed = false;
        let is_first = false;
        if (this.kag.stat.select.is_select)
        {
            pm.readed_index = ++this.kag.stat.select.readed_index;
            pm.readed_id = this.kag.stat.select.readed_id;
            is_first = pm.readed_index == 0;

            let readed = mist_save.readed;
            if (!(pm.readed_id in readed))
            {
                readed[pm.readed_id] = [];
            }

            if (readed[pm.readed_id].length > pm.readed_index)
            {
                is_readed = readed[pm.readed_id][pm.readed_index];
            }
            else
            {
                readed[pm.readed_id].push(false);
            }

            
            if (is_readed)
            {
                
                if (Common.toBool(pm.is_bad_end))
                {
                    this.kag.ftag.nextOrder();
                    return;
                }
                

                
                
            }
        }

        const j_button = mist_system.SelectContainer.addSelect(pm.text, is_readed, is_first);
        if (!j_button) {
            console.error("[SELECT][END_SELECT]内で[SELECT_GLINK]が使われていません");
            return;
        }

        this.kag.event.addEventElement({
            tag: "SELECT_GLINK",
            j_target: j_button, 
            pm: pm,
        });
        this.setEvent(j_button, pm);

        this.kag.ftag.nextOrder();
    },

    setEvent: function (j_button, pm) {
        
        let button_clicked = false;

        
        const use_cm = pm.cm !== "false";

        
        const preexp = this.kag.embScript(pm.preexp);

        
        
        
        const onEnter = () => {
            
            if (!this.kag.stat.is_strong_stop) return false;
            if (button_clicked) return false;
            if (pm.enterimg) j_button.css("background-image", "url(./data/image/" + pm.enterimg + ")");
            if (pm.enterse) this.kag.playSound(pm.enterse);
        };

        const onLeave = () => {
            
            if (!this.kag.stat.is_strong_stop) return false;
            if (button_clicked) return false;
            if (pm.enterimg) j_button.css("background-image", "url(./data/image/" + pm.graphic + ")");
            if (pm.leavese) this.kag.playSound(pm.leavese);
        };


        j_button.on("mousedown", () => {
            return false;
        });

        
        
        

        const onSubmit = (e) => {
            if (mist_temp.is_tutorial) return;
            
            
            if (!this.kag.tmp.ready_audio) this.kag.readyAudio();

            
            
            

            
            if (!this.kag.key_mouse.mouse.isClickEnabled(e)) {
                this.kag.key_mouse.vmouse.hide();
                return false;
            }

            
            if (!this.kag.stat.is_strong_stop) return false;

            
            if (button_clicked && use_cm) return false;
            

            
            
            

            
            button_clicked = true;


            
            if (pm.readed_index != -1)
            {
                this.kag.stat.f.readed[pm.readed_id][pm.readed_index] = true;
            }


            
            let message = pm.text;
            if (message.substr(0, 1) == "-") {
                
                message = message.slice(1);
            }
            TYRANO.kag.tag.text.pushTextToBackLog("", `選択肢「${message.trim()}」を選択した。`);

            
            this.kag.key_mouse.vmouse.hide();

            
            this.kag.cancelStrongStop();

            
            j_button.addClass("glink_button_clicked");

            
            if (pm.clickimg) j_button.css("background-image", "url(./data/image/" + pm.clickimg + ")");

            
            this.kag.trigger("click-tag-glink", e);

            
            if (pm.clickse) this.kag.playSound(pm.clickse);

            
            if (pm.exp) this.kag.embScript(pm.exp, preexp);

            
            const next = () => {
                
                if (use_cm) {
                    
                    this.kag.ftag.startTag("cm", { next: "false" });
                } else {
                    
                    
                    
                    
                }

                
                this.kag.ftag.startTag("jump", pm);

                
                if (this.kag.stat.skip_link === "true") {
                    e.stopPropagation();
                } else {
                    this.kag.setSkip(false);
                }
            };

            
            
            

            
            let animation_target_count = 0;

            
            const j_collection = $(".glink_button");

            
            j_collection.each((i, elm) => {
                const j_elm = $(elm);
                
                const _pm = JSON.parse(j_elm.attr("data-event-pm"));
                
                const is_selected = j_elm.hasClass("glink_button_clicked");
                if (!is_selected) {
                    j_elm.addClass("glink_button_not_clicked");
                }
                
                const head = is_selected ? "select" : "reject";
                const hide_options = {};
                ["time", "easing", "effect", "keyframe", "delay"].forEach((key) => {
                    hide_options[key] = _pm[`${head}_${key}`];
                });
                
                const need_animate =
                    hide_options.time !== undefined &&
                    parseInt(hide_options.time) >= 10 &&
                    (hide_options.keyframe !== "none" || hide_options.effect !== "none");
                if (need_animate) {
                    animation_target_count += 1;
                }
                
                elm.__hide_options = hide_options;
                elm.__need_animate = need_animate;
            });

            
            const should_keep_skip = this.kag.stat.is_skip && this.kag.stat.skip_link === "true";

            
            
            

            
            if (animation_target_count === 0 || should_keep_skip) {

                setTimeout(() => {
                    next();
                }, Common.durationSelected());

                return false;
            }

            
            
            

            
            this.kag.layer.cancelAllFreeLayerButtonsEvents();

            let anim_complete_counter = 0;
            j_collection.each((i, elm) => {
                const j_elm = $(elm);
                if (!elm.__need_animate) {
                    
                    j_elm.setStyle("transition", "none");
                    j_elm.get(0).offsetHeight; 
                    j_elm.setStyle("opacity", "0");
                    j_elm.setStyle("visibility", "hidden");
                } else {
                    
                    elm.__hide_options.callback = () => {
                        anim_complete_counter += 1;
                        if (anim_complete_counter === animation_target_count) {
                            next();
                        }
                    };
                    this.startAnim(j_elm, elm.__hide_options, true);
                }
            });

            return false;
        };

        j_button.click(onSubmit);
        j_button.hover(onEnter, onLeave);
    },

    startAnim: function (j_collection, options, do_hide) {
        
        j_collection.setStyleMap({ "pointer-events": "none" });

        
        
        

        if (options.keyframe && options.keyframe !== "none") {
            j_collection.each((i, elm) => {
                const j_elm = $(elm);
                j_elm.animateWithTyranoKeyframes({
                    keyframe: options.keyframe,
                    time: options.time,
                    delay: options.delay,
                    count: "1",
                    mode: "forwards",
                    easing: options.easing,
                    onend: () => {
                        if (options.callback) options.callback();
                    },
                });
            });
            return;
        }

        
        
        

        j_collection.each((i, elm) => {
            const j_elm = $(elm);
            j_elm.setStyle("animation-fill-mode", "forwards");
            if (options.time) j_elm.setStyle("animation-duration", $.convertDuration(options.time));
            if (options.delay) j_elm.setStyle("animation-delay", $.convertDuration(options.delay));
            if (options.easing) j_elm.setStyle("animation-timing-function", options.easing);
            j_elm.on("animationend", (e) => {
                if (j_elm.get(0) === e.target) {
                    j_elm.off("animationend");
                    j_elm.removeClass(options.effect);
                    if (do_hide) {
                        j_elm.addClass("hidden");
                    }
                    if (options.callback) options.callback();
                }
            });
            j_elm.addClass(options.effect);
        });
    },
};
TYRANO.kag.ftag.master_tag.SELECT_GLINK = object(tyrano.plugin.kag.tag.SELECT_GLINK);
TYRANO.kag.ftag.master_tag.SELECT_GLINK.kag = TYRANO.kag;



const _font = tyrano.plugin.kag.tag.font
tyrano.plugin.kag.tag.font = {
    pm: _font.pm,
    log_join: "true",
    start: function (pm) {
		let that = TYRANO
		if(pm.color && Object.keys(masterdata.replace_define).includes(pm.color)){
			pm.color = masterdata.replace_define[pm.color].replace_value;
		}
		_font.start.apply(that.kag.ftag, [pm]);
	},
};
TYRANO.kag.ftag.master_tag.font = tyrano.plugin.kag.tag.font;
TYRANO.kag.ftag.master_tag.font.kag = TYRANO.kag;


tyrano.plugin.kag.tag.chara_layer = {
    vital: ["name", "part", "id", "storage"],

    pm: {
        name: "",
        part: "",
        id: "",
        storage: "",
        zindex: "",

        left: "",
        top: "",
        width: "",
        height: "",

    },

    start: function (pm) {
        var cpm = this.kag.stat.charas[pm.name];

        if (cpm == null) {
            this.kag.error("undefined_character", pm);
            return;
        }

        var chara_layer = {};

        
        if (cpm["_layer"]) {
            chara_layer = cpm["_layer"];
        } else {
            cpm["_layer"] = {};
        }

        var chara_part = {};

        
        var init_part = false;
        if (chara_layer[pm.part]) {
            chara_part = chara_layer[pm.part];
        } else {
            init_part = true;
            
            cpm["_layer"][pm.part] = {
                default_part_id: pm.id,
                current_part_id: pm.id,
                zindex: pm.zindex,
            };
        }

        var chara_obj = {};

        
        if (chara_part[pm.id]) {
            chara_obj = chara_part[pm.id];
        } else {
            chara_obj = {
                storage: "",
                zindex: "",
            };

            
            if (init_part == true) {
                chara_obj["visible"] = "true";
            } else {
                chara_obj["visible"] = "false";
            }
        }


        chara_obj["left"] = pm.left;
        chara_obj["top"] = pm.top;
        chara_obj["width"] = pm.width;
        chara_obj["height"] = pm.height;

        cpm["_layer"][pm.part][pm.id] = $.extendParam(pm, chara_obj);

        this.kag.ftag.nextOrder();
    },
};
TYRANO.kag.ftag.master_tag.chara_layer = object(tyrano.plugin.kag.tag.chara_layer);
TYRANO.kag.ftag.master_tag.chara_layer.kag = TYRANO.kag;



tyrano.plugin.kag.tag.ptext = {
    vital: ["layer", "x", "y"],

    pm: {
        layer: "0",
        page: "fore",
        x: 0,
        y: 0,
        vertical: "false",
        text: "", 
        size: "",
        face: "",
        color: "",
        italic: "",
        bold: "",
        align: "left",
        edge: "",
        shadow: "",
        name: "",
        time: "",
        width: "",
        zindex: "9999",
        overwrite: "false", 

        
    },

    start: function (pm) {
        var that = this;

        
        
        

        if (pm.overwrite == "true" && pm.name != "") {
            if ($("." + pm.name).length > 0) {
                $("." + pm.name).updatePText(pm.text);

                
                if (pm.x != 0) {
                    $("." + pm.name).css("left", parseInt(pm.x));
                }

                if (pm.y != 0) {
                    $("." + pm.name).css("top", parseInt(pm.y));
                }

                if (pm.color != "") {
                    $("." + pm.name).css("color", $.convertColor(pm.color));
                }

                if (pm.size != "") {
                    $("." + pm.name).css("font-size", parseInt(pm.size));
                }

                this.kag.ftag.nextOrder();
                return false;
            }
        }

        
        
        

        const font = this.kag.stat.font;

        if (pm.face == "") {
            pm.face = font.face;
        }

        if (pm.color == "") {
            pm.color = $.convertColor(font.color);
        } else {
            pm.color = $.convertColor(pm.color);
        }

        
        if (pm.bold === "true") {
            pm.bold = "bold";
        }

        
        
        

        const font_new_style = {
            "color": pm.color,
            "font-weight": pm.bold,
            "font-style": pm.fontstyle,
            "font-size": pm.size + "px",
            "font-family": pm.face,
            "z-index": "999",
            "text": "",
        };

        
        
        

        const tobj = $("<p></p>");

        
        tobj.css({
            "position": "absolute",
            "top": pm.y + "px",
            "left": pm.x + "px",
            "width": pm.width,
            "text-align": pm.align,
        });
        this.kag.setStyles(tobj, font_new_style);

        
        
        

        
        const is_edge_enabled = pm.edge !== "";
        
        pm.edge_method = pm.edge_method || font.edge_method || "shadow";
        
        let is_individual_decoration = is_edge_enabled && pm.edge_method === "stroke";
        
        if (is_edge_enabled && pm.edge_method === "shadow" && pm.gradient) {
            is_individual_decoration = true;
        }
        if (is_edge_enabled) {
            
            switch (pm.edge_method) {
                case "shadow":
                    if (!is_individual_decoration) {
                        tobj.css("text-shadow", $.generateTextShadowStrokeCSS(pm.edge));
                    }
                    break;
                case "filter":
                    tobj.setFilterCSS($.generateDropShadowStrokeCSS(pm.edge));
                    break;
                case "stroke":
                    break;
            }
        } else if (pm.shadow != "") {
            tobj.css("text-shadow", "2px 2px 2px " + $.convertColor(pm.shadow));
        }

        
        if (pm.vertical == "true") {
            tobj.addClass("vertical_text");
        }
        if (pm.layer == "fix") {
            tobj.addClass("fixlayer");
        }
        $.setName(tobj, pm.name);

        
        if (is_individual_decoration) {
            tobj.addClass("multiple-text");
            this.kag.event.addEventElement({
                tag: "ptext",
                j_target: tobj,
                pm: pm,
            });
            this.setEvent(tobj, pm);
        }

        
        tobj.updatePText(pm.text);

        
        if (pm.gradient === "none") {
            pm.gradient = "";
        }
        if (pm.gradient && !is_individual_decoration) {
            tobj.setGradientText(pm.gradient);
        }

        
        
        

        const target_layer = (pm.layer == "free") ? this.kag.layer.getFreeLayer() : this.kag.layer.getLayer(pm.layer, pm.page);


        
        if (pm.time != "") {
            tobj.css("opacity", 0);
            target_layer.append(tobj);
            tobj.stop(true, true).animate({ opacity: 1 }, parseInt(pm.time), function () {
                that.kag.ftag.nextOrder();
            });
        } else {
            target_layer.append(tobj);
            this.kag.ftag.nextOrder();
        }
    },

    setEvent: function (j_target, pm) {
        const that = TYRANO;

        
        j_target.get(0).updateText = (str) => {
            that.kag.tmp.is_edge_overlap = false;

            
            const is_shadow = pm.edge_method === "shadow";
            if (is_shadow) {
                const edges = $.parseEdgeOptions(pm.edge);
                that.kag.tmp.text_shadow_values = [];
                for (let i = edges.length - 1; i >= 0; i--) {
                    const edge = edges[i];
                    const text_shadow_value = $.generateTextShadowStrokeCSSOne(edge.color, edge.total_width);
                    that.kag.tmp.text_shadow_values.push(text_shadow_value);
                }
                that.kag.tmp.inside_stroke_color = edges[0].color;
            }

            const inner_html = Array.prototype.reduce.call(
                str,
                (total_html, this_char) => {
                    if (is_shadow) {
                        return total_html + that.kag.getTag("text").buildTextShadowChar(this_char, pm.edge, true);
                    } else {
                        return total_html + that.kag.getTag("text").buildTextStrokeChar(this_char, pm.edge, true);
                    }
                },
                "",
            );
            j_target.html(inner_html);
            if (pm.gradient) {
                j_target.find(".fill").setGradientText(pm.gradient);
            }
        };
    },
};
TYRANO.kag.ftag.master_tag.ptext = object(tyrano.plugin.kag.tag.ptext);
TYRANO.kag.ftag.master_tag.ptext.kag = TYRANO.kag;


 tyrano.plugin.kag.tag.image = {
    pm: {
        layer: "base",
        page: "fore",
        visible: "",
        top: "",
        left: "",
        x: "",
        y: "",
        width: "",
        height: "",
        pos: "",
        name: "",
        folder: "", 
        time: "",
        wait: "true",
        depth: "front",
        reflect: "",
        zindex: "1",
        
    },

    start: function (pm) {
        var strage_url = "";
        var folder = "";
        var that = this;

        if (pm.layer != "base") {
            
            
            var layer_new_style = {};

            
            if (pm.visible == "true" && pm.page == "fore") {
                layer_new_style.display = "block";
            }


            if (pm.layer != "free")
            {
                this.kag.setStyles(this.kag.layer.getLayer(pm.layer, pm.page), layer_new_style);
            }


            
            if (pm.pos != "") {
                switch (pm.pos) {
                    case "left":
                    case "l":
                        pm.left = this.kag.config["scPositionX.left"];
                        break;

                    case "left_center":
                    case "lc":
                        pm.left = this.kag.config["scPositionX.left_center"];
                        break;

                    case "center":
                    case "c":
                        pm.left = this.kag.config["scPositionX.center"];
                        break;

                    case "right_center":
                    case "rc":
                        pm.left = this.kag.config["scPositionX.right_center"];
                        break;

                    case "right":
                    case "r":
                        pm.left = this.kag.config["scPositionX.right"];
                        break;
                }
            }

            if (pm.folder != "") {
                folder = pm.folder;
            } else {
                folder = "fgimage";
            }

            
            if ($.isHTTP(pm.storage)) {
                strage_url = pm.storage;
            } else {
                strage_url = "./data/" + folder + "/" + pm.storage;
            }

            var img_obj = $("<img />");

            if ($.getExt(pm.storage) == "svg" || $.getExt(pm.storage) == "SVG") {
                img_obj = $("<object type='image/svg+xml' />");
                img_obj.attr("data", strage_url);
            }

            img_obj.attr("src", strage_url);

            img_obj.css("position", "absolute");
            img_obj.css("top", pm.top + "px");
            img_obj.css("left", pm.left + "px");

            if (pm.width != "") {
                img_obj.css("width", pm.width + "px");
            }

            if (pm.height != "") {
                img_obj.css("height", pm.height + "px");
            }

            if (pm.x != "") {
                img_obj.css("left", pm.x + "px");
            }

            if (pm.y != "") {
                img_obj.css("top", pm.y + "px");
            }

            if (pm.zindex != "") {
                img_obj.css("z-index", pm.zindex);
            }

            if (pm.reflect != "") {
                if (pm.reflect == "true") {
                    img_obj.addClass("reflect");
                }
            }

            
            $.setName(img_obj, pm.name);

            if (pm.time == 0 || pm.time == "0") pm.time = ""; 
            if (pm.time != "") {
                img_obj.css("opacity", 0);

                if (pm.depth == "back") {
                    this.kag.layer.getLayer(pm.layer, pm.page).prepend(img_obj);
                } else {
                    this.kag.layer.getLayer(pm.layer, pm.page).append(img_obj);
                }

                img_obj.stop(true, true).animate({ opacity: 1 }, parseInt(pm.time), function () {
                    if (pm.wait == "true") {
                        that.kag.ftag.nextOrder();
                    }
                });

                if (pm.wait != "true") {
                    that.kag.ftag.nextOrder();
                }
            } else {


                if (pm.layer == "free") {
                    this.kag.layer.getFreeLayer().append(img_obj);
                }

                else if (pm.depth == "back") {
                    this.kag.layer.getLayer(pm.layer, pm.page).prepend(img_obj);
                } else {
                    this.kag.layer.getLayer(pm.layer, pm.page).append(img_obj);
                }

                this.kag.ftag.nextOrder();
            }
        } else {
            

            if (pm.folder != "") {
                folder = pm.folder;
            } else {
                folder = "bgimage";
            }

            
            if ($.isHTTP(pm.storage)) {
                strage_url = pm.storage;
            } else {
                strage_url = "./data/" + folder + "/" + pm.storage;
            }

            

            var new_style = {
                "background-image": "url(" + strage_url + ")",
                "display": "none",
            };

            if (pm.page === "fore") {
                new_style.display = "block";
            }

            this.kag.setStyles(this.kag.layer.getLayer(pm.layer, pm.page), new_style);
            this.kag.ftag.nextOrder();
        }
    },
};
TYRANO.kag.ftag.master_tag.image = object(tyrano.plugin.kag.tag.image);
TYRANO.kag.ftag.master_tag.image.kag = TYRANO.kag;



tyrano.plugin.kag.tag.free = {
    vital: ["layer", "name"],

    pm: {
        layer: "",
        page: "fore",
        name: "",
        wait: "true",
        time: "", 
    },

    start: function (pm) {
        var that = this;


        if (pm.layer == "free") {
            var j_obj = this.kag.layer.getFreeLayer();
            j_obj = j_obj.find("." + pm.name);
            j_obj.remove();
            that.kag.ftag.nextOrder();
            return;
        }

        if (pm.layer != "base") {
            

            
            if (pm.time == 0) pm.time = ""; 
            if (pm.time != "") {
                var j_obj = this.kag.layer.getLayer(pm.layer, pm.page);
                j_obj = j_obj.find("." + pm.name);

                
                if (!j_obj.get(0)) {
                    if (pm.wait == "true") {
                        that.kag.ftag.nextOrder();
                        return;
                    }
                }

                var cnt = 0;
                var s_cnt = j_obj.length;

                j_obj.stop(true, true).animate({ opacity: 0 }, parseInt(pm.time), function () {
                    j_obj.remove();
                    
                    cnt++;
                    if (cnt == s_cnt) {
                        if (pm.wait == "true") {
                            that.kag.ftag.nextOrder();
                        }
                    }
                });

                
                if (pm.wait == "false") {
                    that.kag.ftag.nextOrder();
                }
            } else {
                let j_obj = this.kag.layer.getLayer(pm.layer, pm.page);
                j_obj = j_obj.find("." + pm.name);
                j_obj.remove();

                
                that.kag.ftag.nextOrder();
            }
        } else {
            let j_obj = this.kag.layer.getLayer(pm.layer, pm.page);
            j_obj = j_obj.find("." + pm.name);
            j_obj.remove();
            
            
            this.kag.ftag.nextOrder();
        }
    },
};
TYRANO.kag.ftag.master_tag.free = object(tyrano.plugin.kag.tag.free);
TYRANO.kag.ftag.master_tag.free.kag = TYRANO.kag;


tyrano.plugin.kag.tag.chara_show = {
    vital: ["name"],

    pm: {
        name: "",
        page: "fore",
        layer: "0", 
        wait: "true", 
        left: "", 
        top: "",
        width: "",
        height: "",
        zindex: "1",
        depth: "front",
        reflect: "",
        face: "",
        storage: "",
        time: 1000,
    },

    start: function (pm) {
        
        if (TYRANO.kag.stat.f.detective_mode) {
            if (!faces_in_detective.includes(pm.face)) {
                console.error(`${pm.name}の${pm.face}はマダミスでは利用できません`);
                pm.face = "";
            }
        }
        
        var that = this;
        pm.time = Common.toInt(Common.replaceDefineLabelString(pm.time));

        var cpm = this.kag.stat.charas[pm.name];

        var array_storage = [];

        if (cpm == null) {
            this.kag.error("undefined_character", pm);
            return;
        }

        
        var check_obj = that.kag.chara.getCharaContainer(pm.name);

        check_obj.stop(true, true);

        if (check_obj.get(0)) {
            check_obj.stop(true, true);

            if (check_obj.css("display") != "none") {
                that.kag.ftag.nextOrder();
                return;
            }
        } else {
            
            cpm.is_show = "false";
        }

        
        if (cpm.is_show == "true") {
            that.kag.ftag.nextOrder();
            return;
        }

        var storage_url = "./data/fgimage/" + cpm.storage;

        if ($.isHTTP(cpm.storage)) {
            storage_url = cpm.storage;
        }

        
        if (pm.face != "") {
            if (!cpm["map_face"][pm.face]) {
                this.kag.error("undefined_face", pm);
                return;
            }
            storage_url = "./data/fgimage/" + cpm["map_face"][pm.face];
            
            if ($.isHTTP(cpm["map_face"][pm.face])) {
                storage_url = cpm["map_face"][pm.face];
            }
        } else if (pm.storage != "") {
            if ($.isHTTP(pm.storage)) {
                storage_url = pm.storage;
            } else {
                storage_url = "./data/fgimage/" + pm.storage;
            }

            that.kag.stat.charas[pm.name]["storage"] = pm.storage;
        }

        var j_chara_root = $("<div></div>");
        j_chara_root.css({
            position: "absolute",
            display: "none",
        });

        var img_obj = $("<img />");
        img_obj.attr("src", storage_url);
        img_obj.addClass("chara_img");
        
        
        

        
        j_chara_root.append(img_obj);

        if (pm.width != "") {
            var width = parseInt(pm.width);
            cpm.width = width;
        }

        if (pm.height != "") {
            var height = parseInt(pm.height);
            cpm.height = height;
        }

        if (cpm.width != "") {
            j_chara_root.css("width", cpm.width + "px");
        }

        if (cpm.height != "") {
            j_chara_root.css("height", cpm.height + "px");
        }

        if (pm.zindex != "") {
            var zindex = parseInt(pm.zindex);
            j_chara_root.css("z-index", zindex);
        }

        
        
        var chara_layer = {};
        if (cpm["_layer"]) {
            chara_layer = cpm["_layer"];
        }

        for (let key in chara_layer) {
            var chara_part = chara_layer[key];

            
            var current_part_id = chara_part["current_part_id"];
            var chara_obj = chara_part[current_part_id];

            
            if (current_part_id == "allow_storage") {
                chara_obj = {
                    storage: chara_part["allow_storage"],
                    visible: "true",
                };
            }

            if (true) {
                var part_storage = "./data/fgimage/" + chara_obj["storage"];

                var j_img = $("<img />");

                
                if (chara_obj["storage"] == "none") {
                    part_storage = "./tyrano/images/system/transparent.png";
                } else {
                    array_storage.push(part_storage);
                }

                j_img.attr("src", part_storage);


                const left = chara_obj["left"] == "" ? 0 : chara_obj["left"] + "px";
                const top = chara_obj["top"] == "" ? 0 : chara_obj["top"] + "px";
                const width = chara_obj["width"] == "" ? "100%" : chara_obj["width"] + "px";
                const height = chara_obj["height"] == "" ? "100%" : chara_obj["height"] + "px";

                j_img.css({
                    "position": "absolute",

                    "left": left,
                    "top": top,
                    "width": width,
                    "height": height,

                    "z-index": chara_part.zindex,
                });

                j_img.addClass("part");
                j_img.addClass(key); 

                j_chara_root.append(j_img);
            }
        }

        
        if (pm.reflect != "") {
            if (pm.reflect == "true") {
                cpm.reflect = "true";
            } else {
                cpm.reflect = "false";
            }
        }

        
        
        that.kag.chara.setPartContainer(j_chara_root);

        array_storage.push(storage_url);

        
        cpm.is_show = "true";
        cpm.layer = pm.layer;

        
        this.kag.preloadAll(array_storage, function () {
            var target_layer = that.kag.layer.getLayer(pm.layer, pm.page);
            
            
            if (pm.depth == "back") {
                target_layer.prepend(j_chara_root).show();
            } else {
                target_layer.append(j_chara_root).show();
            }

            var chara_num = 1;
            that.kag.weaklyStop();

            

            
            if (that.kag.stat.chara_pos_mode == "true" && pm.left === "") {
                
                if (pm.top !== "") {
                    j_chara_root.css("top", parseInt(pm.top));
                } else {
                    j_chara_root.css("bottom", 0);
                }

                
                var chara_cnt = target_layer.find(".tyrano_chara").length;

                var sc_width = parseInt(that.kag.config.scWidth);
                var sc_height = parseInt(that.kag.config.scHeight);

                var center = Math.floor(parseInt(j_chara_root.css("width")) / 2);

                
                var base = Math.floor(sc_width / (chara_cnt + 2));
                var tmp_base = base;
                var first_left = base - center;

                j_chara_root.css("left", first_left + "px");

                
                var array_tyrano_chara = target_layer.find(".tyrano_chara").get().reverse();
                $(array_tyrano_chara).each(function () {
                    chara_num++;

                    tmp_base += base;

                    var j_chara = $(this);
                    
                    center = Math.floor(parseInt(j_chara.css("width")) / 2);
                    
                    var left = tmp_base - center;

                    if (that.kag.stat.chara_anim == "false") {
                        j_chara.stop(true, true).fadeTo(parseInt(that.kag.cutTimeWithSkip(pm.time)), 0, function () {
                            j_chara.css("left", left);

                            j_chara
                                .stop(true, true)
                                .fadeTo(parseInt(that.kag.cutTimeWithSkip(that.kag.stat.pos_change_time)), 1, function () {
                                    chara_num--;
                                    if (chara_num == 0) {
                                        that.kag.cancelWeakStop();
                                        if (pm.wait == "true") {
                                            that.kag.ftag.nextOrder();
                                        }
                                    }
                                });
                        });
                    } else {
                        j_chara.stop(true, true).animate(
                            {
                                left: left,
                            },
                            parseInt(that.kag.cutTimeWithSkip(that.kag.stat.pos_change_time)),
                            that.kag.stat.chara_effect,
                            function () {
                                chara_num--;
                                if (chara_num == 0) {
                                    that.kag.cancelWeakStop();
                                    if (pm.wait == "true") {
                                        that.kag.ftag.nextOrder();
                                    }
                                }
                            },
                        );
                    }
                });
            } else {
                j_chara_root.css("top", pm.top + "px");
                j_chara_root.css("left", pm.left + "px");

                
            }

            
            setTimeout(function () {
                var width = img_obj.css("width");
                var height = img_obj.css("height");

                j_chara_root.css("width", width);
                j_chara_root.css("height", height);


                
                

            }, 1);

            
            $.setName(j_chara_root, cpm.name);
            j_chara_root.addClass("tyrano_chara");
            

            

            if (cpm.width != "") {
                img_obj.css("width", cpm.width + "px");
            }

            if (cpm.height != "") {
                img_obj.css("height", cpm.height + "px");
            }

            if (cpm.reflect == "true") {
                j_chara_root.addClass("reflect");
            } else {
                j_chara_root.removeClass("reflect");
            }

            if (pm.wait != "true") {
                that.kag.ftag.nextOrder();
            }

            
            j_chara_root.stop(true, true).animate(
                {
                    opacity: "show",
                },
                {
                    duration: parseInt(that.kag.cutTimeWithSkip(pm.time)),
                    easing: that.kag.stat.chara_effect,
                    complete: function () {
                        chara_num--;
                        if (chara_num == 0) {
                            that.kag.layer.showEventLayer();

                            if (pm.wait == "true") {
                                that.kag.ftag.nextOrder();
                            }
                        }
                    }, 
                },
            );
        });
        
    },
};

TYRANO.kag.ftag.master_tag.chara_show = object(tyrano.plugin.kag.tag.chara_show);
TYRANO.kag.ftag.master_tag.chara_show.kag = TYRANO.kag;

tyrano.plugin.kag.tag.text.pushTextToBackLog = function (chara_name, message_str){
    
    let default_color = TYRANO.kag.stat.default_font.color;
    let current_color = TYRANO.kag.stat.font.color;
    if (TYRANO.kag.stat.is_reset_font_color) {
        TYRANO.kag.stat.is_reset_font_color = default_color === current_color;
        if (!TYRANO.kag.stat.is_reset_font_color) {
            message_str = `<span style="color:${current_color};">${message_str}`;
        }
    } else {
        if (default_color === current_color) {
            TYRANO.kag.stat.is_reset_font_color = true;
            message_str = `</span>${message_str}`;
        }
    }

    
    const name = chara_name == "" ? "" : Common.getDisplayNameToFullName(chara_name);

    
    
    var should_join_log = TYRANO.kag.stat.log_join == "true";

    const backlog = mist_save.backlog;
    if (backlog) {
        console.log(backlog[backlog.length - 1]);
    }
    
    if ((name != "" && !should_join_log) || (name != "" && TYRANO.kag.stat.f_chara_ptext == "true")) {
        TYRANO.kag.pushBackLog(name, message_str, "add");

        if (TYRANO.kag.stat.f_chara_ptext == "true") {
            TYRANO.kag.stat.f_chara_ptext = "false";
            TYRANO.kag.stat.log_join = "true";
        }
    } else {
        const join_type = should_join_log ? "join" : "add";
        TYRANO.kag.pushBackLog(name, message_str, join_type);
    }
}


tyrano.plugin.kag.tag.SAVE_CONTINUE_SELECT =
{
    vital: ["id"],
    pm: {
        id: ""
    },
    start: function (pm) {
        const saveTitle = this.kag.stat.current_save_str;
        const menu = this.kag.menu;
        this.kag.menu.snapSave(saveTitle, () => {
            var data = menu.snap;
            data.save_date = menu.getDateStr();
            $.setStorage(`${TYRANO.kag.config.projectID}_tyrano_continue_${pm.id}`, data, this.kag.config.configSave);
            this.kag.ftag.nextOrder();
        }, "false");
    }
}
TYRANO.kag.ftag.master_tag.SAVE_CONTINUE_SELECT = object(tyrano.plugin.kag.tag.SAVE_CONTINUE_SELECT);
TYRANO.kag.ftag.master_tag.SAVE_CONTINUE_SELECT.kag = TYRANO.kag;


tyrano.plugin.kag.tag.LOAD_CONTINUE_SELECT =
{
    vital: ["id"],
    pm: {
        id: ""
    },
    start: function (pm) {
        
        mist_system.temp_readed = mist_save.readed;

        var data = $.getStorage(`${this.kag.config.projectID}_tyrano_continue_${pm.id}`, this.kag.config.configSave);
        if (data) {
            data = JSON.parse(data);
        } else {
            console.error(`[LOAD_CONTINUE_SELECT id=${pm.id}]: セーブデータが無いです。`);
            return false;
        }

        
        this.kag.menu.loadGameData($.extend(true, {}, data), { auto_next: "yes" });
        
        this.kag.setSkip(false);
    }
}
TYRANO.kag.ftag.master_tag.LOAD_CONTINUE_SELECT = object(tyrano.plugin.kag.tag.LOAD_CONTINUE_SELECT);
TYRANO.kag.ftag.master_tag.LOAD_CONTINUE_SELECT.kag = TYRANO.kag;


tyrano.plugin.kag.tag.autosave = {
    vital: [],

    pm: {
        title: "",
    },

    start: function (pm) {
        var that = this;

        
        if (pm.title == "") {
            pm.title = this.kag.stat.current_save_str;
            if(pm.title == "" && mist_save.chapter_select_start){
                pm.title = `チャプターセレクト`;
            }
        }
        
        this.kag.menu.snapSave(pm.title, function () {
            that.kag.menu.doSetAutoSave();
            that.kag.ftag.nextOrder();
        }, "false");
    },
}
TYRANO.kag.ftag.master_tag.autosave = object(tyrano.plugin.kag.tag.autosave);
TYRANO.kag.ftag.master_tag.autosave.kag = TYRANO.kag;


TYRANO.kag.pushBackLog = function(chara_name, str, type, standalone) {
    
    if (!this.stat.log_write) {
        return;
    }
    if (!mist_save.backlog) {
        
        mist_save.backlog = [];
    }
    
    if (TYRANO.kag.stat.ruby_str != "" && str.length > 0) {   
        const temp = str;
        str = `<ruby>${temp.substring(0, 1)}<rt>${TYRANO.kag.stat.ruby_str}</rt></ruby>`;
        if (temp.length > 1)
        str += temp.substring(1, temp.length);
    }

    
    str = str.replace(/(<span.*>|<\/span.*>)/, "");

    
    
    if (TYRANO.kag.stat.font.color &&
        TYRANO.kag.stat.font.color !== TYRANO.kag.stat.default_font.color &&
        TYRANO.kag.stat.font.color !== `white` &&
        TYRANO.kag.stat.font.color !== mist_save.window_font_color) {
        if(Object.keys(masterdata.replace_define).includes('@3')){
            const color = masterdata.replace_define['@3'].replace_value;
            str = `<font color=${color}>${str}</font>`;
        }
    }

    let last_log = mist_save.backlog[mist_save.backlog.length - 1];
    const is_same_name = (() => {
        if (last_log === undefined) return false;
        return last_log.name == chara_name;
    })();
    const is_same_monologue = (() => {
        if (last_log === undefined) return false;
        return last_log.is_monologue == mist_save.is_monologue;
    })();
    const is_same_item = (() => {
        if (last_log === undefined) return false;
        return last_log.backlog_item_type == mist_save.backlog_item_type &&
                last_log.backlog_item_id == mist_save.backlog_item_id;
    })();
    const is_standalone = (() => {
        if (last_log === undefined) return false;
        return last_log.standalone || standalone;
    })();
    const is_same_message_id = (() => {
        if (last_log === undefined) return false;
        return last_log.id == this.stat.message_id;
    })();
    const push = (name, texts, standalone) => {
        mist_save.backlog.push({
            id: this.stat.message_id,
            name: name,
            texts: texts,
            standalone: standalone,
            is_monologue: mist_save.is_monologue,
            backlog_item_type: mist_save.backlog_item_type,
            backlog_item_id: mist_save.backlog_item_id,
            backlog_item_value: mist_save.backlog_item_value,
    
        });
    };
    switch (type) {
        
        case "add":
        case "join": {
            
            
            
            if (is_same_name && is_same_monologue && is_same_item && !is_standalone && is_same_message_id) {
                const texts = last_log.texts;
                const prev_text = texts[texts.length - 1];
                last_log.texts[texts.length - 1] = prev_text + str;
                last_log.id = this.stat.message_id;
            
            } else {
                push(chara_name, [str], standalone);
            }
        }
        break;

        
        case "empty": {
            
            if (last_log === undefined || last_log.name != "empty") {
                push("empty", []);
            } 
        }
        break;
    }

    
    this.stat.current_save_str = Common.removeHtmlTag(str);

    
    const max = parseInt(this.kag.config["maxBackLogNum"]);
    if (max < mist_save.backlog.length) {
        mist_save.backlog.shift();
    }
};
TYRANO.kag.pushBackLogTagBr = function() {
    let last_log = mist_save.backlog[mist_save.backlog.length - 1];
    if (last_log === undefined) return;

    if (last_log.backlog_item_type == "tutorial") {
        
        return;
    }
    const texts = last_log.texts;
    last_log.texts[texts.length - 1] += "<br>";
}




TYRANO.kag.tag.text.setMessageInnerStyle = function (j_inner_message) {
	tyrano.plugin.kag.tag.text.kag = TYRANO.kag;
    
    const font_feature_settings = this.getMessageConfig("kerning") === "true" ? '"palt"' : "initial";

    j_inner_message.setStyleMap({
        "letter-spacing": this.kag.config.defaultPitch + "px",
        "line-height": parseInt(this.kag.stat.default_font.size)  + parseInt(this.kag.config.defaultLineSpacing) + "px",
        "font-family": this.kag.config.userFace,
        "font-feature-settings": font_feature_settings,
    });
};




tyrano.plugin.kag.tag.layer_movie = {
    vital: ["storage"],

    pm: {
        storage: "",
        zIndex: "199999",
        volume: "",
        skip: "false",
        mute: "false",
        
        bgmode: "false",
        loop: "false",
    },

    start: function (pm) {
        var that = this;

        if ($.userenv() != "pc") {
            this.kag.cancelWeakStop();

            
            
            if ($.isTyranoPlayer()) {
                that.playVideo(pm);
            } else {
                this.kag.cancelWeakStop();
                
                that.playVideo(pm);
                $(".tyrano_base").unbind("click.movie");
                
            }
        } else {
            
            if ($.getBrowser() == "opera") {
                pm.storage = $.replaceAll(pm.storage, ".mp4", ".webm");
            }

            that.playVideo(pm);
        }
    },

    playVideo: function (pm) {
        var that = this;

        var url = "./data/video/" + pm.storage;

        var video = document.createElement("video");
        video.id = "bgmovie";
        
        video.src = url;

        if (!isNaN(parseInt(pm.volume))) {
            video.volume = parseFloat(parseInt(pm.volume) / 100);
        } else {
            if (typeof this.kag.config.defaultMovieVolume != "undefined") {
                video.volume = parseFloat(parseInt(this.kag.config.defaultMovieVolume) / 100);
            }
        }

        

        video.style.backgroundColor = "black";
        video.style.position = "absolute";
        video.style.top = "0px";
        video.style.left = "0px";
        video.style.width = "100%";
        video.style.height = "100%";
        video.style.display = "none";
        video.autoplay = true;
        video.autobuffer = true;

        video.setAttribute("playsinline", "1");

        if (pm.mute == "true") {
            video.muted = true;
        }

        

        if (pm.bgmode == "true") {
            that.kag.tmp.video_playing = true;

            
            video.style.zIndex = 0;

            if (pm.loop == "true") {
                video.loop = true;
            } else {
                video.loop = false;
            }

            video.addEventListener("ended", function (e) {
                
                
                
                if (that.kag.stat.video_stack == null) {
                    
                    that.kag.tmp.video_playing = false;

                    if (that.kag.stat.is_wait_bgmovie == true) {
                        that.kag.ftag.nextOrder();
                        that.kag.stat.is_wait_bgmovie = false;
                    }

                    
                } else {
                    var video_pm = that.kag.stat.video_stack;

                    var video2 = document.createElement("video");

                    video2.style.backgroundColor = "black";
                    video2.style.position = "absolute";
                    video2.style.top = "0px";
                    video2.style.left = "0px";
                    video2.style.width = "100%";
                    video2.style.height = "100%";
                    video2.autoplay = true;
                    video2.autobuffer = true;

                    if (video_pm.loop == "true") {
                        video2.loop = true;
                    } else {
                        video2.loop = false;
                    }

                    video2.setAttribute("playsinline", "1");

                    if (video_pm.mute == "true") {
                        video2.muted = true;
                    }

                    
                    video2.src = "./data/video/" + video_pm.storage;
                    video2.load();
                    var j_video2 = $(video2);
                    video2.play();
                    j_video2.css("z-index", -1);
                    $("#tyrano_base").append(j_video2);

                    video2.addEventListener(
                        "canplay",
                        function (event) {
                            var arg = arguments.callee;

                            
                            j_video2.css("z-index", 1);

                            setTimeout(function () {
                                $("#bgmovie").remove();
                                video2.id = "bgmovie";
                            }, 100);

                            that.kag.stat.video_stack = null;
                            

                            that.kag.tmp.video_playing = true;

                            video2.removeEventListener("canplay", arg, false);
                            

                            
                        },
                        false,
                    );

                    

                    video2.addEventListener("ended", arguments.callee);

                    
                }
            });
        } else {
            video.style.zIndex = parseFloat(pm.zIndex);

            video.addEventListener("ended", function (e) {
                $(".tyrano_base").find("video").remove();
                that.kag.ftag.nextOrder();
            });

            
            

            if (pm.skip == "true") {
                $(video).on("click touchstart", function (e) {
                    $(video).off("click touchstart");
                    $(".tyrano_base").find("video").remove();
                    that.kag.ftag.nextOrder();
                });
            }
        }

        var j_video = $(video);
        j_video.css("opacity", 0);

        

        $("#tyrano_base").append(j_video);
        j_video.animate(
            { opacity: "1" },
            {
                duration: parseInt(pm.time),
                complete: function () {
                    
                    
                    
                    
                    
                },
            },
        );

        video.load();

        
        video.addEventListener("canplay", function () {
            video.style.display = "";
            video.play();
        });
    },
};
TYRANO.kag.ftag.master_tag.layer_movie = object(tyrano.plugin.kag.tag.layer_movie);
TYRANO.kag.ftag.master_tag.layer_movie.kag = TYRANO.kag;





const _bg = tyrano.plugin.kag.tag.bg
tyrano.plugin.kag.tag.bg = {
    pm: {
        storage: "",
        method: "crossfade",
        wait: "true",
        time: 3000,
        cross: "false",
        position: "",
    },
    start: function (pm) {
	    TYRANO.kag.ftag.startTag("free_layermode", {"name":"background-effect", "stop":"true"});
		let that = TYRANO

		pm.storage = Common.replaceDefineLabelString(pm.storage);
		pm.time = Common.replaceDefineLabelString(pm.time);
		_bg.start.apply(that.kag.ftag, [pm]);
		const bg_file = pm.storage.split('.')[0].split('/').slice(-1)[0];
        if(masterdata.background[bg_file]){
            const effect_file = `${masterdata.background[bg_file].effect}.mp4`;
		    TYRANO.kag.ftag.startTag("layermode_movie", {"video": effect_file, "mode":"color-dodge", "opacity":"130", "loop":"true", "name":"background-effect", "stop":"true", "zindex":"9"});
		}

        const img = TYRANO.kag.layer.getLayer("base", "fore");
        setBackgroundAnimation(bg_file, img);
	},
};
TYRANO.kag.ftag.master_tag.bg = object(tyrano.plugin.kag.tag.bg);
TYRANO.kag.ftag.master_tag.bg.kag = TYRANO.kag;


const _pushlog = tyrano.plugin.kag.tag.pushlog;
tyrano.plugin.kag.tag.pushlog = {
    vital: ["text"],

    pm: {
        text: "",
        join: "false",
        standalone: "false",
    },
    start: function (pm) {
        if (pm.join == "true") {
            
            this.kag.pushBackLog("", pm.text, "join", pm.standalone);
        } else {
            Common.addMessageCount();
            this.kag.pushBackLog("", pm.text, "add", pm.standalone);
        }

        this.kag.ftag.nextOrder();
	},
};
TYRANO.kag.ftag.master_tag.pushlog = object(tyrano.plugin.kag.tag.pushlog);
TYRANO.kag.ftag.master_tag.pushlog.kag = TYRANO.kag;






tyrano.plugin.kag.tag.free_layermode = {
    vital: [],

    pm: {
        name: "", 
        time: "500", 
        wait: "true", 
        stop: "false", 
    },

     start: function (pm) {
        this.kag.ftag.hideNextImg();

        var that = this;

        var blend_layer = {};

        if (pm.name != "") {
            blend_layer = $(".layer_blend_" + pm.name);
        } else {
            blend_layer = $(".blendlayer");
        }

        var cnt = blend_layer.length;
        var n = 0;

        
        if (cnt == 0) {
            if(pm.stop == "false"){ 
                that.kag.ftag.nextOrder();
            }
            return;
        }

        blend_layer.each(function () {
            var blend_obj = $(this);
            blend_obj.stop(true, true).fadeOut(parseInt(pm.time), function () {
                blend_obj.remove();
                n++;
                if (pm.wait == "true") {
                    if (cnt == n) {
                        if(pm.stop == "false"){ 
                            that.kag.ftag.nextOrder();
                        }
                    }
                }
            });
        });

        if (pm.wait == "false") {
            if(pm.stop == "false"){ 
                this.kag.ftag.nextOrder();
            }
        }
    },
};
TYRANO.kag.ftag.master_tag.free_layermode = object(tyrano.plugin.kag.tag.free_layermode);
TYRANO.kag.ftag.master_tag.free_layermode.kag = TYRANO.kag;


tyrano.plugin.kag.tag.SHOW_DATE = {
    vital: [
        "year",
        "month",
        "day"
    ],

    pm: {
        year: "",
        month: "",
        day: "",
        time: "200", 
        wait: "false", 
        method: "fadeIn"
    },

     start: function (pm) {
        const wait = pm.wait == "true";
        const method = pm.method;
        const fadeTime = parseInt(pm.time);

        const year = Common.zeroPadding(pm.year, 4);
        const month = Common.zeroPadding(pm.month, 2);
        const day = Common.zeroPadding(pm.day, 2);
        const date = `${year}/${month}/${day}`;

        const year_list = Common.stringToArray(year);
        const month_list = Common.stringToArray(month);
        const day_list = Common.stringToArray(day);
        const join_text_list = year_list.concat(["/"], month_list, ["/"], day_list);

        const numbers_html = join_text_list.map(c => {
            const is_slash = c == "/";
            return is_slash
                ? `<span class="slash"></span>`
                : `<span style="background-image: url(./data/image/adv/common/date/date_${c}.png);"></span>`;
        }).join("");

        let elem = $('mist-date');
        if (elem.length == 0) {
            elem = $(`<mist-date></mist-date>`);
            
            elem.addClass("fixlayer");
            elem.attr("l_visible", true);
            const target_layer = TYRANO.kag.layer.getLayer("fix", "fore");
            target_layer.append(elem);
        }
        
        elem.html(`<content>${numbers_html}</content>`);
        elem.show();
        elem.attr("l_visible", true);

        if(fadeTime > 0) {
            if(wait) {
                
                TYRANO.kag.weaklyStop();
            }

            
            elem.css("animation-duration", fadeTime + "ms");

            elem.show();
            const animationEnd = "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend";
            elem.addClass("animated " + method).one(animationEnd, function () {
                elem.off(animationEnd);
                elem.css("animation-duration", "");
                $(this).removeClass("animated " + method);

                elem.css("opacity", 1);
                if (wait) {
                    TYRANO.kag.cancelWeakStop();
                    TYRANO.kag.ftag.nextOrder();
                }
            });
        }
        else {
            elem.css("opacity", 1);
        }

        if (!wait) {
            TYRANO.kag.ftag.nextOrder();
        }
     }
};
TYRANO.kag.ftag.master_tag.SHOW_DATE = object(tyrano.plugin.kag.tag.SHOW_DATE);
TYRANO.kag.ftag.master_tag.SHOW_DATE.kag = TYRANO.kag;


tyrano.plugin.kag.tag.HIDE_DATE = {
    vital: [],

    pm: {
        time: "200", 
        wait: "false", 
        method: "fadeIn"
    },

     start: function (pm) {
        const elem = $("mist-date");

        if (elem.length > 0) {
            const wait = pm.wait == "true";
            let method = pm.method;
            const fadeTime = parseInt(pm.time);
            if(fadeTime > 0) {
                
                if (wait) {
                    TYRANO.kag.weaklyStop();
                }

                
                elem.css("animation-duration", fadeTime + "ms");
                elem.show();
                method = $.replaceAll(method, "In", "Out");
                const animationEnd = "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend";
                elem.addClass("animated " + method).one(animationEnd, function () {
                    elem.off(animationEnd);
                    elem.css("animation-duration", "");
                    $(this).removeClass("animated " + method);
    
                    elem.hide();
                    elem.attr("l_visible", false);
                    if (wait) {
                        TYRANO.kag.cancelWeakStop();
                        TYRANO.kag.ftag.nextOrder();
                    }
                });
            }
            else {
                elem.hide();
                elem.attr("l_visible", false);
            }

            if (!wait) {
                TYRANO.kag.ftag.nextOrder();
            }
        }else{
            TYRANO.kag.ftag.nextOrder();
        }        
     }
};
TYRANO.kag.ftag.master_tag.HIDE_DATE = object(tyrano.plugin.kag.tag.HIDE_DATE);
TYRANO.kag.ftag.master_tag.HIDE_DATE.kag = TYRANO.kag;



const _layermode_movie = tyrano.plugin.kag.tag.layermode_movie
tyrano.plugin.kag.tag.layermode_movie = {
    vital: ["video"],

    pm: {
        name: "",
        mode: "multiply",
        opacity: "",
        time: "500", 
        wait: "false", 
        video: "", 
        volume: "",
        loop: "true",
        mute: "false",
        speed: "",

        fit: "true",

        width: "",
        height: "",
        top: "",
        left: "",

        stop: "false", 
        zindex: "99",  
    },
    start: function (pm) {
        this.kag.ftag.hideNextImg();

        var that = this;

        var blend_layer = null;

        blend_layer = $(
            "<video class='layer_camera layer_blend_mode blendlayer blendvideo' data-video-name='" +
                pm.name +
                `' data-video-pm='' style='display:none;position:absolute;width:100%;height:100%;z-index:${pm.zindex}' ></video>`,
        );
        var video = blend_layer.get(0);
        var url = "./data/video/" + pm.video;

        video.src = url;

        if (pm.volume != "") {
            video.volume = parseFloat(parseInt(pm.volume) / 100);
        } else {
            video.volume = 0;
        }

        if (pm.speed != "") {
            video.defaultPlaybackRate = parseFloat(pm.speed);
        }

        video.style.backgroundColor = "black";
        video.style.position = "absolute";
        video.style.top = "0px";
        video.style.left = "0px";
        video.style.width = "auto";
        video.style.height = "auto";

        

        if (pm.width != "") {
            video.style.width = pm.width + "px";
        }

        if (pm.height != "") {
            video.style.height = pm.height + "px";
        } else {
            if (pm.fit == "false") {
                video.style.height = "100%";
            } else {
                video.style.height = "";
            }
        }

        if (pm.left != "") {
            video.style.left = pm.left + "px";
        }

        if (pm.top != "") {
            video.style.top = pm.top + "px";
        }

        if(pm.width == ""){
            video.style.minHeight = "100%";
        }
        if(pm.height == ""){
            video.style.minWidth = "100%";
        }
        if(pm.zIndex != ""){
            video.style.zIndex = parseFloat(pm.zIndex);
        }
        video.style.backgroundSize = "cover";

        video.autoplay = true;
        video.autobuffer = true;

        video.setAttribute("playsinline", "1");

        if (pm.mute == "true") {
            video.muted = true;
        }

        if (pm.loop == "true") {
            video.loop = true;
        } else {
            video.loop = false;
        }

        var j_video = $(video);

        
        video.addEventListener("ended", function (e) {
            if (pm.loop == "false") {
                j_video.remove();
            }

            if (pm.wait == "true") {
                that.kag.ftag.nextOrder();
            }
        });

        j_video.attr("data-video-pm", JSON.stringify(pm));

        j_video.hide();

        video.load();
        
        
        let playPromise = video.play();
        if (playPromise !== undefined) {
          playPromise.then(_ => {
            
            
          })
          .catch(error => {
            
            
          });
        }

        blend_layer = j_video;

        if (pm.name != "") {
            blend_layer.addClass("layer_blend_" + pm.name);
        }

        if (pm.opacity != "") {
            blend_layer.css("opacity", $.convertOpacity(pm.opacity));
        }

        blend_layer.css("mix-blend-mode", pm.mode);

        $("#tyrano_base").append(blend_layer);

        blend_layer.stop(true, true).fadeIn(parseInt(pm.time), function () {
            if (pm.wait == "true" && pm.loop == "true") {
                if (pm.stop != "true") {
                    that.kag.ftag.nextOrder();
                }
            }
        });

        if (pm.wait == "false") {
            if (pm.stop != "true") {
                this.kag.ftag.nextOrder();
            }
        }
    },
};
TYRANO.kag.ftag.master_tag.layermode_movie = object(tyrano.plugin.kag.tag.layermode_movie);
TYRANO.kag.ftag.master_tag.layermode_movie.kag = TYRANO.kag;



const _setSkip = TYRANO.kag.setSkip
TYRANO.kag.setSkip = function (bool, options = {}, is_exec=false) {
    if(!is_exec){
        return ;
    }
	_setSkip.apply(TYRANO.kag, [bool, options]);
}


const _setAuto = TYRANO.kag.setAuto
TYRANO.kag.setAuto = function (bool, is_exec=false) {
    if(!is_exec){
        return ;
    }

	_setAuto.apply(TYRANO.kag, [bool]);
}


const _mask = tyrano.plugin.kag.tag.mask
tyrano.plugin.kag.tag.mask = {
 vital: [],

    pm: {
        time: 1000,
        effect: "fadeIn",
        color: "0x000000",
        graphic: "",
        folder: "",
        stop: false,
    },

    start: function (pm) {
        var that = this;
        that.kag.weaklyStop();

        if (pm.time == "0") {
            pm.time = "1";
        }

        var j_div = $("<div class='layer layer_mask' data-effect='" + pm.effect + "' style='z-index:100000000;position:absolute;'>");
        j_div.css("animation-duration", parseInt(pm.time) + "ms");

        var sc_width = parseInt(that.kag.config.scWidth);
        var sc_height = parseInt(that.kag.config.scHeight);

        var behind = false;

        j_div.css({ width: sc_width, height: sc_height });

        if (pm.color == "none") {
            j_div.css("background-color", "");
        } else {
            j_div.css("background-color", $.convertColor(pm.color));
        }

        if (pm.graphic != "") {
            var folder = "";
            if (pm.folder != "") {
                folder = pm.folder;
            } else {
                folder = "image";
            }

            var storage_url = "";

            if (pm.graphic != "") {
                storage_url = "./data/" + folder + "/" + pm.graphic;
                j_div.css("background-image", "url(" + storage_url + ")");
            }

            
            behind = true;
        }

        
        if (behind == false) {
            j_div.css("transform", "scale(1.02)");
        }

        $(".tyrano_base").append(j_div);

        var animationEnd = "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend";
        j_div.addClass("animated " + pm.effect).one(animationEnd, function () {
            

            if (behind == false) {
                $("#root_layer_game").css("opacity", 0);
            }

            if(pm.stop == false){
                that.kag.ftag.nextOrder();
            }
        });
    },
};
TYRANO.kag.ftag.master_tag.mask = object(tyrano.plugin.kag.tag.mask);
TYRANO.kag.ftag.master_tag.mask.kag = TYRANO.kag;



const _mask_off = tyrano.plugin.kag.tag.mask_off
tyrano.plugin.kag.tag.mask_off = {
    vital: [],

    pm: {
        time: 1000,
        effect: "fadeOut",
        stop: false,
    },

    start: function (pm) {
        var that = this;
        var j_div = $(".layer_mask");
        if (pm.time == "0") {
            pm.time = "1";
        }

        $("#root_layer_game").css("opacity", 1);

        if (j_div.get(0)) {
            var _effect = j_div.attr("data-effect");
            j_div.removeClass("animated " + _effect);
            j_div.css("animation-duration", parseInt(pm.time) + "ms");

            var animationEnd = "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend";
            j_div.addClass("animated " + pm.effect).one(animationEnd, function () {
                j_div.remove();
                that.kag.cancelWeakStop();
                if(pm.stop == false){
                    that.kag.ftag.nextOrder();
                }
            });
        } else {
            that.kag.cancelWeakStop();
            if(pm.stop == false){
                that.kag.ftag.nextOrder();
            }
        }
    },
};

TYRANO.kag.ftag.master_tag.mask_off = object(tyrano.plugin.kag.tag.mask_off);
TYRANO.kag.ftag.master_tag.mask_off.kag = TYRANO.kag;




tyrano.plugin.kag.tag.movie = {
vital: ["storage"],

    pm: {
        storage: "",
        volume: "",
        skip: "false",
        mute: "false",
        
        bgmode: "false",
        loop: "false",
    },

    start: function (pm) {
        var that = this;

        if ($.userenv() != "pc") {
            this.kag.cancelWeakStop();

            
            
            if ($.isTyranoPlayer()) {
                that.playVideo(pm);
            } else {
                this.kag.cancelWeakStop();
                
                that.playVideo(pm);
                $(".tyrano_base").unbind("click.movie");
                
            }
        } else {
            
            if ($.getBrowser() == "opera") {
                pm.storage = $.replaceAll(pm.storage, ".mp4", ".webm");
            }

            that.playVideo(pm);
        }
    },

    playVideo: function (pm) {
        var that = this;

        var url = "./data/video/" + pm.storage;

        var video = document.createElement("video");
        video.id = "bgmovie";
        
        video.src = url;

        if (!isNaN(parseInt(pm.volume))) {
            video.volume = parseFloat(parseInt(pm.volume) / 100);
        } else {
            if (typeof this.kag.config.defaultMovieVolume != "undefined") {
                video.volume = parseFloat(parseInt(this.kag.config.defaultMovieVolume) / 100);
            }
        }

        

        video.style.backgroundColor = "black";
        video.style.position = "absolute";
        video.style.top = "0px";
        video.style.left = "0px";
        video.style.width = "100%";
        video.style.height = "100%";
        video.style.display = "none";
        video.autoplay = true;
        video.autobuffer = true;

        video.setAttribute("playsinline", "1");

        if (pm.mute == "true") {
            video.muted = true;
        }

        

        if (pm.bgmode == "true") {
            that.kag.tmp.video_playing = true;

            
            video.style.zIndex = 0;

            if (pm.loop == "true") {
                video.loop = true;
            } else {
                video.loop = false;
            }

            video.addEventListener("ended", function (e) {
                
                
                
                if (that.kag.stat.video_stack == null) {
                    
                    that.kag.tmp.video_playing = false;

                    if (that.kag.stat.is_wait_bgmovie == true) {
                        that.kag.ftag.nextOrder();
                        that.kag.stat.is_wait_bgmovie = false;
                    }

                    
                } else {
                    var video_pm = that.kag.stat.video_stack;

                    var video2 = document.createElement("video");

                    video2.style.backgroundColor = "black";
                    video2.style.position = "absolute";
                    video2.style.top = "0px";
                    video2.style.left = "0px";
                    video2.style.width = "100%";
                    video2.style.height = "100%";
                    video2.autoplay = true;
                    video2.autobuffer = true;

                    if (video_pm.loop == "true") {
                        video2.loop = true;
                    } else {
                        video2.loop = false;
                    }

                    video2.setAttribute("playsinline", "1");

                    if (video_pm.mute == "true") {
                        video2.muted = true;
                    }

                    
                    video2.src = "./data/video/" + video_pm.storage;
                    video2.load();
                    var j_video2 = $(video2);
                    video2.play();
                    j_video2.css("z-index", -1);
                    $("#tyrano_base").append(j_video2);

                    video2.addEventListener(
                        "canplay",
                        function (event) {
                            var arg = arguments.callee;

                            
                            j_video2.css("z-index", 1);

                            setTimeout(function () {
                                $("#bgmovie").remove();
                                video2.id = "bgmovie";
                            }, 100);

                            that.kag.stat.video_stack = null;
                            

                            that.kag.tmp.video_playing = true;

                            video2.removeEventListener("canplay", arg, false);
                            

                            
                        },
                        false,
                    );

                    

                    video2.addEventListener("ended", arguments.callee);

                    
                }
            });
        } else {
            video.style.zIndex = 199999;

            video.addEventListener("ended", function (e) {
                $(".tyrano_base").find("video").remove();
                that.kag.ftag.nextOrder();
            });

            
            

            if (pm.skip == "true") {
                $(video).on("click touchstart", function (e) {
                    $(video).off("click touchstart");
                    $(".tyrano_base").find("video").remove();
                    that.kag.ftag.nextOrder();
                });
            }
        }

        var j_video = $(video);
        j_video.css("opacity", 0);

        

        $("#tyrano_base").append(j_video);
        j_video.animate(
            { opacity: "1" },
            {
                duration: parseInt(pm.time),
                complete: function () {
                    
                    
                    
                    
                    
                },
            },
        );

        video.load();

        
        video.addEventListener("canplay", function () {
            video.style.display = "";
            video.play();
        });
    },
};
TYRANO.kag.ftag.master_tag.movie = object(tyrano.plugin.kag.tag.movie);
TYRANO.kag.ftag.master_tag.movie.kag = TYRANO.kag;


tyrano.plugin.kag.tag.label = {
    pm: {
        nextorder: "true",
    },

    start: function (pm) {
        
        const target_scenario = pm.scneario || this.kag.stat.current_scenario;
        
        if (this.kag.config.autoRecordLabel == "true") {
            var sf_tmp =
                "trail_" +
                target_scenario
                    .replace(".ks", "")
                    .replace(/\u002f/g, "")
                    .replace(/:/g, "")
                    .replace(/\./g, "");
            var sf_buff = this.kag.stat.buff_label_name;
            var sf_label = sf_tmp + "_" + pm.label_name;

            if (this.kag.stat.buff_label_name != "") {
                if (!this.kag.variable.sf.record) {
                    this.kag.variable.sf.record = {};
                }

                var sf_str = "sf.record." + sf_buff;

                var scr_str = "" + sf_str + " = " + sf_str + "  || 0;" + sf_str + "++;";
                this.kag.evalScript(scr_str, false);
            }

            if (this.kag.variable.sf.record) {
                if (this.kag.variable.sf.record[sf_label]) {
                    
                    this.kag.stat.already_read = true;
                } else {
                    this.kag.stat.already_read = false;
                }
            }

            
            this.kag.stat.buff_label_name = sf_label;
        }

        
        if (pm.nextorder == "true") {
            this.kag.ftag.nextOrder();
        }
    },
};
TYRANO.kag.ftag.master_tag.label = object(tyrano.plugin.kag.tag.label);
TYRANO.kag.ftag.master_tag.label.kag = TYRANO.kag;


tyrano.plugin.kag.tag.skipstop = {
    start: function (pm) {
        this.kag.setSkip(false, {}, true);
        this.kag.ftag.nextOrder();
    },
};
TYRANO.kag.ftag.master_tag.skipstop = object(tyrano.plugin.kag.tag.skipstop);
TYRANO.kag.ftag.master_tag.skipstop.kag = TYRANO.kag;



tyrano.plugin.kag.evalScript = function (str, savesystem=true) {
        var TG = this;

        var f = this.stat.f;
        var sf = this.variable.sf;
        var tf = this.variable.tf;
        var mp = this.stat.mp;

        try {
            eval(str);
            if(savesystem){
                this.saveSystemVariable();
            }
        } catch (e) {
            console.error(e);
            this.warning(e, true);
        }

        if (this.kag.is_studio) {
            this.kag.studio.notifyChangeVariable();
        }
};


tyrano.plugin.kag.tag.eval = {
    vital: ["exp"],

    pm: {
        exp: "",
        next: "true",
    },

    start: function (pm) {
        this.kag.evalScript(pm.exp, false);

        if (pm.next == "true") {
            this.kag.ftag.nextOrder();
        }
    },
};
TYRANO.kag.ftag.master_tag.eval = object(tyrano.plugin.kag.tag.eval);
TYRANO.kag.ftag.master_tag.eval.kag = TYRANO.kag;



tyrano.plugin.kag.tag.endscript = {
    pm: {
        stop: "false",
    },

    start: function (pm) {
        var that = this;
        this.kag.stat.is_script = false;
        
        try {
            this.kag.evalScript(this.kag.stat.buff_script, false);
        } catch (err) {
            that.kag.error("error_in_iscript");
            console.error(err);
        }
        this.kag.stat.buff_script = "";

        if (pm.stop == "false") {
            this.kag.ftag.nextOrder();
        }
    },
};
TYRANO.kag.ftag.master_tag.endscript = object(tyrano.plugin.kag.tag.endscript);
TYRANO.kag.ftag.master_tag.endscript.kag = TYRANO.kag;



tyrano.plugin.kag.tag.bgmovie = {
    vital: ["storage"],

    pm: {
        storage: "",
        volume: "",
        loop: "true",
        mute: "false",
        time: "300",
        stop: "false", 
    },

    start: function (pm) {
        var that = this;

        pm.skip = "false";
        pm.bgmode = "true";

        this.kag.stat.current_bgmovie["storage"] = pm.storage;
        this.kag.stat.current_bgmovie["volume"] = pm.volume;
        this.kag.stat.current_bgmovie["loop"] = pm.loop;

        
        if (this.kag.tmp.video_playing != false) {

            var video = document.getElementById("bgmovie");
            if(video){
                this.kag.stat.video_stack = pm;
                video.loop = false;
    
                that.kag.ftag.nextOrder();
                return;
            }
            this.kag.tmp.video_playing = false;
        }

        this.kag.ftag.startTag("movie", pm);

        if (pm.stop == "false") {
            this.kag.ftag.nextOrder();
        }
    },
};
TYRANO.kag.ftag.master_tag.bgmovie = object(tyrano.plugin.kag.tag.bgmovie);
TYRANO.kag.ftag.master_tag.bgmovie.kag = TYRANO.kag;

tyrano.plugin.kag.tag.fa_chara_part_origin =
{
    vital: ["name", "eye"],
    pm: {
        name: "",
        eye: "",
        time: "1",
    },
    start: function (pm) {
        const that = this;
        mist_system.BlinkAnimation.animation(pm, true, () => {
            that.kag.ftag.nextOrder();
        });
    }
}
TYRANO.kag.ftag.master_tag.fa_chara_part_origin = object(tyrano.plugin.kag.tag.fa_chara_part_origin);
TYRANO.kag.ftag.master_tag.fa_chara_part_origin.kag = TYRANO.kag;
