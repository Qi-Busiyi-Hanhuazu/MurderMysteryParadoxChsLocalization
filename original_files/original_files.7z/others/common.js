
let mist_temp = TYRANO.kag.variable.tf;
let mist_save = TYRANO.kag.stat.f;
let mist_system = TYRANO.kag.variable.sf;


TYRANO.kag.error = function(message, replace_map) {
    const current_storage = this.kag.stat.current_scenario,
    line = parseInt(this.kag.stat.current_line) + 1,
    line_str = $.lang("line", { line: line });
    message in tyrano_lang.word && (message = $.lang(message, replace_map));
    const error_str = `Error: ${current_storage}:${line_str}\n\n${message}`;
    console.error(error_str);
};


class Common {

	
	static checkHelpConditionsStr(cond_str) {
		if(!cond_str){ return true; }

		
		return true;
	}

	
	static randomRange(min, max)
	{
		return Math.floor(Math.random() * (max - min)) + min;
	}

	
	static replaceDefineColorString(str) {
		if(str.indexOf("color=") == -1){ return str; }
		Object.keys(masterdata.replace_define).forEach((key) => {
			const def = masterdata.replace_define[key];
			const reg = new RegExp(def.color_reg, 'g');
			str = str.replace(reg, def.color_value);
		});
		return str;
	}

	
	static replaceDefineLabelString(str) {
		Object.keys(masterdata.replace_define).forEach((key) => {
			if(str == key){ str = masterdata.replace_define[key].replace_value; }
		});
		return str;
	}

	
	static replaceDefineLabelStringAll(str) {
		Object.keys(masterdata.replace_define).forEach((key) => {
			const replace_value = masterdata.replace_define[key].replace_value; 
			const reg = new RegExp(key, 'g');
			str = str.replace(reg, replace_value);
		});
		return str;
	}

	
	static getDefineLabel(label_name){
		const result = masterdata.replace_define[label_name];
		if(!result){ return label_name; }
		return result.replace_value; 
	}



	
	static objectToClass(obj, type)
	{
		let classObj = Object.assign(new type(), obj);
		if ("deserialize" in classObj)
		{
			classObj.deserialize();
		}
		return classObj;
	}

    
    static toBool(str)
    {
        
        if (typeof str === "boolean") return str;
        
        if (!str) return false;
        return str.toLowerCase() === "true";
    }

    
    static toInt(str)
    {
        return Number(str);
    }

    
    static getFiles(fs, dir)
    {
        const path = require('path');
        return fs.readdirSync(dir).flatMap(filePath => {
            const full_path = `${dir}${path.sep}${filePath}`;
            const is_dir = fs.statSync(full_path).isDirectory();
            return is_dir ? Common.getFiles(fs, full_path) : full_path;
        });
    }

    
    static getFile(fs, file_path)
    {
        return fs.readFileSync(file_path);
    }

    
	static fileLoadPromise(path)
	{
        if (path.split('.').pop() == "json")
        {
            return new Promise((resolve, reject) => {
                $.getJSON(path)
                .done((json) => resolve([path, json]))
                .fail((data) => reject([path, data]));
            });
        }

        return new Promise((resolve, reject) => {
            $.get(path)
            .done((data) => resolve([path, data]))
            .fail((data) => reject([path, data]));
        });
	}

	
	static getCharaName()
	{
		return TYRANO.kag.chara.getCharaName();
	}

	
	static sfAddClass(class_obj)
	{
        TYRANO.kag.variable.sf[`${class_obj.constructor.name}`] = class_obj;
	}

    
    static clamp(num, min, max)
    {
        return Math.min(Math.max(num, min), max);
    }

    
    static groupBy(ary, key)
    {
        return ary.reduce(function(v, x) {
            (v[x[key]] = v[x[key]] || []).push(x);
            return v;
        }, {});
    }

    
	static addClickEvent(elem, pm)
	{
        
        if (elem.length == 0) return;

		const kag = TYRANO.kag;
		elem.css("cursor", "pointer");
		elem.off();
		
        elem.click((e) => {
            if (mist_temp.is_tutorial) return;
            
			const use_cm = pm.cm != "false";
            
            if (!kag.tmp.ready_audio) kag.readyAudio();

            
            
            

            
            if (!kag.key_mouse.mouse.isClickEnabled(e)) {
                kag.key_mouse.vmouse.hide();
                return false;
            }

            
            if (!kag.stat.is_strong_stop) return false;

            
            if (elem.hasClass("glink_button_clicked") && use_cm) return false;
            

            
            
            

            
            kag.key_mouse.vmouse.hide();

            
            kag.cancelStrongStop();

            
            elem.addClass("glink_button_clicked");

            
            if (pm.clickimg) j_button.css("background-image", "url(./data/image/" + pm.clickimg + ")");

            
            kag.trigger("click-tag-glink", e);

            
            if (pm.clickse) kag.playSound(pm.clickse);

            
            if (pm.exp) kag.embScript(pm.exp, preexp);

            
            const next = () => {
                
				
				if (use_cm) {
					kag.ftag.startTag("cm", { next: "false" });
				}

                
                if (pm.hold === "true") {
                    kag.stat.hold_glink = true;
                    kag.stat.hold_glink_storage = pm.storage;
                    kag.stat.hold_glink_target = pm.target;
                    kag.cancelStrongStop();
                    kag.cancelWeakStop();
                    kag.ftag.nextOrder();
                } else {
                    kag.ftag.startTag("jump", pm);
                }

                
                if (kag.stat.skip_link === "true") {
                    e.stopPropagation();
                } else {
                    kag.setSkip(false);
                }
            };

            
            
            

            
            let animation_target_count = 0;

            
            const j_collection = $(".glink_button");

            
            j_collection.each((i, elm) => {
                const j_elm = $(elm);
                
                const _pm = JSON.parse(j_elm.attr("data-event-pm"));
                
                const is_selected = j_elm.hasClass("glink_button_clicked");
                if (!is_selected) {
                    j_elm.addClass("glink_button_not_clicked");
                }
                
                const head = is_selected ? "select" : "reject";
                const hide_options = {};
                ["time", "easing", "effect", "keyframe", "delay"].forEach((key) => {
                    hide_options[key] = _pm[`${head}_${key}`];
                });
                
                const need_animate =
                    hide_options.time !== undefined &&
                    parseInt(hide_options.time) >= 10 &&
                    (hide_options.keyframe !== "none" || hide_options.effect !== "none");
                if (need_animate) {
                    animation_target_count += 1;
                }
                
                elm.__hide_options = hide_options;
                elm.__need_animate = need_animate;
            });

            
            const should_keep_skip = kag.stat.is_skip && kag.stat.skip_link === "true";

            
            
            

            
            if (animation_target_count === 0 || should_keep_skip) {
                next();
                return false;
            }

            
            
            

            
            kag.layer.cancelAllFreeLayerButtonsEvents();

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            return false;
        });
	}

    
    static blackout(time = 1000, oncomplete = undefined, is_remove = false)
    {
        time = parseInt(time);
        const elem = $(`<div id="blackout" style="position:absolute; left: 0px; top: 0px; width:100%; height:100%; background-color: rgba(0,0,0, 0)"></div>`);
        
        let layer_menu = TYRANO.kag.layer.getMenuLayer();
        layer_menu.append(elem);

        
        elem.animate({
            backgroundColor: 'rgba(0, 0, 0, 1)',
        }, time, () => {
            if (is_remove) elem.remove();
            if (oncomplete) oncomplete();
        })
    }

    
    static setVisible(elem, is_visible)
    {
        elem.css("visibility", is_visible ? "visible" : "hidden");
    }

    
    static saveSystem()
    {
        TYRANO.kag.saveSystemVariable();
    }

    
    static hoverImage(elem, hoverOn = undefined, hoverOff = undefined)
    {
        elem.each(function() {
            const image1 = $(this).attr("src");
            const image2 = image1.replace(".png", "2.png");
            $(this).hover(
                () => {
                    $(this).attr("src", image2);
                    if (hoverOn) hoverOn();
                },
                () => {
                    $(this).attr("src", image1);
                    if (hoverOff) hoverOff();
                },
            );
        });
    }

    
     static getClassList(elem)
     {
         const attr = elem.attr('class');
         return attr === undefined ? [] : attr.split(' ').filter(x => x != "");
     }

     
     static getClassByName(elem, name) {
        const ary = Common.getClassList(elem);
        for (let i = 0; i < ary.length; ++i) {
            const is_exist = ary[i].indexOf(name) !== -1;
            if (is_exist) return ary[i];
        }

        return "";
     }
 
     
    static setBlock(is_block = true, id = "", time = 0)
    {
        let block_layer = $("block_layer");
        if (block_layer.length == 0)
        {
            block_layer = $("<block_layer></block_layer>");
            block_layer.css("display", "none");
            block_layer.css("position", "absolute");
            block_layer.css("width", TYRANO.kag.config.scWidth);
            block_layer.css("height", TYRANO.kag.config.scHeight);
            
            block_layer.css("background-color", "rgba(255, 0, 255, 0)");
            block_layer.css("z-index", "2147483643");
            
            $('#tyrano_base').append(block_layer);
        }

        
        const unlock = () => {
            let block_layer = $("block_layer");
            if (id)
            {
                block_layer.removeClass(`block-${id}`);
            }
            let class_list = Common.getClassByName(block_layer, `block-`); 
            if (class_list.length == 0)
            {
                block_layer.hide();
                console.log("setBlock: false");
            }
        };

        if (is_block) {
            block_layer.show();
            console.log("setBlock: true");
            if (id)
            {
                block_layer.addClass(`block-${id}`);
            }
            if (time > 0)
            {
                
                setTimeout(() => {
                    unlock();
                }, time);
            }
        } else {
            unlock();
        }
    }

    
    static isVisible(elem)
    {
        const visibility = elem.css("visibility");
        return visibility == "visible";
    }

    
    static zeroPadding(value, digit)
    {
        return (Array(digit).join('0') + value).slice(-digit);
    }

    
    static clearDebugInfoHtml()
    {
        return;
        let elem = $('debug-info');
        if (elem.length == 0) return;
        elem.remove();
        if (mist_save.debug_animation_id)
        {
            cancelAnimationFrame(mist_save.debug_animation_id);
            delete mist_save.debug_animation_id;
        }
    }

    
    static debugInfoHtml(callback, is_visible = true)
    {
        return;
        if (!mist_save.enable_debug) return;

        Common.clearDebugInfoHtml();
        if ($('debug-info').length == 0)
        {
            let html = $('<debug-info></debug-info>');
            
            html.css("display", "block");
            html.css("position", "absolute");
            html.css("right", "0px");
            html.css("top", "0px");
            html.css("padding", "10px");
            html.css("max-height", "1000px");
            html.css("overflow-y", "auto");
            html.css("background-color", "rgba(0, 0, 0, 0.7)");
            html.css("color", "white");
            html.css("font-size", "20px");
            html.css("font-family", "FOT-UtrilloPro-DB");
            html.css("z-index", "10000000000");
            
            $("#root_layer_game").append(html);
        }
        Common.setVisible($('debug-info'), is_visible);

        Common._DebugInfoHtml(callback);
    }

    
    static _DebugInfoHtml(callback)
    {
        const elem = $('debug-info');
        if (elem.length == 0) return;
        let obj = callback();
        if (!obj) {
            elem.empty();
            return;
        }

        let s = JSON.stringify(obj, null, "  ").replace(/,/g, "").replace(/\"/g, "").replace(/\{/g, "").replace(/}/g, "");
        let str = `<pre style="font-family: consolas;">${s}</pre>`;
        elem.html(str);

        mist_save.debug_animation_id = requestAnimationFrame(() => Common._DebugInfoHtml(callback));
    }

    
    static fadeInAnimation(elem, onComplete, time = 200)
    {
        if (elem.length == 0) return;
        elem.stop(true, true).fadeIn(time, () => {
            if($.isFunction(onComplete)){
                onComplete();
            }
        });
    }

    
    static createDialogBase(is_show = true)
    {
        const layer = Common.getDialogLayer();
        let elem = $('.dialog');
        if (elem.length > 0) return elem;

        elem = $('<div class="dialog"></div>');
        if (is_show) {
            elem.show();
        } else {
            elem.hide();
        }
        layer.append(elem);
        return elem;
    }

    
    static getLayer(name, is_show = false)
    {
        const layer = name == "free"
            ? TYRANO.kag.layer.getFreeLayer()
            : TYRANO.kag.layer.getLayer(name, "fore");
        if (is_show) layer.show();
        return layer;
    }

    
    static addFixLayer(elem) {
        const layer = TYRANO.kag.layer.getLayer("fix");
        layer.append(elem);
        elem.addClass("fixlayer");
    }

    
    static getDialogLayer()
    {
        
        let layer = TYRANO.kag.layer.getLayer("message13", "fore");
        
        layer.find(".message_outer").remove();
        layer.find(".message_inner").remove();
        layer.show();
        return layer;
    }

    
    static clearDialogLayer()
    {
        let layer = Common.getDialogLayer();
        layer.empty();
        layer.hide();
    }

    
    static makeFocusable(elem, tabindex = "")
    {
        TYRANO.kag.makeFocusable(elem, tabindex);
    }

    
    static makeUnfocusable(elem)
    {
        TYRANO.kag.makeUnfocusable(elem);
    }

    
    static registerFocus(key, up_on, down_on, left_on, right_on) {
        
        const length = mist_temp.focus_info.length;
        if (length > 0) {
            var last = mist_temp.focus_info[length - 1];
            if (last.key == key) {
                
                return;
            }
        }
        mist_temp.focus_info.push({
            "key": key,
            "up_on": up_on,
            "down_on": down_on,
            "left_on": left_on,
            "right_on": right_on,
        });
    }
    
    
    static unregisterFocus(key) {
        
        const length = mist_temp.focus_info.length;
        if (length > 0) {
            var last = mist_temp.focus_info[length - 1];
            if (last.key == key) {
                
                mist_temp.focus_info.pop();
                return;
            }
        }
    }
    
    
    static focusUp() {
        const length = mist_temp.focus_info.length;
        if (length > 0) {
            return mist_temp.focus_info[length - 1].up_on();
        }
        return false;
    }
    
    
    static focusDown() {
        const length = mist_temp.focus_info.length;
        if (length > 0) {
            return mist_temp.focus_info[length - 1].down_on();
        }
        return false;
    }
    
    
    static focusLeft() {
        const length = mist_temp.focus_info.length;
        if (length > 0) {
            return mist_temp.focus_info[length - 1].left_on();
        }
        return false;
    }
    
    
    static focusRight() {
        const length = mist_temp.focus_info.length;
        if (length > 0) {
            return mist_temp.focus_info[length - 1].right_on();
        }
        return false;
    }

    
    static registerWheel(key, up_on, down_on) {
        
        const length = mist_temp.wheel_info.length;
        if (length > 0) {
            var last = mist_temp.wheel_info[length - 1];
            if (last.key == key) {
                
                return;
            }
        }
        mist_temp.wheel_info.push({
            "key": key,
            "up_on": up_on,
            "down_on": down_on,
        });
    }
    
    static unregisterWheel(key) {
        
        const length = mist_temp.wheel_info.length;
        if (length > 0) {
            var last = mist_temp.wheel_info[length - 1];
            if (last.key == key) {
                
                mist_temp.wheel_info.pop();
                return;
            }
        }
    }
    
    
    static wheelUp() {
        const length = mist_temp.wheel_info.length;
        if (length > 0) {
            return mist_temp.wheel_info[length - 1].up_on();
        }
        return false;
    }
    
    
    static wheelDown() {
        const length = mist_temp.wheel_info.length;
        if (length > 0) {
            return mist_temp.wheel_info[length - 1].down_on();
        }
        return false;
    }

    static wheel(elem, delta, afterglow_needs = true) {
        TYRANO.kag.key_mouse.util.smoothScrollWithFixedSpeed(elem[0], delta, afterglow_needs);
    }

    
    static on(event_names, callback, options = {})
    {
        TYRANO.kag.off(event_names, options);
        TYRANO.kag.on(event_names, callback, options);
    }

    
    static trigger(event_name, event_obj = {})
    {
        TYRANO.kag.trigger(event_name, event_obj);
    }

    
    static off(event_names, options = {})
    {
        TYRANO.kag.off(event_names, options);
    }

    
    static isFocusble(elem)
    {
        if (elem.css("display") === "none") return false;
        if (elem.css("pointer-events") === "none") return false;
        if (elem.css("visibility") === "hidden") return false;
        return true;
    }

    
    static outputConsole()
    {
        const fs = require('fs');
        const util = require('util');
        const flags = 'a'; 
        const dt = new Date();
        const dt_string = dt.getFullYear()  + ("00" + (dt.getMonth()+1)).slice(-2) +  ("00" + (dt.getDate())).slice(-2);
        const log_file = fs.createWriteStream(__dirname + '/mist' + dt_string + '.log', {flags : flags });

        log_file.write(`------------- NewLogStart ${String(dt)} ----------------\n`);
        const _console_log = console.log;
        console.log = function(message, ...params) {
            _console_log.apply(console, arguments);
            const s = util.format(message).replace(/\%c/g, '');
            log_file.write(`${s}\n`);
        };

        const _console_error = console.error;
        console.error = function(message, ...params) {
            _console_error.apply(console, arguments);
            const s = util.format(message).replace(/\%c/g, '');
            log_file.write(`[ERROR] ${s}\n`);
        };
        const _console_warn = console.warn;
        console.warn = function(message, ...params) {
            _console_warn.apply(console, arguments);
            const s = util.format(message).replace(/\%c/g, '');
            log_file.write(`[WARN] ${s}\n`);
        };
    }

    
    static timeStamp()
    {
        const date = new Date();
        const Y = date.getFullYear();
        const M = ("00" + (date.getMonth()+1)).slice(-2);
        const D = ("00" + date.getDate()).slice(-2);
        const h = ("00" + date.getHours()).slice(-2);
        const m = ("00" + date.getMinutes()).slice(-2);
        const s = ("00" + date.getSeconds()).slice(-2);
        return `${Y}/${M}/${D} ${h}:${m}:${s}`;
    }

    
    static gameClose()
    {
        window.close();

        if (typeof navigator.app !== "undefined") {
            navigator.app.exitApp();
        }
        if (typeof require != "undefined" && typeof require("nw.gui") != "undefined") {
            require("nw.gui").Window.get().close();   
        }
    }

    
    static templateToString(str, dict)
    {
        return dict.template
            ? Common._nestToString(str, dict.template)
            : Common._paramToString(str, dict);
    }

    
    static _paramToString(str, dict)
    {
        Object.keys(dict).forEach(function(key) {
            str = str.replace(new RegExp('\\${' + key + '}','g'), dict[key]);
        });
        return str;
    }

    
    static _nestToString(str, dict)
    {
        str = str.replace(/\$\{(.+?)\}/g, function(m, c) {
            const ary = c.split(".");
            switch (ary.length) {
                case 1: return dict[ary[0]];
                case 2: return dict[ary[0]][ary[1]];
                case 3: return dict[ary[0]][ary[1]][ary[2]];
                case 4: return dict[ary[0]][ary[1]][ary[2]][ary[3]];
                case 5: return dict[ary[0]][ary[1]][ary[2]][ary[3]][ary[4]];
            }
            console.error("オブジェクトのネストが深すぎます。");
            return dict[c];
        });
        return str;
    }

    static convertDict(json_str) {
        
        if(json_str.indexOf('{') != 0){
            return {};
        }
        let ret = {};
        let elements = json_str.replace("{", "").replace("}", "").split(",");
        elements.forEach((element) => {
            const elems = element.split(':');
            ret[elems[0]] = elems[1];
        });

        return ret;
    }

    
    static isExistObj(obj) {
        return Object.keys(obj).length != 0;
    }


    
    static addDataEvent(elem, pm) {
        elem.addClass("event-setting-element");
        elem.attr("data-event-tag", "MIST_SERIALIZABLE");
        elem.attr("data-event-pm", JSON.stringify(pm));
    }

    
    static deleteDataEvent(elem) {
        elem.removeClass("event-setting-element");
        elem.removeAttr("data-event-tag data-event-pm");
    }

    
    static stringToArray(str) {
        let list = [];
        for (let i = 0; i < str.length; ++i) {
            list.push(str.charAt(i));
        }
        return list;
    }

    static preloadAll(storages, callback) {
        TYRANO.kag.preloadAll(storages, callback);
    }

    
    static playMovie(pm) {
        if($('common-movie-container').length > 0) {
            return;
        }
        
        let movie_skip_timeout = undefined;
        const html =`
            <common-movie-container>
                <video src="./data/video/${pm.storage}"></video>
            </common-movie-container>`;
        pm.layer.append(html);

        const container = pm.layer.find("common-movie-container");
        let video = container.find("video").get(0);
        video.muted = pm.mute === undefined ? false : pm.mute;
        video.volume = pm.volume === undefined
            ? parseFloat(parseInt(TYRANO.kag.config.defaultMovieVolume) / 100)
            : video.volume = parseFloat(parseInt(pm.volume) / 100);
        $(video).css("z-index", pm.zIndex === undefined ? "" : pm.zIndex);

        let timers = [];
        
        const complete = () => {
            timers.forEach(x => clearTimeout(x));
            timers = [];
            video.src = "";
            video.load();
            container.remove();
            if ($.isFunction(pm.onComplete)) pm.onComplete();

            if(movie_skip_timeout) {
                clearTimeout(movie_skip_timeout);
            }
            mist_system.FooterContainer.show();
            mist_system.FooterContainer.back();
        };

        
        mist_system.FooterContainer.showMoiveFooter(function() {
            video.pause();
            $(video).off();
            container.fadeTo(200, 0, () => {
                
                complete();
            });
        });

        
        mist_system.FooterContainer.hide();
        container.click(() => {
            mist_system.FooterContainer.show();
            if(movie_skip_timeout) {
                clearTimeout(movie_skip_timeout);
            }
            movie_skip_timeout = setTimeout(
                function() {
                    movie_skip_timeout = undefined;
                    mist_system.FooterContainer.hide();
                },
                5000
            );
        });

        $(video).on("ended", () => {
            
            complete();
        });

        
        $(video).on("canplay", () => {
            
            video.play();
        });

        
        $(video).on("play", () => {
            
            container.fadeTo(200, 1);

            
            const t = video.duration * 1000 - 300;
            timers.push(setTimeout(() => {
                video.pause();
                
                container.fadeTo(200, 0, () => {
                    complete();
                });
            }, t));
        });

        video.load();
    }

    
    static getDisplayNameToFullName(display_name) {
        
        let fullnames = [];
        for (const [_, value] of Object.entries(masterdata.names)) {
            const sysname = value.sysname;
            const fullname = value.fullname;
            fullnames[sysname] = fullname;
        }

        const error = (sysname) => {
            console.error(`${sysname}: 存在しないsysnameです`);
        };

        
        switch (display_name) {
            case "NPC":
                if (!(TYRANO.kag.stat.f.npc in fullnames)) {
                    error(TYRANO.kag.stat.f.npc);
                    return "";
                }
                return fullnames[TYRANO.kag.stat.f.npc];

            case "主人公":
                if (!("樹" in fullnames)) {
                    error(TYRANO.kag.stat.f.npc);
                    return "";
                }
                return fullnames["樹"];
        }

        
        if (!(display_name in fullnames)) {
            console.log(`display_name: ${display_name}`);
            return display_name;
        }

        
        return fullnames[display_name];
    }

    
    static addMessageCount() {
        ++TYRANO.kag.stat.message_id;
    }

    
    static removeHtmlTag(text) {
        return text.replace(/(<([^>]+)>)/gi, '');
    }

    
    static checkAndCreateSaveLock() {
        if (mist_system.save_lock != undefined) {
            return;
        }
        mist_system.save_lock = [];
        TYRANO.kag.menu.getSaveData().data.forEach((x, i) => {
            mist_system.save_lock[i] = false;
        });
    }

    
    static autoBRText(text, br_count) {
        const br = "<br>";
        const br_length = br.length;
        let ret = "";
        let count = 0;
        for (var i = 0; i < text.length; ++i) {
            const c = text[i];
            if (text.indexOf(br, i) == i) {
                ret += br;
                i += br_length - 1;
                count = 0;
            } else if (c == '<') {
                for (var j = i; j < text.length; ++j) {
                    ret += text[j];
                    if (text[j] == '>') {
                        i = j;
                        break;
                    }
                }
            } else {
                ret += c;
                if (++count == br_count) {
                    count = 0;
                    ret += br;
                }
            }
        }
        return ret;
    }

    
    static durationSelected(){
        return Number(TYRANO.kag.config.durationSelected);
    }

    
    static setFocus(elem) {
        if (elem === undefined || typeof elem.get === 'undefined' || elem.length == 0) {
            return;
        }

        
        if(!$("html").hasClass("mouse_disable")) {
            $("html").addClass("mouse_disable");
            TYRANO.kag.key_mouse.util.setMouseHoverMask(true);
            TYRANO.kag.key_mouse.mouse.disable_first = true;
        }
        setTimeout(function() {
            TYRANO.kag.key_mouse.util.focus(elem);
        }, 10);
    }

    
    static getFilename(path_str){
        return path_str.replace(/^url\(["']?/, '').replace(/["']?\)$/, '').split("/").reverse()[0];
    }

    
    static clamp(number, min, max) {
        return Math.max(min, Math.min(number, max));
    }

    
    static resetTempVolume() {
		setTempBgmVolume(100);
		setTempSeVolume(100);
		resetTempSeBufVolume();
    }

    static isPreventSimultaneosKey(){
        return TYRANO.kag.key_mouse.preventSimultaneosKey !== void 0 || mist_temp.preventScene !== void 0;
    }
    static addPreventScene(name){
        mist_temp.preventScene = name;
    }
    static removePreventScene(name){
        delete mist_temp.preventScene;
    }

    
    static isSkipAwaitInput(){
        return TYRANO.kag.stat.is_skip || TYRANO.kag.stat.is_auto;
    }

    
    static unfocusKey(){
        TYRANO.kag.unfocus();
    }


    static new_help(id, visible) {
        let item = undefined;
        for (const [key, value] of Object.entries(masterdata.help)) {
            item = masterdata.help[key].find(x => x.id == id);
            if (item) break;
        }
        if (item === undefined)
        {
            console.error(`[NEW_HELP] ${id} マスターデータに存在しないヘルプidです。`);
            return;
        }

        if (!mist_system.helps)
        {
            mist_system.helps = {};
            Object.keys(masterdata.help).forEach(key => {
                masterdata.help[key].forEach(x => {
                    mist_system.helps[x.id] = { is_release: false, is_new: true, is_visible: true };
                });
            });
        }
        mist_system.helps[id].is_release = true;
        mist_system.helps[id].is_visible = Common.toBool(visible);
    }

    
    static getSaveData() {
        if (mist_temp.cache_save_data == undefined) {
            this.applyCacheSaveData();
        }
        return mist_temp.cache_save_data;
    }

    
    static applyCacheSaveData() {
        mist_temp.cache_save_data = TYRANO.kag.menu.getSaveData();
    }

    
    static enableMouseCursor() {
        $("html").removeClass("mouse_disable");
        TYRANO.kag.key_mouse.util.setMouseHoverMask(false);
    }
}


